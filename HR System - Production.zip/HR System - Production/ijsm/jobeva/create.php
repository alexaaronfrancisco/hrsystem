<?php
require_once '../../assets/dbconfig.php';
require_once '../../assets/connection.php';
if($_POST){
$jobrating=mysql_query("select rating_id from job_rating_plan", $connection);
$countrating = mysql_num_rows($jobrating);
/*$a = 0;
$b = 0;
while ($a < $countrating){
$convalue = "val".$b;
$addval[] = $_POST[$convalue];
$a++;
$b++;
}*/
$x = 0;
$y = 0;
$addchoarr = array();
while ($x < $countrating){
$concho = "cho".$y;
$addcho = $_POST[$concho];
$addchoarr[] = $addcho;
$x++;
$y++;
//$filetxt = $_POST['getfile'];
}




$sum = array_sum($addchoarr);
$z = $sum;
$_SESSION['getthesum'] = $z;
/*
$jobrank=mysql_query("select job_id from job_classification", $connection);
$countrank = mysql_num_rows($jobrank);
$a=0;
$b=1;
while ($a < $countrank){
$jobstart=mysql_query("select start from job_classification where job_id == ".$b."", $connection);
$row2 = mysql_fetch_assoc($jobstart);
$getstart=$row2['start'];
$jobend=mysql_query("select end from job_classification where job_id == ".$b."", $connection);
$row3 = mysql_fetch_assoc($jobend);
$getend=$row3['end'];
*/
//if ($z >= $getstart && $z <= $getend){
$rankname=mysql_query("select rank from job_classification where start_range <= ".$z." AND end_range >= ".$z, $connection);
$row4 = mysql_fetch_assoc($rankname);
$getname=$row4['rank'];

$levelname=mysql_query("select level from job_classification where rank='$getname'", $connection);
$rowlevel = mysql_fetch_assoc($levelname);
$lvlname=$rowlevel['level'];

//}
//else{
//$getname="Executive";}
//$a++;
//$b++;
//}
$nametoid=mysql_query("select job_id from job_classification where rank LIKE '".$getname."'", $connection);
$row5 = mysql_fetch_assoc($nametoid);
$getid=$row5['job_id'];
$getid2 = (int)$getid;


$recpos=mysql_query("select rec_pos from job_classification where job_id=$getid", $connection);
$rowpos = mysql_fetch_assoc($recpos);
$recopos=$rowpos['rec_pos'];
	$position = $_POST['jobtitle'];
if ($recopos == ""){
	$positions = $position;}
	else {
	$positions = $recopos.", ".$position;
	}
/*
$file = str_replace("blank","\r\n", $filetxt);
$file_sql=mysql_query("select file from job_rating_ans where job_id=$getid2 order by job_title_id DESC", $connection);
$rowfile = mysql_fetch_assoc($file_sql);
$countrow = count($rowfile);
$file_entry =$rowfile['file'];
if (!file_exists('../jobevaansfile/'.$getname)) {
    mkdir('../jobevaansfile/'.$getname, 0777, true);}
	
	if ($countrow == 0){
$getcount ="0";}
else{
$getcount= str_replace("_answer.txt","", $file_entry);}
$count = (int)$getcount;
$count++;
if($countrow != 0){
$chgfile = $count."_answer.txt";
$myfile = fopen("../jobevaansfile/".$getname."/".$chgfile, "w") or die("Unable to open file!");
fwrite($myfile, $file);
fclose($myfile);
}	
*/

	

		
		try{
			
			$stmt = $db_con->prepare("INSERT INTO job_rating_ans(job_id, job_title, total) VALUES(:id, :tle, :tot)");
			$stmt->bindParam(":id", $getid);
			$stmt->bindParam(":tle", $position);
			$stmt->bindParam(":tot", $z);
									
			if($stmt->execute())
			{		
			$trail = mysql_query("INSERT INTO trail (type, per_action, description, emp_id) VALUES ('Job Evaluation', 'ADDED', '$position to $getname | Total Points:$z', '$user_check')", $connection);
			$addpos = mysql_query("UPDATE job_classification SET rec_pos='$positions' WHERE job_id=$getid", $connection);
			echo "Saving... $lvlname";
			}
			else{
				echo "Query Problem";
			}	
		}
		catch(PDOException $e){
			echo $e->getMessage();
		}
		}
?>