<?php 
require_once '../../assets/dbconfig.php';
require_once '../../assets/connection.php';
if(isset($_GET['pos']))
{
$pos = $_GET['pos'];
$sum = $_GET['sum'];
$val = $_GET['val'];
}
?>
<script>
$(document).ready(function() {  
 	var val = <?php echo $val; ?>;
	alert(val);
	$("#page-content-wrapper").load('index.php?kuha='+val);

});


</script>
