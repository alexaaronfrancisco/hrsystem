<?php
include('../../session.php');
if ($login_session != "admin")
{
header("Location: HTTP/1.1 401 Unauthorized Access");
}
$name_sql=mysql_query("select fname from emp_personal_data where emp_id='$user_check'", $connection);
$row2 = mysql_fetch_assoc($name_sql);
$getthename =$row2['fname'];

$kuha = 0;
if ($_GET){
$kuhaget = $_GET['kuha'];
$kuha = (int)$kuhaget;
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<title>Job Evaluation</title>
<!--<link href="bootstrap/css/bootstrap.min.css" rel="stylesheet" media="screen">-->
<!--<link href="bootstrap/css/bootstrap-theme.min.css" rel="stylesheet" media="screen"> -->
  <link rel="shortcut icon" href="../../img/logo.ico" type="image/x-icon">
<link href="../../assets/datatables.min.css" rel="stylesheet" type="text/css">
    <link href="../../bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css"/>
	    <link href="../../bootstrap/css/sidebar.css" rel="stylesheet" type="text/css"/>
<script src="../../bootstrap/js/bootstrap.js"></script>
<script src="../../bootstrap/js/jquery-1.12.0.js"></script>
<script src="../../bootstrap/js/bootstrap.min.js"></script>
<script type="text/javascript">

$(document).ready(function(){
    $('[data-toggle="tooltip"]').tooltip();
});

$(window).load(function() {
	$(".loader").fadeOut("slow");
})
 $(document).ready(function(){
    var hContent = $("body").height(); // get the height of your content
    var hWindow = $(window).height();  // get the height of the visitor's browser window

    // if the height of your content is bigger than the height of the 
    // browser window, we have a scroll bar
    if(hContent>hWindow) {
	$('.footer').css("position","absolute");
        return true;    
    }

    return false;
});
</script>
<style>
@import url('https://fonts.googleapis.com/css?family=Tauri');
body{font-family: 'Tauri', sans-serif;}
.title{font-size:18px;
padding-bottom: 20px;
color: #0066CC;
width:100%;}


  @page { size: Portrait; }

#printme {
  display: none;
}


@media print {
#hideprint{
display:none;}
#hidesal{
display:none;}

.sidebar-nav, #footer{
display:none;}

#wrapper.toggled, #sidebar-wrapper{
padding-left:0px;
}

#page-content-wrapper{
top:0;
}
	
	#printthis, #printthis * {
	visibility: visible;
  }
  .print:last-child {
     page-break-after: auto;
}
	
@page { size: Portrait; }
}

#result{
	display: none;
	margin-left: 70px;
	position: fixed;
	top: 50px;
	width: 68%;
	padding:20px;
	z-index:99999;
}

.drop {
font-size:12px;
background-color:#111;
display:none;
 text-indent: 30px;
    line-height: 30px;
}

.drop2 {
font-size:12px;
background-color:#111;
display:none;
 text-indent: 30px;
    line-height: 30px;
}

.drop3 {
font-size:12px;
background-color:#111;
display:none;
 text-indent: 30px;
    line-height: 30px;
}

.drop4 {
font-size:12px;
background-color:#111;
display:none;
 text-indent: 30px;
    line-height: 30px;
}

.drop5 {
font-size:12px;
background-color:#111;
display:none;
 text-indent: 30px;
    line-height: 30px;
}

.footer {
z-index:2;
width:100%;
position:fixed;
display: block;
  right: 0;
  bottom: 0;
  left: 0;
  font-size:12px;
  padding: 1rem;
  background-color: #efefef;
  text-align: right;}
  
  .loader {
	position: fixed;
	left: 0px;
	top: 0px;
	width: 100%;
	height: 100%;
	z-index: 9999;
	background: url('../../img/loading.gif') 50% 50% no-repeat rgb(249,249,249);
	opacity: .5;
}

  .icon {
  float:left;
  display:block;
  padding-top: 10px;
  }
  
  .back {
  display:none;
  border:none;
  }
  .add {
  border:none;
border-radius: 100%;
padding-top:15px;
padding-bottom: 17px;
padding-left: 17px;
padding-right: 15px;
font-size:24px;

}
.add:focus{
outline: 0px;
}
.sidebar-brand{
background-color:#FFFFFF;
}
.sidebar-brand img {
width: 225px;
height:57px;

}
#salary {
padding-left:10px;
padding-right:10px;
}

#optradio{
width:15px;
height:15px;
}

.radio{
padding-top:10px;
padding-left:50px;}

.square {
background-color: #FFFFFF;
margin-top:20px;
-webkit-box-shadow: 0px 0px 2px rgba(50, 50, 50, 0.31);
    -moz-box-shadow:    0px 0px 5px rgba(50, 50, 50, 0.31);
    box-shadow:         0px 0px 10px rgba(50, 50, 50, 0.31);
padding:20px;

 }
#jobtitle {
padding-left:10px;
padding-right:10px;
padding-top:10px;
padding-bottom:10px;
font-size:16px;
 }
  @media only screen and (max-width: 768px) 
{ 
.footer {
margin-top: 50px;
width:100%;
position: relative;
font-size: 10px;
background-color: #fff;
}

.sidebar-brand img {
width: 190px;
height:45px;

}
#result{
	top: 75px;
	margin-left: 0;
	width:70%
}
#footer{
display:none;
visibility:hidden;
}
}

</style>


</head>

<body>
<!------------------------------------------->
<div class="loader"></div>
      

        <!-- Sidebar -->
		<div class="stat" style="position:static;">
		<div class="sticktop" style="top:0; display:block; position: fixed; z-index:1000; right:0; left:0;">
		<div id="hidesal">
		<div class="sidebar-brand">
                    <a href="#">
                       <img src="../../img/logo.jpg"> 
                    </a>
                </div>
				<div class="drops">
		<div class="dropdowntogs">
                <a href="#"><span class="glyphicon glyphicon-user"> </span> &nbsp;&nbsp; <b>Admin</b> <?php echo $getthename ?></a></div>
				<div class="dropmenu">
<!---				<a href="#"><span class="glyphicon glyphicon-wrench"> </span> Edit Profile</a><div></div>--->
				<a href="../../chgpass.php"><span class="glyphicon glyphicon-lock"> </span> Change Password</a>
				<hr></hr>
				<a href="../../logout.php"><span class="glyphicon glyphicon-log-out"> </span> Log-out</a>
				</div>
				</div>							

		<div class="toggles"><a href="#menu-toggle" id="menu-toggle"><span class="glyphicon glyphicon-menu-hamburger"></span></a></div>       
                </div>
				</div>
				 <div id="wrapper">
<div id="sidebar-wrapper">
            <ul class="sidebar-nav">
			<div class="menunav"></div>
				<li>
				<a href="../../home/"><span class="glyphicon glyphicon-home icon"></span> Home</a>
                </li>
                <li>
				<div class="main">
                    <a href="#"><i class="glyphicon glyphicon-cog icon"></i> Maintenance</a></div>
					<div class="drop">
					<a href="../../maintenance/emperdata">Employee Personal Data</a>
					<a href="../../maintenance/empjobdata">Employee Job Data</a>
					<a href="../../maintenance/emprater">Employee Rater</a>
					</div>
					</li>
					<li>
				<div class="ijsm">
                    <a href="#" class="active"><i class="glyphicon glyphicon-briefcase icon"></i>IJSM</a></div>
					<div class="drop2" style="display:block;">
					<a href="../../ijsm/jobclass">Job Classification</a>
					<a href="../../ijsm/jobrating">Job Rating Plan</a>
					<a href="" class="active" style="background-color:#fff; color:#000000;">Job Evaluation</a>
					<a href="../../ijsm/salstruct">Salary Structure</a>
					<a href="../../ijsm/salanal">Salary Analysis</a>
					</div>
					</li>
					<li>
				<div class="opms">
                    <a href="#"><i class="glyphicon glyphicon-list-alt icon"></i>OPMS</a></div>
					<div class="drop3">
					<a href="../../opms/wpg">Manage WPG</a>
					<a href="../../opms/wperfpercent">Manage WPA</a>
					<a href="../../opms/orgper">Manage OPMS</a>
					<a href="../../opms/getper">OPMS Form</a>
					</div>
                </li>
                <li>
								<div class="rprt">
                    <a href="#"><i class="glyphicon glyphicon-duplicate icon"></i>Report</a></div>
											
									<div class="drop4">
					<a href="../../rprt/ern">E.R.N.</a>
					<a href="../../rprt/tabul">OPMS Tabulation</a>
                    <a href="../../rprt/percat">Indv. Performance Category</a>
					<a href="../../rprt/orgcat">Org. Performance Category</a>
				</div>
                </li>
                <li>
				<div class="util">
                    <a href="#"><i class="glyphicon glyphicon-wrench icon"></i>Utilities</a></div>
					<div class="drop5">
					<a href="../../util/trail">Audit Trail</a>
					<a href="../../util/showinact">Show inactive</a>
					<a href="../../util/localbup">Data Back-up</a>

					</div>
                </li>
            </ul>							
			<div class="move" style="position:relative; z-index:-1; min-height:600px;">				
														<div id="footer" style=" position:absolute; margin-left:10px; left:0; bottom:0; text-align:center; font-size:10px;  width:200px; margin-right:10px; color:#CCCCCC; ">
				<b>Copyright </b> <span class="glyphicon glyphicon-copyright-mark"></span> <b><?php echo date(' Y')?></b> All Rights Reserved. <br /> Confluent Management Inc. <br /> <b>Version</b> 2.0
				</div>			</div>
							
        </div>			
        <!-- /#sidebar-wrapper -->


        <!-- Page Content -->
<!--table--->				

        <div id="page-content-wrapper">
            <div class="container-fluid">
	
<h2>Job Evaluation </h2><div id="position" class="label label-warning" style="font-size:16px; margin-bottom:20px;"></div><hr />

   <div id="result">
    <!-- here message will be displayed -->
	</div>
	 <div class="content-loader">
	 		<div id="hidesal">
 <form id='jbrate' name="jbrate" action="" method="post">
  <p><input type="text" name="jobtitle" id="jobtitle" value="" style="width:30%;" placeholder="Enter Job Title" maxlength="50" required/>  
  <button class="btn btn-primary" id="start" disabled="disabled"  data-toggle="tooltip" data-placement="right" title="Start" style="border-radius:100%; padding:10px; padding-top:6px; font-size:24px;" ><span class="glyphicon glyphicon-arrow-right"></span></button> </p>
</div> 

<?php	
require_once '../../assets/dbconfig.php';

$count_sql=mysql_query("select * from job_rating_plan", $connection);
$row5 = mysql_num_rows($count_sql);
$b = 0;
$a = 1;
$z = 0;
while ($b < $row5){
$rating_id = $a;
//category
$cat_sql=mysql_query("select category from job_rating_plan where rating_id='$rating_id'", $connection);
$row6 = mysql_fetch_assoc($cat_sql);
$cat_entry =$row6['category'];
$convert_cat=explode(": ",$cat_entry);
//sub-category
$subcat_sql=mysql_query("select sub_category from job_rating_plan where rating_id='$rating_id'", $connection);
$row7 = mysql_fetch_assoc($subcat_sql);
$subcat_entry =$row7['sub_category'];
if ($subcat_entry == ""){
$convert_subcat = array(" "," ");}
else{
$convert_subcat=explode(": ",$subcat_entry);}
//tanong
$tanong_sql=mysql_query("select questions from job_rating_plan where rating_id='$rating_id'", $connection);
$row8 = mysql_fetch_assoc($tanong_sql);
$tanong_entry =$row8['questions'];
if ($tanong_entry == ""){
$convert_tanong = array(" "," ");
$space = "";}
else{
$convert_tanong=explode(": ",$tanong_entry);
$space = "<br>";}
//choices
$ques_sql=mysql_query("select choices from job_rating_plan where rating_id='$rating_id'", $connection);
$row3 = mysql_fetch_assoc($ques_sql);
$ques_entry =$row3['choices'];
$convert_ques=explode(" + ",$ques_entry);
//values
$ques_val=mysql_query("select value from job_rating_plan where rating_id='$rating_id'", $connection);
$row4 = mysql_fetch_assoc($ques_val);
$val_entry =$row4['value'];
$convert_val=explode(", ",$val_entry);
$countarr = count($convert_ques);
$x = 0;
$y = 0;
$c = 0;	
?>
<div id="square<?php echo $b; ?>" class="square" style="display:none">
<h5 class="label label-danger"><?php echo $convert_cat[0];?></h5>
<h5><?php echo $convert_cat[1];?></h5>
<h5 class="text text-info" style="padding-left:30px;"><?php echo $convert_subcat[0];?></h5>
<h5 style="padding-left:30px;"><?php echo $convert_subcat[1];?></h5>
<?php echo $space; ?>
<h4 class="text text-primary"><?php echo $convert_tanong[0];?></h4>
<h5><?php echo $convert_tanong[1];?></h5>
<?php
		 while ($x < $countarr){
			
		?>
		
	
				  <div class="radio">
<label><input type="radio" id='<?php echo $z; ?>' name='cho<?php echo $z; ?>' placeholder='<?php echo $convert_ques[$y]; ?>' value='<?php echo $convert_val[$y]; ?>' required /><?php echo $convert_ques[$y];?></label>
</div>
<?php 

$x++;
$y++;
}
$z++;
if ($b != 0){?>
<button class="btn btn-default" name="baliklaman" data-toggle="tooltip" data-placement="bottom" title="Previous Question" value="#square<?php echo $b;?>" id="#square<?php echo $c;?>">Previous</button>
<?php 
echo '<script>$("#square'.$b.'").hide();</script>';}
$a++;
$b++;

if ($b == $row5){?>
<button class="btn btn-primary" name="tapos" data-toggle="tooltip" data-placement="right" title="Finish Evaluating"  disabled="disabled" value="#square<?php echo $b;?>" id="#square<?php echo $c;?>">Finish</button>
</div>
<?php } else { ?>
<button class="btn btn-primary" name="pasalaman" data-toggle="tooltip" data-placement="right" title="Next Question"  disabled="disabled" value="#square<?php echo $b;?>" id="#square<?php echo $c;?>">Next</button>

</div>
<?php 
} $c++;
}
?>

</form>

<!--<button class="btn btn-primary" name="tapos" data-toggle="tooltip" data-placement="right" title="Finish Evaluating" >CLICK FINISH </button>-->
<div id="fullprint" style="display:none;">
<center><img src="../../img/logo.jpg" width="180px" height="48px" /></center>
<center style="color:#0000FF; font-size:20px;">JOB EVALUATION RESULT</center></span><br />
<div id="quesprint"></div>
<div class="row">
<div class="col-md-8">
Date : <?php echo date('M d, Y | l');?>
</div>
<div class="col-md-4">
Total Points : <c id="totval"></c>
</div>
</div>
<h4>Job Title : <c id="positions"></c></h4>
<h3>
<?php 
//$levelidget = $_POST['val'];
//$levelid = (int)$levelidget;
//$levelidget = $putid;
//$levelidstr = "$levelidget";
//$levelid = (int)$levelidstr;
//$val1 = $_SESSION['getthesum'];
//$rankname=mysql_query("select level from job_classification where job_id=$kuha", $connection);
//$row4 = mysql_fetch_assoc($rankname);
//$getname=$row4['level'];
?>
<table class='table table-bordered table-hover table-striped'><tbody><tr><td>
Job Level : <c id="getname"></c></h3></td></tr></tbody></table>
</div>
<div id="summaryprint" style="display:none;">
<center><img src="../../img/logo.jpg" width="180px" height="48px" /></center>
<center style="color:#0000FF; font-size:20px;">JOB EVALUATION RESULT</center></span><br />
<div class="row">
<div class="col-md-8">
Date : <?php echo date('M d, Y | l');?>
</div>
<div class="col-md-4">
Total Points :  <c id="totval2"></c>
</div>
</div>
<h4>Job Title :  <c id="positionss"></c></h4>
<?php 
//$levelid2 = (int)$levelidget2;
//$levelidget2 = $putid;
//$levelidstr2 = "$levelidget2";
//$levelid2 = (int)$levelidstr2;
//$val2 = $_SESSION['getthesum'];
//$rankname22=mysql_query("select level from job_classification where job_id=$kuha", $connection);
//$row22 = mysql_fetch_assoc($rankname22);
//$getname22=$row22['level'];
?>
<h3><table class='table table-bordered table-hover table-striped'><tbody><tr><td>
Job Level : <c id="getname2"></c> </h3></td></tr></tbody></table>
</div>
<div id="totalval" style="display:none;"></div>
<button class="btn btn-primary" id="print" style="display:none;" data-toggle="tooltip" data-placement="right" title="Print Result"><span class="glyphicon glyphicon-print"></span> Print</button>


<!-- Modal -->

  <div class="modal fade" id="modalprint" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h3 class="modal-title text-primary"><span class="glyphicon glyphicon-print"> </span> Print Result</h3>
        </div>
        <div class="modal-body">
		<br />
          <span>Do you want to print it in full version?</span>
        </div>
        <div class="modal-footer">
		  <button type="button" id="no" value="no" onclick="printDiv(no)" class="btn btn-default" > No </button>
		  <button type="button" id="yes" value="yes" autofocus class="btn btn-primary"> Yes </button>
        </div>
      </div>
      
    </div>
  </div>



<script>
 $("#menu-toggle").click(function(e) {
        e.preventDefault();
        $("#wrapper").toggleClass("toggled");
    });	    
	    $(".main").click(function(e) {
        e.preventDefault();
        $(".drop").slideToggle();
		$(".drop2").slideUp();
		$(".drop3").slideUp();
		$(".drop4").slideUp();
		$(".drop5").slideUp();
    });
		$(".ijsm").click(function(e) {
        e.preventDefault();
        $(".drop2").slideToggle();
		$(".drop").slideUp();
		$(".drop3").slideUp();
		$(".drop4").slideUp();
		$(".drop5").slideUp();
    });
	    $(".opms").click(function(e) {
        e.preventDefault();
        $(".drop3").slideToggle();
		$(".drop").slideUp();
		$(".drop2").slideUp();
		$(".drop4").slideUp();
		$(".drop5").slideUp();
    });
		$(".rprt").click(function(e) {
        e.preventDefault();
        $(".drop4").slideToggle();
		$(".drop").slideUp();
		$(".drop2").slideUp();
		$(".drop3").slideUp();
		$(".drop5").slideUp();
    });
		$(".util").click(function(e) {
        e.preventDefault();
        $(".drop5").slideToggle();
		$(".drop").slideUp();
		$(".drop2").slideUp();
		$(".drop3").slideUp();
		$(".drop4").slideUp();
    });	   
	$(".dropdowntogs").click(function(e) {
        e.preventDefault();
        $(".dropmenu").toggle();
    });
	$(document).click(function(e) {
  if ( $(e.target).closest('.dropdowntogs').length === 0 ) {
    // hide menu here
	$(".dropmenu").hide();
  }
}); 
<!---tapos---->
// $("button[name='tapos']").click(function(){
//});
var countrow = <?php echo $row5; ?>;
		 $('button[name="pasalaman"]').attr('disabled', 'disabled');
	//	 $('button[name="tapos"]').attr('disabled', 'disabled');
var resetattr = 0;
var fulllast =  new Array('NICE','WOW');
var vallast =  new Array(0,1);
var fullprint =  new Array();
var totalval =  new Array();



<!---- AJAX CREATE RECORD ---->
    $("button[name='tapos']").click(function(e){
	e.preventDefault()
	 var last = fulllast[fulllast.length - 1];
 var lastnum = vallast[vallast.length - 1];
fullprint.push(last);
totalval.push(lastnum);
var jobtitle = $("#jobtitle").val();
$("#positions").text(""+jobtitle+"");
$("#positionss").text(""+jobtitle+"");
var i;
var a=1;
var text = "<table class='table table-bordered table-hover table-striped'><tbody>";
for (i = 0; i < fullprint.length; i++) {
    text += "<tr><td>"+a+"</td><td>" + fullprint[i] + "</td></tr>";
	a++;
}
text += "</tbody></table>";
var myTotal = 0;  // Variable to hold your total
for(var j = 0; j < totalval.length; j++) {
    myTotal += totalval[j]; // Iterate over your first array and then grab the second element add the values up
}
var sum = totalval.reduce(function(pv, cv) { return parseInt(pv) + parseInt(cv); }, 0);
//$("#quesprint").text(text);
$("#totval").text(sum);
$("#totval2").text(sum);
document.getElementById("quesprint").innerHTML = text;
//document.getElementById("totval").innerHTML = sum;
//document.getElementById("totval2").innerHTML = sum;
		$.ajax({
            type: "POST",
            url: "create.php", //process to add
            data: $('form#jbrate').serialize(),					
            success: function(data){
			var dataname = data.split("Saving... ").pop();
			var getdata = data.substring(0, 9);
		//	var result = data.split("-").pop();		
//			$("#page-content-wrapper").load('print.php?val='+dataid+'&pos='+jobtitle+'&sum='+sum);
			$("#getname").html(dataname);
			$("#getname2").html(dataname);
			$(".loader").fadeIn();
			$("#result").css('display','block') 
			$("#result").fadeIn('slow') 
		$("#result").html('<div class="alert alert-success"><span class="glyphicon glyphicon-ok">&nbsp;</span>'+getdata+'</div>');
				     setTimeout(function(){
        $("#result").fadeOut();
    }, 2000); 

	setTimeout(
  function() 
  {

  $("hr").fadeIn();
  $("#print").fadeIn();
  $("#position").fadeOut();
$(".square").fadeOut();
  }, 2000);
					  setTimeout(
  function() 
  {
$(".loader").fadeOut();
  }, 2000);
  
  				  setTimeout(
  function() 
  {
$("#summaryprint").fadeIn();
  }, 2000);
   
	}		  

        });
		});

<!---Radio Button disable next---->
$("input[type='radio']").click(function(){
var idcount = $(this).attr("id");
var ansques = $(this).attr("placeholder");
var valques = $(this).attr("value");
//if($('input[type="radio"][id="'+idcount+'"').is(':checked')){
fulllast.push(ansques);
vallast.push(valques);
			$('button[name="pasalaman"]').removeAttr('disabled', 'disabled');
			$('button[name="tapos"]').removeAttr('disabled', 'disabled');
});
 $('button[name="pasalaman"]').click(function() {
var last = fulllast[fulllast.length - 1];
var lastnum = vallast[vallast.length - 1];
fullprint.push(last);
totalval.push(lastnum);
});

/*	
function getSum(total, num) {
    return total + num;
}
			$("#next"+j).click(function(){
                $("#square"+i).fadeOut('slow');
				$("#square"+j).fadeIn('slow');               
            });
*/

$(".square").hide();
$('#start').click(function() {
var position = $("#jobtitle").val();
$("#position").text(position);
$("p").fadeOut();
$("hr").fadeOut();
$("#square0").fadeIn();
});


 $('button[name="pasalaman"]').click(function() {
 $(".loader").fadeIn();
            var laman = $(this).attr("value");
            $(laman).fadeIn('');
			
					  setTimeout(
  function() 
  {
$(".loader").fadeOut();
  }, 1000);
						var lastChar = laman.split("#square").pop();
			var inclast = parseInt(lastChar)-1; 
			var laman2 = ("#square"+inclast);
			$(laman2).fadeOut('slow');
			
			$('button[name="pasalaman"]').attr('disabled', 'disabled');
			$('button[name="tapos"]').attr('disabled', 'disabled');
		});
		 $('button[name="baliklaman"]').click(function() {
		  $(".loader").fadeIn();
//            var laman = $(this).attr("id");
//            $(laman).fadeIn('');
			var laman2 = $(this).attr("value");
			var lastChar = laman2.split("#square").pop();
			var inclast = parseInt(lastChar)-1; 
			var laman = ("#square"+inclast);
			$('input[name=cho'+lastChar+']').attr('checked',false);
			$(laman2).fadeOut('slow');
				  setTimeout(
  function() 
  {
$(".loader").fadeOut();
  }, 1000);
			$(laman).fadeIn('slow');
			
					 	fullprint.pop();
			totalval.pop();
			$('button[name="pasalaman"]').removeAttr('disabled', 'disabled');
        });
				
		   var count = 0;		
		//Key uP title
		$('#jobtitle').keyup(function() {
		   if ($('#jobtitle').val() == '' || $('#jobtitle').val().length < 3) {
		   count = 1;
		   $("#jobtitle").css("border","red solid 1px");
		 $('#start').attr('disabled', 'disabled');
			}
		else {
		count = 0;
		$("#jobtitle").css("border","grey solid 1px");
		$('#start').removeAttr('disabled', 'disabled');
	}
	});
if (count = 1){
		$('#start').attr('disabled', 'disabled');}
		else{
		$('#start').removeAttr('disabled', 'disabled');}

<!----- FUNCTION PRINT ---->
$("#print").click(function() {
	 $("#modalprint").modal('show');
});

//	 $("#modalprint").modal('hide');
//var yes = $(this).val();
//function printDiv() {
//var yes = $(this).val();
//if (confirm("Do you want to print in full version?")==true){
  /*   var printContents = document.getElementById('fullprint').innerHTML;
     var originalContents = document.body.innerHTML;

     document.body.innerHTML = printContents;

     window.print();
	  document.getElementById('modalprint').style.display = 'none';
     document.body.innerHTML = originalContents;
*/
/*
  var mywindow = window.open('', 'PRINT', '');

    mywindow.document.write(document.getElementById('fullprint').innerHTML);

    mywindow.document.close(); // necessary for IE >= 10
    mywindow.focus(); // necessary for IE >= 10*/
/*
    mywindow.print();
    mywindow.close();

    return true;
	 });
$("#no").click(function() {
 $("#modalprint").modal('hide');
  var mywindow = window.open('', 'PRINT', '');

    mywindow.document.write(document.getElementById('summaryprint').innerHTML);

    mywindow.document.close(); // necessary for IE >= 10
    mywindow.focus(); // necessary for IE >= 10*/

  //  mywindow.print();
   // mywindow.close();

//    return true;
$("#yes").click(function() {
			$("#modalprint").modal("hide");
						$("#logo").removeAttr("style");
					 	$(".footer").attr("style","display:none;");
						$("#fullprint").removeAttr("style");
						$("h2").attr("style","display:none;");
						$("hr").attr("style","display:none;");
						$("#print").attr("style","display:none;");
						$(".hideprint").attr("style","display:none;");
					 	$(".hidesal").attr("style","display:none;");
						$("#summaryprint").attr("style","display:none;");
			var printit = $("#fullprint").html()
            $("#printme").html(printit);
            window.print();				
									$("#summaryprint").removeAttr("style");
									$("#print").removeAttr("style");
			$("#fullprint").attr("style","display:none;");
			$("#logo").attr("style","display:none;");
					    $("#dailysal").attr("style","display:none;");
			$(".hideprint").removeAttr("style");
			$(".footer").removeAttr("style");
						$(".hidesal").removeAttr("style");
														$("h2").removeAttr("style");
						$("hr").removeAttr("style");

						            $("#printme").html("");

});
$("#no").click(function() {
			$("#modalprint").modal("hide");
									$("h2").attr("style","display:none;");
						$("hr").attr("style","display:none;");
						$("#logo").removeAttr("style");
					    $("#dailysal").removeAttr("style");
						$("#summaryprint").removeAttr("style");
					 	$(".footer").attr("style","display:none;");
						$("#print").attr("style","display:none;");
		 				$(".hideprint").attr("style","display:none;");
					 	$(".hidesal").attr("style","display:none;");
            window.print();
									$("#print").removeAttr("style");
																		$("h2").removeAttr("style");
						$("hr").removeAttr("style");

			$("#logo").attr("style","display:none;");
					    $("#dailysal").attr("style","display:none;");
			$(".hideprint").removeAttr("style");
			$(".footer").removeAttr("style");
						$(".hidesal").removeAttr("style");

});
	
</script>

</body>
</html>