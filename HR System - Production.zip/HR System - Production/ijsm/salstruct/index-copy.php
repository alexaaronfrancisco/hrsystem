<?php
include('../../session.php');
if ($login_session != "admin")
{
header("Location: HTTP/1.1 401 Unauthorized Access");
}
$name_sql=mysql_query("select fname from emp_personal_data where emp_id='$user_check'", $connection);
$row2 = mysql_fetch_assoc($name_sql);
$getthename =$row2['fname'];

$sal_sql=mysql_query("select sal_range from emp_job_data where emp_job_id='1'", $connection);
$row3 = mysql_fetch_assoc($sal_sql);
$salrange =$row3['sal_range'];

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Salary Structure</title>
<!--<link href="bootstrap/css/bootstrap.min.css" rel="stylesheet" media="screen">-->
<!--<link href="bootstrap/css/bootstrap-theme.min.css" rel="stylesheet" media="screen"> -->
  <link rel="shortcut icon" href="../../img/logo.ico" type="image/x-icon">
<link href="../../assets/datatables.min.css" rel="stylesheet" type="text/css">
    <link href="../../bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css"/>
	    <link href="../../bootstrap/css/sidebar.css" rel="stylesheet" type="text/css"/>
<script src="../../bootstrap/js/bootstrap.js"></script>
<script src="../../bootstrap/js/jquery-1.12.0.js"></script>
<script src="../../bootstrap/js/bootstrap.min.js"></script>
<script type="text/javascript">



$(document).ready(function(){
    $('[data-toggle="tooltip"]').tooltip();   
	$('#save').hide();
});
$(document).ready(function(){
$('#edit').click(function(){
	$('#save').show();
	$('#edit').hide();
	$('#salary').removeAttr('disabled','disabled');
		  $('#yes').focus();
		  		  $('#yessave').focus();
	
});
});

$(window).load(function() {
	$(".loader").fadeOut("slow");
})

 $(document).ready(function(){
    var hContent = $("body").height(); // get the height of your content
    var hWindow = $(window).height();  // get the height of the visitor's browser window

    // if the height of your content is bigger than the height of the 
    // browser window, we have a scroll bar
    if(hContent>hWindow) {
	$('.footer').css("position","absolute");
        return true;    
    }

    return false;
});


<!----- DoC READY ------>
$(document).ready(function(){
function addCommas(nStr){
 nStr += '';
 var x = nStr.split('.');
 var x1 = x[0];
 var x2 = x.length > 1 ? '.' + x[1] : '';
 var rgx = /(\d+)(\d{3})/;
 while (rgx.test(x1)) {
  x1 = x1.replace(rgx, '$1' + ',' + '$2');
 }
 return x1 + x2;
}  
var getsal = '<?php echo $salrange;?>';
var $getsalary = parseFloat((getsal*313)/12).toFixed(2);
var $intwodecimal = parseFloat($getsalary)-.02;
var $plusrf1s2com = parseFloat(($intwodecimal*0.0375)+$intwodecimal).toFixed(2);
var $plusrf1s2 = parseFloat($plusrf1s2com);
var $plusrf1s3com = parseFloat(($plusrf1s2*0.0375)+$plusrf1s2).toFixed(2);
var $plusrf1s3 = parseFloat($plusrf1s3com);
var $plusrf1s4com = parseFloat(($plusrf1s3*0.0375)+$plusrf1s3).toFixed(2);
var $plusrf1s4 = parseFloat($plusrf1s4com);
var $plusrf1s5com = parseFloat(($plusrf1s4*0.0375)+$plusrf1s4).toFixed(2);
var $plusrf1s5 = parseFloat($plusrf1s5com);


$("#rf1s1").text(addCommas($intwodecimal));
$("#rf1s2").text(addCommas($plusrf1s2));
$("#rf1s3").text(addCommas($plusrf1s3));
$("#rf1s4").text(addCommas($plusrf1s4));
$("#rf1s5").text(addCommas($plusrf1s5));

<!---- Rank & File 2 ------>			
					
var $plusrf2s1com = parseFloat(($plusrf1s3*0.04)+$plusrf1s3).toFixed(2);
var $plusrf2s1 = parseFloat($plusrf2s1com);
var $plusrf2s2com = parseFloat(($plusrf2s1*0.05)+$plusrf2s1).toFixed(2);
var $plusrf2s2 = parseFloat($plusrf2s2com);
var $plusrf2s3com = parseFloat(($plusrf2s2*0.05)+$plusrf2s2).toFixed(2);
var $plusrf2s3 = parseFloat($plusrf2s3com);
var $plusrf2s4com = parseFloat(($plusrf2s3*0.05)+$plusrf2s3).toFixed(2);
var $plusrf2s4 = parseFloat($plusrf2s4com);
var $plusrf2s5com = parseFloat(($plusrf2s4*0.05)+$plusrf2s4).toFixed(2);
var $plusrf2s5 = parseFloat($plusrf2s5com);


$("#rf2s1").text(addCommas($plusrf2s1));
$("#rf2s2").text(addCommas($plusrf2s2));
$("#rf2s3").text(addCommas($plusrf2s3));
$("#rf2s4").text(addCommas($plusrf2s4));
$("#rf2s5").text(addCommas($plusrf2s5));

<!---- Staff 1 ------>			
					
var $pluss1s1com = parseFloat(($plusrf2s3*0.06)+$plusrf2s3).toFixed(2);
var $pluss1s1 = parseFloat($pluss1s1com);
var $pluss1s2com = parseFloat(($pluss1s1*0.05)+$pluss1s1).toFixed(2);
var $pluss1s2 = parseFloat($pluss1s2com);
var $pluss1s3com = parseFloat(($pluss1s2*0.05)+$pluss1s2).toFixed(2);
var $pluss1s3 = parseFloat($pluss1s3com);
var $pluss1s4com = parseFloat(($pluss1s3*0.05)+$pluss1s3).toFixed(2);
var $pluss1s4 = parseFloat($pluss1s4com);
var $pluss1s5com = parseFloat(($pluss1s4*0.05)+$pluss1s4).toFixed(2);
var $pluss1s5 = parseFloat($pluss1s5com);


$("#s1s1").text(addCommas($pluss1s1));
$("#s1s2").text(addCommas($pluss1s2));
$("#s1s3").text(addCommas($pluss1s3));
$("#s1s4").text(addCommas($pluss1s4));
$("#s1s5").text(addCommas($pluss1s5));

<!---- Staff 2 ------>			
					
var $pluss2s1com = parseFloat(($pluss1s3*0.06)+$pluss1s3).toFixed(2);
var $pluss2s1 = parseFloat($pluss2s1com);
var $pluss2s2com = parseFloat(($pluss2s1*0.05)+$pluss2s1).toFixed(2);
var $pluss2s2 = parseFloat($pluss2s2com);
var $pluss2s3com = parseFloat(($pluss2s2*0.05)+$pluss2s2).toFixed(2);
var $pluss2s3 = parseFloat($pluss2s3com);
var $pluss2s4com = parseFloat(($pluss2s3*0.05)+$pluss2s3).toFixed(2);
var $pluss2s4 = parseFloat($pluss2s4com);
var $pluss2s5com = parseFloat(($pluss2s4*0.05)+$pluss2s4).toFixed(2);
var $pluss2s5 = parseFloat($pluss2s5com);


$("#s2s1").text(addCommas($pluss2s1));
$("#s2s2").text(addCommas($pluss2s2));
$("#s2s3").text(addCommas($pluss2s3));
$("#s2s4").text(addCommas($pluss2s4));
$("#s2s5").text(addCommas($pluss2s5));

<!---- Professional / Specialist ------>			
					
var $plusps1s1com = parseFloat(($pluss2s3*0.08)+$pluss2s3).toFixed(2);
var $plusps1s1 = parseFloat($plusps1s1com);
var $plusps1s2com = parseFloat(($plusps1s1*0.05)+$plusps1s1).toFixed(2);
var $plusps1s2 = parseFloat($plusps1s2com);
var $plusps1s3com = parseFloat(($plusps1s2*0.05)+$plusps1s2).toFixed(2);
var $plusps1s3 = parseFloat($plusps1s3com);
var $plusps1s4com = parseFloat(($plusps1s3*0.05)+$plusps1s3).toFixed(2);
var $plusps1s4 = parseFloat($plusps1s4com);
var $plusps1s5com = parseFloat(($plusps1s4*0.05)+$plusps1s4).toFixed(2);
var $plusps1s5 = parseFloat($plusps1s5com);


$("#ps1s1").text(addCommas($plusps1s1));
$("#ps1s2").text(addCommas($plusps1s2));
$("#ps1s3").text(addCommas($plusps1s3));
$("#ps1s4").text(addCommas($plusps1s4));
$("#ps1s5").text(addCommas($plusps1s5));

<!---- Section Head I ------>			
					
var $plussh1s1com = parseFloat(($plusps1s3*0.08)+$plusps1s3).toFixed(2);
var $plussh1s1 = parseFloat($plussh1s1com);
var $plussh1s2com = parseFloat(($plussh1s1*0.05)+$plussh1s1).toFixed(2);
var $plussh1s2 = parseFloat($plussh1s2com);
var $plussh1s3com = parseFloat(($plussh1s2*0.05)+$plussh1s2).toFixed(2);
var $plussh1s3 = parseFloat($plussh1s3com);
var $plussh1s4com = parseFloat(($plussh1s3*0.05)+$plussh1s3).toFixed(2);
var $plussh1s4 = parseFloat($plussh1s4com);
var $plussh1s5com = parseFloat(($plussh1s4*0.05)+$plussh1s4).toFixed(2);
var $plussh1s5 = parseFloat($plussh1s5com);


$("#sh1s1").text(addCommas($plussh1s1));
$("#sh1s2").text(addCommas($plussh1s2));
$("#sh1s3").text(addCommas($plussh1s3));
$("#sh1s4").text(addCommas($plussh1s4));
$("#sh1s5").text(addCommas($plussh1s5));

<!---- Section Head II ------>			
					
var $plussh2s1com = parseFloat(($plussh1s3*0.08)+$plussh1s3).toFixed(2);
var $plussh2s1 = parseFloat($plussh2s1com);
var $plussh2s2com = parseFloat(($plussh2s1*0.05)+$plussh2s1).toFixed(2);
var $plussh2s2 = parseFloat($plussh2s2com);
var $plussh2s3com = parseFloat(($plussh2s2*0.05)+$plussh2s2).toFixed(2);
var $plussh2s3 = parseFloat($plussh2s3com);
var $plussh2s4com = parseFloat(($plussh2s3*0.05)+$plussh2s3).toFixed(2);
var $plussh2s4 = parseFloat($plussh2s4com);
var $plussh2s5com = parseFloat(($plussh2s4*0.05)+$plussh2s4).toFixed(2);
var $plussh2s5 = parseFloat($plussh2s5com);


$("#sh2s1").text(addCommas($plussh2s1));
$("#sh2s2").text(addCommas($plussh2s2));
$("#sh2s3").text(addCommas($plussh2s3));
$("#sh2s4").text(addCommas($plussh2s4));
$("#sh2s5").text(addCommas($plussh2s5));

<!---- Department Head I ------>			
					
var $plusdh1s1com = parseFloat(($plussh2s3*0.10)+$plussh2s3).toFixed(2);
var $plusdh1s1 = parseFloat($plusdh1s1com);
var $plusdh1s2com = parseFloat(($plusdh1s1*0.05)+$plusdh1s1).toFixed(2);
var $plusdh1s2 = parseFloat($plusdh1s2com);
var $plusdh1s3com = parseFloat(($plusdh1s2*0.05)+$plusdh1s2).toFixed(2);
var $plusdh1s3 = parseFloat($plusdh1s3com);
var $plusdh1s4com = parseFloat(($plusdh1s3*0.05)+$plusdh1s3).toFixed(2);
var $plusdh1s4 = parseFloat($plusdh1s4com);
var $plusdh1s5com = parseFloat(($plusdh1s4*0.05)+$plusdh1s4).toFixed(2);
var $plusdh1s5 = parseFloat($plusdh1s5com);


$("#dh1s1").text(addCommas($plusdh1s1));
$("#dh1s2").text(addCommas($plusdh1s2));
$("#dh1s3").text(addCommas($plusdh1s3));
$("#dh1s4").text(addCommas($plusdh1s4));
$("#dh1s5").text(addCommas($plusdh1s5));

<!---- Department Head II ------>			
					
var $plusdh2s1com = parseFloat(($plusdh1s3*0.10)+$plusdh1s3).toFixed(2);
var $plusdh2s1 = parseFloat($plusdh2s1com);
var $plusdh2s2com = parseFloat(($plusdh2s1*0.05)+$plusdh2s1).toFixed(2);
var $plusdh2s2 = parseFloat($plusdh2s2com);
var $plusdh2s3com = parseFloat(($plusdh2s2*0.05)+$plusdh2s2).toFixed(2);
var $plusdh2s3 = parseFloat($plusdh2s3com);
var $plusdh2s4com = parseFloat(($plusdh2s3*0.05)+$plusdh2s3).toFixed(2);
var $plusdh2s4 = parseFloat($plusdh2s4com);
var $plusdh2s5com = parseFloat(($plusdh2s4*0.05)+$plusdh2s4).toFixed(2);
var $plusdh2s5 = parseFloat($plusdh2s5com);


$("#dh2s1").text(addCommas($plusdh2s1));
$("#dh2s2").text(addCommas($plusdh2s2));
$("#dh2s3").text(addCommas($plusdh2s3));
$("#dh2s4").text(addCommas($plusdh2s4));
$("#dh2s5").text(addCommas($plusdh2s5));

<!---- Group Head I ------>			
					
var $plusgh1s1com = parseFloat(($plusdh2s3*0.12)+$plusdh2s3).toFixed(2);
var $plusgh1s1 = parseFloat($plusgh1s1com);
var $plusgh1s2com = parseFloat(($plusgh1s1*0.05)+$plusgh1s1).toFixed(2);
var $plusgh1s2 = parseFloat($plusgh1s2com);
var $plusgh1s3com = parseFloat(($plusgh1s2*0.05)+$plusgh1s2).toFixed(2);
var $plusgh1s3 = parseFloat($plusgh1s3com);
var $plusgh1s4com = parseFloat(($plusgh1s3*0.05)+$plusgh1s3).toFixed(2);
var $plusgh1s4 = parseFloat($plusgh1s4com);
var $plusgh1s5com = parseFloat(($plusgh1s4*0.05)+$plusgh1s4).toFixed(2);
var $plusgh1s5 = parseFloat($plusgh1s5com);


$("#gh1s1").text(addCommas($plusgh1s1));
$("#gh1s2").text(addCommas($plusgh1s2));
$("#gh1s3").text(addCommas($plusgh1s3));
$("#gh1s4").text(addCommas($plusgh1s4));
$("#gh1s5").text(addCommas($plusgh1s5));

<!---- Group Head II ------>			
					
var $plusgh2s1com = parseFloat(($plusgh1s3*0.12)+$plusgh1s3).toFixed(2);
var $plusgh2s1 = parseFloat($plusgh2s1com);
var $plusgh2s2com = parseFloat(($plusgh2s1*0.05)+$plusgh2s1).toFixed(2);
var $plusgh2s2 = parseFloat($plusgh2s2com);
var $plusgh2s3com = parseFloat(($plusgh2s2*0.05)+$plusgh2s2).toFixed(2);
var $plusgh2s3 = parseFloat($plusgh2s3com);
var $plusgh2s4com = parseFloat(($plusgh2s3*0.05)+$plusgh2s3).toFixed(2);
var $plusgh2s4 = parseFloat($plusgh2s4com);
var $plusgh2s5com = parseFloat(($plusgh2s4*0.05)+$plusgh2s4).toFixed(2);
var $plusgh2s5 = parseFloat($plusgh2s5com);


$("#gh2s1").text(addCommas($plusgh2s1));
$("#gh2s2").text(addCommas($plusgh2s2));
$("#gh2s3").text(addCommas($plusgh2s3));
$("#gh2s4").text(addCommas($plusgh2s4));
$("#gh2s5").text(addCommas($plusgh2s5));

<!---- Executive I ------>			
					
var $pluse1s1com = parseFloat(($plusgh2s3*0.15)+$plusgh2s3).toFixed(2);
var $pluse1s1 = parseFloat($pluse1s1com);
var $pluse1s2com = parseFloat(($pluse1s1*0.05)+$pluse1s1).toFixed(2);
var $pluse1s2 = parseFloat($pluse1s2com);
var $pluse1s3com = parseFloat(($pluse1s2*0.05)+$pluse1s2).toFixed(2);
var $pluse1s3 = parseFloat($pluse1s3com);
var $pluse1s4com = parseFloat(($pluse1s3*0.05)+$pluse1s3).toFixed(2);
var $pluse1s4 = parseFloat($pluse1s4com);
var $pluse1s5com = parseFloat(($pluse1s4*0.05)+$pluse1s4).toFixed(2);
var $pluse1s5 = parseFloat($pluse1s5com);


$("#e1s1").text(addCommas($pluse1s1));
$("#e1s2").text(addCommas($pluse1s2));
$("#e1s3").text(addCommas($pluse1s3));
$("#e1s4").text(addCommas($pluse1s4));
$("#e1s5").text(addCommas($pluse1s5));

<!---- Exexutive II ------>			
					
var $pluse2s1com = parseFloat(($pluse1s3*0.15)+$pluse1s3).toFixed(2);
var $pluse2s1 = parseFloat($pluse2s1com);
var $pluse2s2com = parseFloat(($pluse2s1*0.05)+$pluse2s1).toFixed(2);
var $pluse2s2 = parseFloat($pluse2s2com);
var $pluse2s3com = parseFloat(($pluse2s2*0.05)+$pluse2s2).toFixed(2);
var $pluse2s3 = parseFloat($pluse2s3com);
var $pluse2s4com = parseFloat(($pluse2s3*0.05)+$pluse2s3).toFixed(2);
var $pluse2s4 = parseFloat($pluse2s4com);
var $pluse2s5com = parseFloat(($pluse2s4*0.05)+$pluse2s4).toFixed(2);
var $pluse2s5 = parseFloat($pluse2s5com);


$("#e2s1").text(addCommas($pluse2s1));
$("#e2s2").text(addCommas($pluse2s2));
$("#e2s3").text(addCommas($pluse2s3));
$("#e2s4").text(addCommas($pluse2s4));
$("#e2s5").text(addCommas($pluse2s5));

<!---- Executive III ------>			
					
var $pluse3s1com = parseFloat(($pluse2s3*0.15)+$pluse2s3).toFixed(2);
var $pluse3s1 = parseFloat($pluse3s1com);
var $pluse3s2com = parseFloat(($pluse3s1*0.05)+$pluse3s1).toFixed(2);
var $pluse3s2 = parseFloat($pluse3s2com);
var $pluse3s3com = parseFloat(($pluse3s2*0.05)+$pluse3s2).toFixed(2);
var $pluse3s3 = parseFloat($pluse3s3com);
var $pluse3s4com = parseFloat(($pluse3s3*0.05)+$pluse3s3).toFixed(2);
var $pluse3s4 = parseFloat($pluse3s4com);
var $pluse3s5com = parseFloat(($pluse3s4*0.05)+$pluse3s4).toFixed(2);
var $pluse3s5 = parseFloat($pluse3s5com);


$("#e3s1").text(addCommas($pluse3s1));
$("#e3s2").text(addCommas($pluse3s2));
$("#e3s3").text(addCommas($pluse3s3));
$("#e3s4").text(addCommas($pluse3s4));
$("#e3s5").text(addCommas($pluse3s5));

})
</script>
<style>
@import url('https://fonts.googleapis.com/css?family=Tauri');
body{font-family: 'Tauri', sans-serif;}
.title{font-size:18px;
padding-bottom: 20px;
color: #0066CC;
width:100%;}

  @page { size: Landscape; }

#printme {
  display: none;
}


@media print {
body{
    -webkit-print-color-adjust: exact; 
}

#hidesal{
display:none;}
#hideprint{
display:none;}
#page-content-wrapper{
top:0;
}
	
	#printthis, #printthis * {
	visibility: visible;
  }
	
	
    html, body {
    height:100%; 
    margin: 0 !important; 
    padding: 0 !important;
    overflow: hidden;
  }
@page { size: Landscape; }
}
  

.footer {
z-index:2;
width:100%;
position:fixed;
display: block;
  right: 0;
  bottom: 0;
  left: 0;
  font-size:12px;
  padding: 1rem;
  background-color: #efefef;
  text-align: right;}
  
  .loader {
	position: fixed;
	left: 0px;
	top: 0px;
	width: 100%;
	height: 100%;
	z-index: 9999;
	background: url('../../img/loading.gif') 50% 50% no-repeat rgb(249,249,249);
	opacity: .5;
}

  .icon {
  float:left;
  display:block;
  padding-top: 10px;
  }
  
  .back {
  display:none;
  border:none;
  }
  .add {
  border:none;
border-radius: 100%;
padding-top:15px;
padding-bottom: 17px;
padding-left: 17px;
padding-right: 15px;
font-size:24px;

}
.add:focus{
visibility:hidden;
outline: 0px;
}
.sidebar-brand{
background-color:#FFFFFF;
}
.sidebar-brand img {
width: 225px;
height:57px;

}
#salary {
padding-left:10px;
padding-right:10px;
}

  @media only screen and (max-width: 768px) 
{ 
.footer {
margin-top: 50px;
width:100%;
position: relative;
font-size: 10px;
background-color: #fff;
}

.sidebar-brand img {
width: 190px;
height:45px;

}
}

</style>


</head>

<body>
<!------------------------------------------->
<div class="loader"></div>
      

        <!-- Sidebar -->
		
		
		<div class="stat" style="position:static;">
		<div class="sticktop" style="top:0; display:block; position: fixed; z-index:1000; right:0; left:0;">
		<div class="hideprint">		
		<div class="sidebar-brand">
                    <a href="#">
                       <img src="../../img/logo.jpg"> 
                    </a>
                </div>
				<div class="drops">
		<div class="dropdowntogs">
                <a href="#"><span class="glyphicon glyphicon-user"> </span> &nbsp;&nbsp; <b>Admin</b> <?php echo $getthename ?></a></div>
				<div class="dropmenu">
<!---				<a href="#"><span class="glyphicon glyphicon-wrench"> </span> Edit Profile</a><div></div>--->
				<a href="../../chgpass.php"><span class="glyphicon glyphicon-lock"> </span> Change Password</a>
				<hr></hr>
				<a href="../../logout.php"><span class="glyphicon glyphicon-log-out"> </span> Log-out</a>
				</div>
				</div>							

		<div class="toggles"><a href="#menu-toggle" id="menu-toggle"><span class="glyphicon glyphicon-menu-hamburger"></span></a></div>       
                </div>
				</div>
				 <div id="wrapper">
				 <div id="sidebar-wrapper">
            <ul class="sidebar-nav">
			<div class="menunav"></div>
				<li>
				<a href="../../home/"><span class="glyphicon glyphicon-home icon"></span> Home</a>
                </li>
                <li>
				<div class="main">
                    <a href="#"><i class="glyphicon glyphicon-cog icon"></i> Maintenance</a></div>
					<div class="drop">
					<a href="../../maintenance/emperdata">Employee Personal Data</a>
					<a href="../../maintenance/empjobdata">Employee Job Data</a>
					<a href="../../maintenance/emprater">Employee Rater</a>
					</div>
					</li>
					<li>
				<div class="ijsm">
                    <a href="#" class="active"><i class="glyphicon glyphicon-briefcase icon"></i>IJSM</a></div>
					<div class="drop2" style="display:block;">
					<a href="../../ijsm/jobclass">Job Classification</a>
					<a href="../../ijsm/jobrating">Job Rating Plan</a>
					<a href="../../ijsm/jobeva">Job Evaluation</a>
					<a href=""  class="active" style="background-color:#fff; color:#000000;">Salary Structure</a>
					<a href="../../ijsm/salanal">Salary Analysis</a>
					</div>
					</li>
					<li>
				<div class="opms">
                    <a href="#"><i class="glyphicon glyphicon-list-alt icon"></i>OPMS</a></div>
					<div class="drop3">
					<a href="../../opms/wpg">Manage WPG</a>
					<a href="../../opms/wperfpercent">Manage WPA</a>
					<a href="../../opms/orgper">Manage OPMS</a>
					<a href="../../opms/getper">OPMS Form</a>
					</div>
                </li>
                <li>
								<div class="rprt">
                    <a href="#"><i class="glyphicon glyphicon-duplicate icon"></i>Report</a></div>
											
									<div class="drop4">
					<a href="../../rprt/ern">E.R.N.</a>
					<a href="../../rprt/tabul">OPMS Tabulation</a>
                    <a href="../../rprt/percat">Indv. Performance Category</a>
					<a href="../../rprt/orgcat">Org. Performance Category</a>
				</div>
                </li>
                <li>
				<div class="util">
                    <a href="#"><i class="glyphicon glyphicon-wrench icon"></i>Utilities</a></div>
					<div class="drop5">
					<a href="../../util/trail">Audit Trail</a>
					<a href="../../util/showinact">Show inactive</a>
					<a href="../../util/localbup">Data Back-up</a>

					</div>
                </li>
            </ul>							
			<div class="move" style="position:relative; z-index:-1; min-height:600px;">				
														<div id="footer" style=" position:absolute; margin-left:10px; left:0; bottom:0; text-align:center; font-size:10px;  width:200px; margin-right:10px; color:#CCCCCC; ">
				<b>Copyright </b> <span class="glyphicon glyphicon-copyright-mark"></span> <b><?php echo date(' Y')?></b> All Rights Reserved. <br /> Confluent HR System Solutions <br /> <b>Version</b> 2.0
				</div>			</div>
							
        </div>				
        <!-- /#sidebar-wrapper -->

        <!-- Page Content -->
<!--table--->				
<div id="result"></div>

        <div id="page-content-wrapper">
            <div class="container-fluid">
					<div id="hidesal">
<h2>Salary Matrix</h2>
<hr />
  Enter a daily salary <input type="text" name="salary" id="salary" value="<?php echo $salrange; ?>" maxlength="6" onkeypress='return event.charCode >= 46 && event.charCode <= 57 && event.charCode != 47' autofocus='' disabled="disabled" /> <button class="btn btn-success" id="save">Save</button> <button class="btn btn-default" id="edit" data-toggle="tooltip" data-placement="right" title="Edit">Edit</button> <i id="err_sal" style="font-size:10px; color:#FF0000"></i>
<div align="right" style="overflow:hidden; float:right;"><button class="btn btn-primary" id="print"  data-toggle="tooltip" data-placement="left"  title="Print Salary Structure" ><span class="glyphicon glyphicon-print"></span> Print</button></div>
</div>
  <div id="printthis">
  <span id="logo" style="display:none;">
<center><img src="../../img/logo.jpg" width="180px" height="48px" /></center>
<center style="color:#0000FF; font-size:20px;">SALARY MATRIX</center></span>
<b id="dailysal" style="display:none; font-size:16px; color:#0000CC;"></b>
  <p></p> 
  <table class="table table-bordered table-hover table-striped" id="table">
    <thead>
      <tr>
        <th>Job Level</th>
        <th>Job Grade</th>
		<th>Hiring</th>
		<th>Developmental</th>
		<th>Intermediate</th>
		<th>Advanced</th>
		<th>Proficient</th>
      </tr>
    </thead>
    <tbody>
	<tr>
        <td>Executive III</td>
        <td>14</td>
		        <td><c id="e3s1"></c></td>
				        <td><c id="e3s2"></c></td>
						        <td><c id="e3s3"></c></td>
								        <td><c id="e3s4"></c></td>
										        <td><c id="e3s5"></c></td>											
	</tr>
	<tr>
        <td>Executive II</td>
        <td>13</td>
		        <td><c id="e2s1"></c></td>
				        <td><c id="e2s2"></c></td>
						        <td><c id="e2s3"></c></td>
								        <td><c id="e2s4"></c></td>
										        <td><c id="e2s5"></c></td>											
	</tr>
	<tr>
        <td>Executive I</td>
        <td>12</td>
		        <td><c id="e1s1"></c></td>
				        <td><c id="e1s2"></c></td>
						        <td><c id="e1s3"></c></td>
								        <td><c id="e1s4"></c></td>
										        <td><c id="e1s5"></c></td>											
	</tr>
	<tr>
        <td>Group Head II</td>
        <td>11</td>
		        <td><c id="gh2s1"></c></td>
				        <td><c id="gh2s2"></c></td>
						        <td><c id="gh2s3"></c></td>
								        <td><c id="gh2s4"></c></td>
										        <td><c id="gh2s5"></c></td>											
      </tr>
	  	<tr>
        <td>Group Head I</td>
        <td>10</td>
		        <td><c id="gh1s1"></c></td>
				        <td><c id="gh1s2"></c></td>
						        <td><c id="gh1s3"></c></td>
								        <td><c id="gh1s4"></c></td>
										        <td><c id="gh1s5"></c></td>											
      </tr>												
      </tr>
	  <tr>
        <td>Department Hear II</td>
        <td>9</td>
		        <td><c id="dh2s1"></c></td>
				        <td><c id="dh2s2"></c></td>
						        <td><c id="dh2s3"></c></td>
								        <td><c id="dh2s4"></c></td>
										        <td><c id="dh2s5"></c></td>
      </tr>
	  <tr>
        <td>Department Head I</td>
        <td>8</td>
		        <td><c id="dh1s1"></c></td>
				        <td><c id="dh1s2"></c></td>
						        <td><c id="dh1s3"></c></td>
								        <td><c id="dh1s4"></c></td>
										        <td><c id="dh1s5"></c></td>
      </tr>
	  <tr>
        <td>Section Head II</td>
        <td>7</td>
		        <td><c id="sh2s1"></c></td>
				        <td><c id="sh2s2"></c></td>
						        <td><c id="sh2s3"></c></td>
								        <td><c id="sh2s4"></c></td>
										        <td><c id="sh2s5"></c></td>
      </tr>
	  <tr>
        <td>Section Head I</td>
        <td>6</td>
		        <td><c id="sh1s1"></c></td>
				        <td><c id="sh1s2"></c></td>
						        <td><c id="sh1s3"></c></td>
								        <td><c id="sh1s4"></c></td>
										        <td><c id="sh1s5"></c></td>
      </tr>
	  <tr>
        <td>Professional / Specialist</td>
        <td>5</td>
		        <td><c id="ps1s1"></c></td>
				        <td><c id="ps1s2"></c></td>
						        <td><c id="ps1s3"></c></td>
								        <td><c id="ps1s4"></c></td>
										        <td><c id="ps1s5"></c></td>
      </tr>
	<tr>
        <td>Staff II</td>
        <td>4</td>
		        <td><c id="s2s1"></c></td>
				        <td><c id="s2s2"></c></td>
						        <td><c id="s2s3"></c></td>
								        <td><c id="s2s4"></c></td>
										        <td><c id="s2s5"></c></td>
	  <tr>
        <td>Staff I</td>
        <td>3</td>
		        <td><c id="s1s1"></c></td>
				        <td><c id="s1s2"></c></td>
						        <td><c id="s1s3"></c></td>
								        <td><c id="s1s4"></c></td>
										        <td><c id="s1s5"></c></td>
      </tr>												
												
      </tr>
		  <tr>
        <td>Rank & File II</td>
        <td>2</td>
		        <td><c id="rf2s1"></c></td>
				        <td><c id="rf2s2"></c></td>
						        <td><c id="rf2s3"></c></td>
								        <td><c id="rf2s4"></c></td>
										        <td><c id="rf2s5"></c></td>
      </tr>
      <tr>
        <td>Rank & File I</td>
        <td>1</td>
		        <td><b id="rf1s1"></b></td>
				        <td ><c id="rf1s2"></c></td>
						        <td><c id="rf1s3"></c></td>
								        <td><c id="rf1s4"></c></td>
										        <td><c id="rf1s5"></c></td>
      </tr>
    </tbody>
  </table>
		  </div>

        <!-- /#page-content-wrapper -->
    </div>
	 </div>
    <!-- /#wrapper -->
	
	<!-- Modal -->

  <div class="modal fade" id="modalprint" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h3 class="modal-title text-primary"><span class="glyphicon glyphicon-print"> </span> Print Salary Matrix</h3>
        </div>
        <div class="modal-body">
		<br />
          <p>Are you sure you want to print Salary Matrix?</p>
        </div>
        <div class="modal-footer">
		  <button type="button" id="no" value="no" data-dismiss="modal" class="btn btn-default" > Cancel </button>
		  <button type="button" id="yes" value="yes" class="btn btn-primary" autofocus > Ok </button>
		
        </div>
      </div>
      
    </div>
  </div>
	

	
	<!-- Modal for save salary -->

  <div class="modal fade" id="modalsave" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h3 class="modal-title text-primary"><span class="glyphicon glyphicon-print"> </span> Daily Salary</h3>
        </div>
        <div class="modal-body">
		<br />
          <p>Are you sure you want to save daily salary?</p>
        </div>
        <div class="modal-footer">
		  <button type="button" id="nosave" value="no" data-dismiss="modal" class="btn btn-default" > Cancel </button>
		  <button type="button" id="yessave" value="yes" class="btn btn-primary" autofocus> Ok </button>
		
        </div>
      </div>
      
    </div>
  </div>
	
	<?php include('../../assets/navbar.php'); ?>  
     <!-- Menu Toggle Script -->
    <script>





	<!---- Compute Salary ----->
//var	$getsalary = $('#salary').val(); 
    $('#salary').keyup(function() {       		 
            if ($('#salary').val() == '') {                
$("#err_sal").text("*This is a required field");
$("#print").attr('disabled','disabled');
            }
else {
$("#err_sal").text("");
$("#print").removeAttr('disabled');
}

function addCommas(nStr){
 nStr += '';
 var x = nStr.split('.');
 var x1 = x[0];
 var x2 = x.length > 1 ? '.' + x[1] : '';
 var rgx = /(\d+)(\d{3})/;
 while (rgx.test(x1)) {
  x1 = x1.replace(rgx, '$1' + ',' + '$2');
 }
 return x1 + x2;
}        
<!----- Rank & File 1 ---->
var $getsalary = parseFloat(($('#salary').val()*313)/12).toFixed(2);
var $intwodecimal = parseFloat($getsalary);
var $plusrf1s2com = parseFloat(($intwodecimal*0.0375)+$intwodecimal).toFixed(2);
var $plusrf1s2 = parseFloat($plusrf1s2com);
var $plusrf1s3com = parseFloat(($plusrf1s2*0.0375)+$plusrf1s2).toFixed(2);
var $plusrf1s3 = parseFloat($plusrf1s3com);
var $plusrf1s4com = parseFloat(($plusrf1s3*0.0375)+$plusrf1s3).toFixed(2);
var $plusrf1s4 = parseFloat($plusrf1s4com);
var $plusrf1s5com = parseFloat(($plusrf1s4*0.0375)+$plusrf1s4).toFixed(2);
var $plusrf1s5 = parseFloat($plusrf1s5com);


$("#rf1s1").text(addCommas($intwodecimal));
$("#rf1s2").text(addCommas($plusrf1s2));
$("#rf1s3").text(addCommas($plusrf1s3));
$("#rf1s4").text(addCommas($plusrf1s4));
$("#rf1s5").text(addCommas($plusrf1s5));

<!---- Rank & File 2 ------>			
					
var $plusrf2s1com = parseFloat(($plusrf1s3*0.04)+$plusrf1s3).toFixed(2);
var $plusrf2s1 = parseFloat($plusrf2s1com);
var $plusrf2s2com = parseFloat(($plusrf2s1*0.05)+$plusrf2s1).toFixed(2);
var $plusrf2s2 = parseFloat($plusrf2s2com);
var $plusrf2s3com = parseFloat(($plusrf2s2*0.05)+$plusrf2s2).toFixed(2);
var $plusrf2s3 = parseFloat($plusrf2s3com);
var $plusrf2s4com = parseFloat(($plusrf2s3*0.05)+$plusrf2s3).toFixed(2);
var $plusrf2s4 = parseFloat($plusrf2s4com);
var $plusrf2s5com = parseFloat(($plusrf2s4*0.05)+$plusrf2s4).toFixed(2);
var $plusrf2s5 = parseFloat($plusrf2s5com);


$("#rf2s1").text(addCommas($plusrf2s1));
$("#rf2s2").text(addCommas($plusrf2s2));
$("#rf2s3").text(addCommas($plusrf2s3));
$("#rf2s4").text(addCommas($plusrf2s4));
$("#rf2s5").text(addCommas($plusrf2s5));

<!---- Staff 1 ------>			
					
var $pluss1s1com = parseFloat(($plusrf2s3*0.06)+$plusrf2s3).toFixed(2);
var $pluss1s1 = parseFloat($pluss1s1com);
var $pluss1s2com = parseFloat(($pluss1s1*0.05)+$pluss1s1).toFixed(2);
var $pluss1s2 = parseFloat($pluss1s2com);
var $pluss1s3com = parseFloat(($pluss1s2*0.05)+$pluss1s2).toFixed(2);
var $pluss1s3 = parseFloat($pluss1s3com);
var $pluss1s4com = parseFloat(($pluss1s3*0.05)+$pluss1s3).toFixed(2);
var $pluss1s4 = parseFloat($pluss1s4com);
var $pluss1s5com = parseFloat(($pluss1s4*0.05)+$pluss1s4).toFixed(2);
var $pluss1s5 = parseFloat($pluss1s5com);


$("#s1s1").text(addCommas($pluss1s1));
$("#s1s2").text(addCommas($pluss1s2));
$("#s1s3").text(addCommas($pluss1s3));
$("#s1s4").text(addCommas($pluss1s4));
$("#s1s5").text(addCommas($pluss1s5));

<!---- Staff 2 ------>			
					
var $pluss2s1com = parseFloat(($pluss1s3*0.06)+$pluss1s3).toFixed(2);
var $pluss2s1 = parseFloat($pluss2s1com);
var $pluss2s2com = parseFloat(($pluss2s1*0.05)+$pluss2s1).toFixed(2);
var $pluss2s2 = parseFloat($pluss2s2com);
var $pluss2s3com = parseFloat(($pluss2s2*0.05)+$pluss2s2).toFixed(2);
var $pluss2s3 = parseFloat($pluss2s3com);
var $pluss2s4com = parseFloat(($pluss2s3*0.05)+$pluss2s3).toFixed(2);
var $pluss2s4 = parseFloat($pluss2s4com);
var $pluss2s5com = parseFloat(($pluss2s4*0.05)+$pluss2s4).toFixed(2);
var $pluss2s5 = parseFloat($pluss2s5com);


$("#s2s1").text(addCommas($pluss2s1));
$("#s2s2").text(addCommas($pluss2s2));
$("#s2s3").text(addCommas($pluss2s3));
$("#s2s4").text(addCommas($pluss2s4));
$("#s2s5").text(addCommas($pluss2s5));

<!---- Professional / Specialist ------>			
					
var $plusps1s1com = parseFloat(($pluss2s3*0.08)+$pluss2s3).toFixed(2);
var $plusps1s1 = parseFloat($plusps1s1com);
var $plusps1s2com = parseFloat(($plusps1s1*0.05)+$plusps1s1).toFixed(2);
var $plusps1s2 = parseFloat($plusps1s2com);
var $plusps1s3com = parseFloat(($plusps1s2*0.05)+$plusps1s2).toFixed(2);
var $plusps1s3 = parseFloat($plusps1s3com);
var $plusps1s4com = parseFloat(($plusps1s3*0.05)+$plusps1s3).toFixed(2);
var $plusps1s4 = parseFloat($plusps1s4com);
var $plusps1s5com = parseFloat(($plusps1s4*0.05)+$plusps1s4).toFixed(2);
var $plusps1s5 = parseFloat($plusps1s5com);


$("#ps1s1").text(addCommas($plusps1s1));
$("#ps1s2").text(addCommas($plusps1s2));
$("#ps1s3").text(addCommas($plusps1s3));
$("#ps1s4").text(addCommas($plusps1s4));
$("#ps1s5").text(addCommas($plusps1s5));

<!---- Section Head I ------>			
					
var $plussh1s1com = parseFloat(($plusps1s3*0.08)+$plusps1s3).toFixed(2);
var $plussh1s1 = parseFloat($plussh1s1com);
var $plussh1s2com = parseFloat(($plussh1s1*0.05)+$plussh1s1).toFixed(2);
var $plussh1s2 = parseFloat($plussh1s2com);
var $plussh1s3com = parseFloat(($plussh1s2*0.05)+$plussh1s2).toFixed(2);
var $plussh1s3 = parseFloat($plussh1s3com);
var $plussh1s4com = parseFloat(($plussh1s3*0.05)+$plussh1s3).toFixed(2);
var $plussh1s4 = parseFloat($plussh1s4com);
var $plussh1s5com = parseFloat(($plussh1s4*0.05)+$plussh1s4).toFixed(2);
var $plussh1s5 = parseFloat($plussh1s5com);


$("#sh1s1").text(addCommas($plussh1s1));
$("#sh1s2").text(addCommas($plussh1s2));
$("#sh1s3").text(addCommas($plussh1s3));
$("#sh1s4").text(addCommas($plussh1s4));
$("#sh1s5").text(addCommas($plussh1s5));

<!---- Section Head II ------>			
					
var $plussh2s1com = parseFloat(($plussh1s3*0.08)+$plussh1s3).toFixed(2);
var $plussh2s1 = parseFloat($plussh2s1com);
var $plussh2s2com = parseFloat(($plussh2s1*0.05)+$plussh2s1).toFixed(2);
var $plussh2s2 = parseFloat($plussh2s2com);
var $plussh2s3com = parseFloat(($plussh2s2*0.05)+$plussh2s2).toFixed(2);
var $plussh2s3 = parseFloat($plussh2s3com);
var $plussh2s4com = parseFloat(($plussh2s3*0.05)+$plussh2s3).toFixed(2);
var $plussh2s4 = parseFloat($plussh2s4com);
var $plussh2s5com = parseFloat(($plussh2s4*0.05)+$plussh2s4).toFixed(2);
var $plussh2s5 = parseFloat($plussh2s5com);


$("#sh2s1").text(addCommas($plussh2s1));
$("#sh2s2").text(addCommas($plussh2s2));
$("#sh2s3").text(addCommas($plussh2s3));
$("#sh2s4").text(addCommas($plussh2s4));
$("#sh2s5").text(addCommas($plussh2s5));

<!---- Department Head I ------>			
					
var $plusdh1s1com = parseFloat(($plussh2s3*0.10)+$plussh2s3).toFixed(2);
var $plusdh1s1 = parseFloat($plusdh1s1com);
var $plusdh1s2com = parseFloat(($plusdh1s1*0.05)+$plusdh1s1).toFixed(2);
var $plusdh1s2 = parseFloat($plusdh1s2com);
var $plusdh1s3com = parseFloat(($plusdh1s2*0.05)+$plusdh1s2).toFixed(2);
var $plusdh1s3 = parseFloat($plusdh1s3com);
var $plusdh1s4com = parseFloat(($plusdh1s3*0.05)+$plusdh1s3).toFixed(2);
var $plusdh1s4 = parseFloat($plusdh1s4com);
var $plusdh1s5com = parseFloat(($plusdh1s4*0.05)+$plusdh1s4).toFixed(2);
var $plusdh1s5 = parseFloat($plusdh1s5com);


$("#dh1s1").text(addCommas($plusdh1s1));
$("#dh1s2").text(addCommas($plusdh1s2));
$("#dh1s3").text(addCommas($plusdh1s3));
$("#dh1s4").text(addCommas($plusdh1s4));
$("#dh1s5").text(addCommas($plusdh1s5));

<!---- Department Head II ------>			
					
var $plusdh2s1com = parseFloat(($plusdh1s3*0.10)+$plusdh1s3).toFixed(2);
var $plusdh2s1 = parseFloat($plusdh2s1com);
var $plusdh2s2com = parseFloat(($plusdh2s1*0.05)+$plusdh2s1).toFixed(2);
var $plusdh2s2 = parseFloat($plusdh2s2com);
var $plusdh2s3com = parseFloat(($plusdh2s2*0.05)+$plusdh2s2).toFixed(2);
var $plusdh2s3 = parseFloat($plusdh2s3com);
var $plusdh2s4com = parseFloat(($plusdh2s3*0.05)+$plusdh2s3).toFixed(2);
var $plusdh2s4 = parseFloat($plusdh2s4com);
var $plusdh2s5com = parseFloat(($plusdh2s4*0.05)+$plusdh2s4).toFixed(2);
var $plusdh2s5 = parseFloat($plusdh2s5com);


$("#dh2s1").text(addCommas($plusdh2s1));
$("#dh2s2").text(addCommas($plusdh2s2));
$("#dh2s3").text(addCommas($plusdh2s3));
$("#dh2s4").text(addCommas($plusdh2s4));
$("#dh2s5").text(addCommas($plusdh2s5));

<!---- Group Head I ------>			
					
var $plusgh1s1com = parseFloat(($plusdh2s3*0.12)+$plusdh2s3).toFixed(2);
var $plusgh1s1 = parseFloat($plusgh1s1com);
var $plusgh1s2com = parseFloat(($plusgh1s1*0.05)+$plusgh1s1).toFixed(2);
var $plusgh1s2 = parseFloat($plusgh1s2com);
var $plusgh1s3com = parseFloat(($plusgh1s2*0.05)+$plusgh1s2).toFixed(2);
var $plusgh1s3 = parseFloat($plusgh1s3com);
var $plusgh1s4com = parseFloat(($plusgh1s3*0.05)+$plusgh1s3).toFixed(2);
var $plusgh1s4 = parseFloat($plusgh1s4com);
var $plusgh1s5com = parseFloat(($plusgh1s4*0.05)+$plusgh1s4).toFixed(2);
var $plusgh1s5 = parseFloat($plusgh1s5com);


$("#gh1s1").text(addCommas($plusgh1s1));
$("#gh1s2").text(addCommas($plusgh1s2));
$("#gh1s3").text(addCommas($plusgh1s3));
$("#gh1s4").text(addCommas($plusgh1s4));
$("#gh1s5").text(addCommas($plusgh1s5));

<!---- Group Head II ------>			
					
var $plusgh2s1com = parseFloat(($plusgh1s3*0.12)+$plusgh1s3).toFixed(2);
var $plusgh2s1 = parseFloat($plusgh2s1com);
var $plusgh2s2com = parseFloat(($plusgh2s1*0.05)+$plusgh2s1).toFixed(2);
var $plusgh2s2 = parseFloat($plusgh2s2com);
var $plusgh2s3com = parseFloat(($plusgh2s2*0.05)+$plusgh2s2).toFixed(2);
var $plusgh2s3 = parseFloat($plusgh2s3com);
var $plusgh2s4com = parseFloat(($plusgh2s3*0.05)+$plusgh2s3).toFixed(2);
var $plusgh2s4 = parseFloat($plusgh2s4com);
var $plusgh2s5com = parseFloat(($plusgh2s4*0.05)+$plusgh2s4).toFixed(2);
var $plusgh2s5 = parseFloat($plusgh2s5com);


$("#gh2s1").text(addCommas($plusgh2s1));
$("#gh2s2").text(addCommas($plusgh2s2));
$("#gh2s3").text(addCommas($plusgh2s3));
$("#gh2s4").text(addCommas($plusgh2s4));
$("#gh2s5").text(addCommas($plusgh2s5));

<!---- Executive I ------>			
					
var $pluse1s1com = parseFloat(($plusgh2s3*0.15)+$plusgh2s3).toFixed(2);
var $pluse1s1 = parseFloat($pluse1s1com);
var $pluse1s2com = parseFloat(($pluse1s1*0.05)+$pluse1s1).toFixed(2);
var $pluse1s2 = parseFloat($pluse1s2com);
var $pluse1s3com = parseFloat(($pluse1s2*0.05)+$pluse1s2).toFixed(2);
var $pluse1s3 = parseFloat($pluse1s3com);
var $pluse1s4com = parseFloat(($pluse1s3*0.05)+$pluse1s3).toFixed(2);
var $pluse1s4 = parseFloat($pluse1s4com);
var $pluse1s5com = parseFloat(($pluse1s4*0.05)+$pluse1s4).toFixed(2);
var $pluse1s5 = parseFloat($pluse1s5com);


$("#e1s1").text(addCommas($pluse1s1));
$("#e1s2").text(addCommas($pluse1s2));
$("#e1s3").text(addCommas($pluse1s3));
$("#e1s4").text(addCommas($pluse1s4));
$("#e1s5").text(addCommas($pluse1s5));

<!---- Exexutive II ------>			
					
var $pluse2s1com = parseFloat(($pluse1s3*0.15)+$pluse1s3).toFixed(2);
var $pluse2s1 = parseFloat($pluse2s1com);
var $pluse2s2com = parseFloat(($pluse2s1*0.05)+$pluse2s1).toFixed(2);
var $pluse2s2 = parseFloat($pluse2s2com);
var $pluse2s3com = parseFloat(($pluse2s2*0.05)+$pluse2s2).toFixed(2);
var $pluse2s3 = parseFloat($pluse2s3com);
var $pluse2s4com = parseFloat(($pluse2s3*0.05)+$pluse2s3).toFixed(2);
var $pluse2s4 = parseFloat($pluse2s4com);
var $pluse2s5com = parseFloat(($pluse2s4*0.05)+$pluse2s4).toFixed(2);
var $pluse2s5 = parseFloat($pluse2s5com);


$("#e2s1").text(addCommas($pluse2s1));
$("#e2s2").text(addCommas($pluse2s2));
$("#e2s3").text(addCommas($pluse2s3));
$("#e2s4").text(addCommas($pluse2s4));
$("#e2s5").text(addCommas($pluse2s5));

<!---- Executive III ------>			
					
var $pluse3s1com = parseFloat(($pluse2s3*0.15)+$pluse2s3).toFixed(2);
var $pluse3s1 = parseFloat($pluse3s1com);
var $pluse3s2com = parseFloat(($pluse3s1*0.05)+$pluse3s1).toFixed(2);
var $pluse3s2 = parseFloat($pluse3s2com);
var $pluse3s3com = parseFloat(($pluse3s2*0.05)+$pluse3s2).toFixed(2);
var $pluse3s3 = parseFloat($pluse3s3com);
var $pluse3s4com = parseFloat(($pluse3s3*0.05)+$pluse3s3).toFixed(2);
var $pluse3s4 = parseFloat($pluse3s4com);
var $pluse3s5com = parseFloat(($pluse3s4*0.05)+$pluse3s4).toFixed(2);
var $pluse3s5 = parseFloat($pluse3s5com);


$("#e3s1").text(addCommas($pluse3s1));
$("#e3s2").text(addCommas($pluse3s2));
$("#e3s3").text(addCommas($pluse3s3));
$("#e3s4").text(addCommas($pluse3s4));
$("#e3s5").text(addCommas($pluse3s5));

})
$("#print").click(function() {
	 $("#modalprint").modal('show');
	  var dailysal = $("#salary").val();
	  var text = "Daily Salary : "+dailysal;
	  $("#dailysal").text(text);

});


$("#yes").click(function() {
//	 $("#dailysal").removeAttr('style');
	
/*	 var divToPrint = document.getElementById('table');
	 var htmlToPrint = "Daily Salary: "+dailysal+"";
	 htmlToPrint += '' + 
        '<style type="text/css">' +
        'table th, table td {' +
        'margin-top:10px; border:1px solid #000;' +
        'padding:0.5em; padding-right:40px;' +
        '}' +
        '</style>';
		htmlToPrint += divToPrint.outerHTML;

  	mywindow = window.open('');
    mywindow.document.write(htmlToPrint);
    mywindow.document.close(); // necessary for IE >= 10
    mywindow.focus(); // necessary for IE >= 10*/

//    mywindow.print();
 //   mywindow.close();

//    return true;
/*	var printContents = document.getElementById('printthis').innerHTML;
     var originalContents = document.body.innerHTML;

     document.body.innerHTML = printContents;
	 
     window.print();
	 
     document.body.innerHTML = originalContents;

		
	 return true;*/
	 			 		$("#modalprint").modal("hide");
						$("#logo").removeAttr("style");
					    $("#dailysal").removeAttr("style");
					 	$(".footer").attr("style","display:none;");
		 				$(".hideprint").attr("style","display:none;");
					 	$(".hidesal").attr("style","display:none;");
			var printit = $("#printthis").html()
            $("#printme").html(printit);
            window.print();
			$("#logo").attr("style","display:none;");
					    $("#dailysal").attr("style","display:none;");
			$(".hideprint").removeAttr("style");
			$(".footer").removeAttr("style");
						$(".hidesal").removeAttr("style");
			$("#printme").html("");

	 });

$("#save").click(function() {
	 $("#modalsave").modal('show');
});
$("#yessave").click(function() {
 var valsal = $('#salary').val();
	$('#edit').show();
	$('#save').hide();
	$('#salary').attr('disabled','disabled');
        $.ajax({
            type: "POST",
            url: "update.php", //process to update
			data: {salary : valsal},										
            success: function(data){
			$(".loader").fadeIn();
					  setTimeout(
  function() 
  {
$(".loader").fadeOut();
  }, 2000);		
 setTimeout(
  function() 
  {
				window.location.reload(); }, 2000);
			}

			})
					
				 });

	
</script>
</body>
</html>