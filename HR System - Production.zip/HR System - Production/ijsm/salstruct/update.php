<?php
require_once '../../assets/dbconfig.php';
require_once '../../assets/connection.php';
	if($_POST)
	{	$range = $_POST['salary'];
	$empid = '1';
		
		
		$stmt = $db_con->prepare("UPDATE emp_job_data SET sal_range=:ran WHERE emp_job_id = :id");
			$stmt->bindParam(":ran", $range);
			$stmt->bindParam(":id", $empid);

			
		if($stmt->execute())
		{
		$trail = mysql_query("INSERT INTO trail (type, per_action, description, emp_id) VALUES ('Salary Structure', 'UPDATED', 'Daily Salary changed to $range', '$user_check')", 		$connection);
			echo "Daily Salary Successfully Saved";
		}
		else{
			echo "Query Problem";
		}
	}

?>