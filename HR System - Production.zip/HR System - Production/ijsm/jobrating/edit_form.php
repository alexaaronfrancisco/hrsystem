<?php
require_once '../../assets/dbconfig.php';
require_once '../../assets/connection.php';

if($_GET['edit_id'])
{
	$id = $_GET['edit_id'];	
	$stmt=$db_con->prepare("SELECT * FROM job_rating_plan WHERE rating_id=:id");
	$stmt->execute(array(':id'=>$id));	
	$row=$stmt->fetch(PDO::FETCH_ASSOC);
}

?>

<script>
		$(document).ready(function(){
    $('[data-toggle="tooltip"]').tooltip();   
});
		</script>

<style type="text/css">
#dis{
	display: none;
	margin-left: 70px;
	position: fixed;
	top: 50px;
	width: 68%;
	padding:20px;
	z-index:99999;
}
  .loader {
	position: fixed;
	left: 0px;
	top: 0px;
	width: 100%;
	height: 100%;
	z-index: 9999;
	background: url('../../img/loading.gif') 50% 50% no-repeat rgb(249,249,249);
	opacity: .5;
}

#square {
background-color: #ECECFF;
-webkit-box-shadow: 0px 0px 2px rgba(50, 50, 50, 0.31);
    -moz-box-shadow:    0px 0px 5px rgba(50, 50, 50, 0.31);
    box-shadow:         0px 0px 10px rgba(50, 50, 50, 0.31);
padding:20px;
}
.add {
border-radius: 100%;
padding-top:15px;
padding-bottom: 17px;
padding-left: 15px;
padding-right: 17px;
font-size:24px;		
}
.add:focus{
outline: 0px;
}
.btn {
border-radius: 100%;
padding-top:25px;
padding-bottom: 25px;
padding-left: 25px;
padding-right: 25px;
font-size:36px;
			    -webkit-box-shadow: 0px 0px 10px rgba(50, 50, 50, 20);
    -moz-box-shadow:    0px 0px 10px rgba(50, 50, 50, 20);
    box-shadow:         0px 0px 10px rgba(50, 50, 50, 20);
}
.btn:focus{
outline: 0px;
}
  @media only screen and (max-width: 768px) 
{ 
#dis{
	top: 75px;
	margin-left: 0;
	width:70%
}

</style>
    <div id="dis">
    <!-- here message will be displayed -->
	</div>

<div class="title"> Update </div>
	 <form method='post' id='emp-UpdateForm' action="">
 
<div id="square">
<div class="row">
<input type='hidden' name='id' value='<?php echo $row['rating_id']; ?>' />
                  <div class="col-sm-12">
              <b>Category</b>
 <div style="margin-bottom: 10px;" class="input-group">
			  <span class="input-group-addon"><i class="glyphicon glyphicon-th"></i></span>
			<textarea name='cat' id="area" style="height:100px;"  placeholder='' class="form-control" required><?php echo $row['category']; ?></textarea> 
         </div>
 </div>

         <div class="col-sm-12">
             <b>Sub-Category</b> 
			  <div style="margin-bottom: 10px;" class="input-group">
			  <span class="input-group-addon"><i class="glyphicon glyphicon-th-list"></i></span>
			<textarea name='subcat' id="subcat" style="height:100px;"  placeholder='' class="form-control"><?php echo $row['sub_category']; ?></textarea> 

         </div>
		 </div>
		 </div>
		 <div class="row">
 <div class="col-sm-12">
			 <b>Question</b>
			  <div style="margin-bottom: 10px;" class="input-group">
			  <span class="input-group-addon"><b>?</b></span>
          			<textarea name='ques' id="area" style="height:100px;"  placeholder='' class="form-control" required><?php echo $row['questions']; ?></textarea> 
         </div>
		 </div>
		 </div>
		<?php	
$rating_id = $row['rating_id'];
$ques_sql=mysql_query("select choices from job_rating_plan where rating_id='$rating_id'", $connection);
$row3 = mysql_fetch_assoc($ques_sql);
$ques_entry =$row3['choices'];
$convert_ques=explode(" + ",$ques_entry);
$ques_val=mysql_query("select value from job_rating_plan where rating_id='$rating_id'", $connection);
$row4 = mysql_fetch_assoc($ques_val);
$val_entry =$row4['value'];
$convert_val=explode(", ",$val_entry);
$countarr = count($convert_ques);
$x = 0;
$y = 0;
$z = 0;
$a = 1;
		 while ($x < $countarr){
		?>		 <div class="row">
				  <div class="col-sm-10">
			 <b>Choice #<?php echo $a; ?></b>
<textarea name='cho<?php echo $z; ?>' id='area' style='height:50px;' placeholder='' class='form-control' required><?php echo $convert_ques[$y];?></textarea><br />
</div>
		  <div class="col-sm-2">
             <b>Value</b>
 <textarea name='val<?php echo $z; ?>' id="value" style="height:50px;" class='form-control' maxlength="2" onkeypress='return event.charCode >= 48 && event.charCode <= 57' required><?php echo $convert_val[$y]; ?></textarea>  <br/>   
 </div>
</div>
<?php 
$x++;
$y++;
$z++;
$a++;
}?>
		  <center><div id="errrmsg" style="color:#FF0000; font-size:12px;"></div></center>
		     
     </form>    
            <button type="btn-save" class="btn btn-success" name="btn-save" id="btn-save" data-toggle="tooltip" data-placement="right" title="Save Record">
    		<span class="glyphicon glyphicon-floppy-save"></span>
			</button>  
			</div>
		</div>

 <script>
 

var count = parseInt(1, 10);
		var count1 = parseInt(1, 10);      
				var count2 = parseInt(1, 10);   
//DOCUMENT READY
$(document).ready(function(){
    var empty_flds = 0;
    $('input, textarea').each(function() {
        if(!$.trim($(this).val())) {
            empty_flds++;
        }    
    });
    if (empty_flds) {
                count1 = 1;
$("#errrmsg").text("*Some required field is empty");
$("textarea").css("border","grey solid 1px");
            }
else {
count1 = 0;
$("#errrmsg").text("");
$("textarea").css("border","green solid 1px");
}
if (count1 == 1 || count2 == 1){       
            $('#btn-save').attr('disabled', 'disabled');
        } else {
            $('#btn-save').removeAttr('disabled');}
})				
		
$(document).ready(function(){
	var sum = 0;
	var left = 100;
$('textarea[id="value"]').each(function(){
    sum += parseFloat(this.value);
	left -= parseFloat(this.value);
            if (sum != 100) {
                count2 = 1;

				
$("#errrmsg").text("*Maximum total value is 100 | value left: " + left+"");
$("textarea").css("border","grey solid 1px");
$('#btn-save').attr('disabled', 'disabled');
            }
else {
count2=0;
$("#left").text("");
$("#errrmsg").text("");
$("textarea").css("border","green solid 1px");
}
if (count1 == 1 || count2 == 1){       
            $('#btn-save').attr('disabled', 'disabled');
        } else {
            $('#btn-save').removeAttr('disabled');}

})
});		
				
//KEYUP     
$('textarea[id="area"]').keyup(function() {
    var empty_flds = 0;
    $('input, textarea').each(function() {
        if(!$.trim($(this).val())) {
            empty_flds++;
        }    
    });
    if (empty_flds) {
                count1 = 1;
$("#errrmsg").text("*Some required field is empty");
$("textarea").css("border","grey solid 1px");
            }
else {
count1 = 0;
$("#errrmsg").text("");
$("textarea").css("border","green solid 1px");
}
if (count1 == 1 || count2 == 1){       
            $('#btn-save').attr('disabled', 'disabled');
        } else {
            $('#btn-save').removeAttr('disabled');}
})
/*
$(document).on('input propertychange', "textarea", function () {
            if (this.value == '') {
                count1 = 1;
$("#errrmsg").text("*Some required field is empty");
$("textarea").css("border","grey solid 1px");
$('#btn-save').attr('disabled', 'disabled');
            }
else {
count1=0;
$("#errrmsg").text("");
$("textarea").css("border","green solid 1px");
$('#btn-save').removeAttr('disabled', 'disabled');
}
})*/
	$('textarea[id="value"]').keyup(function(){
	var sum = 0;
	var left = 100;
$('textarea[id="value"]').each(function(){
    sum += parseFloat(this.value);
	left -= parseFloat(this.value);
            if (sum != 100) {
                count2 = 1;

				
$("#errrmsg").text("*Maximum total value is 100 | value left: " + left+"");
$("textarea").css("border","grey solid 1px");
$('#btn-save').attr('disabled', 'disabled');
            }
else {
count2=0;
$("#left").text("");
$("#errrmsg").text("");
$("textarea").css("border","green solid 1px");
}
if (count1 == 1 || count2 == 1){       
            $('#btn-save').attr('disabled', 'disabled');
        } else {
            $('#btn-save').removeAttr('disabled');}

})
});



</script>
    