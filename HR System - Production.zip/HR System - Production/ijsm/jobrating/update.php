<?php
require_once '../../assets/dbconfig.php';
require_once '../../assets/connection.php';
	
/*$a = 0;
$b = 0;
while ($a < $countrating){
$convalue = "val".$b;
$addval[] = $_POST[$convalue];
$a++;
$b++;
}*/
if($_POST){
	$rating_id = $_POST['id'];	

$ques_val=mysql_query("select value from job_rating_plan where rating_id='$rating_id'", $connection);
$row4 = mysql_fetch_assoc($ques_val);
$val_entry =$row4['value'];
$convert_val=explode(", ",$val_entry);
$countval = count($convert_val);
$a = 0;
$b = 0;
while ($a < $countval){
$conques = "cho".$b;
$addques[] = $_POST[$conques];
$conval = "val".$b;
$addval[] = $_POST[$conval];
$a++;
$b++;
}
$valimplode = implode(", ",$addval);
$quesimplode = implode(" + ",$addques);

 	$cat = $_POST['cat'];
		$sub = $_POST['subcat'];
		$ques = $_POST['ques'];
		
	
			$stmt = $db_con->prepare("UPDATE job_rating_plan SET category=:cat, sub_category=:sub, questions=:ques, choices=:cho, value=:val WHERE rating_id=:id");
			$stmt->bindParam(":cat", $cat);
			$stmt->bindParam(":sub", $sub);
			$stmt->bindParam(":ques", $ques);
			$stmt->bindParam(":cho", $quesimplode);
			$stmt->bindParam(":val", $valimplode);
			$stmt->bindParam(":id", $rating_id);
		
						
			if($stmt->execute())
			{		
			$trail = mysql_query("INSERT INTO trail (type, per_action, description, emp_id) VALUES ('Job Rating Plan', 'UPDATED', 'ID No. $rating_id', '$user_check')", $connection);
			echo "Updating...";
			}
			else{
				echo "Query Problem";
			}	
	}

?>