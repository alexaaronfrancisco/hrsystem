<?php
require_once '../../assets/dbconfig.php';

if($_GET['edit_id'])
{
	$id = $_GET['edit_id'];	
	$stmt=$db_con->prepare("SELECT * FROM job_classification WHERE job_id=:id");
	$stmt->execute(array(':id'=>$id));	
	$row=$stmt->fetch(PDO::FETCH_ASSOC);
}

?>
<script>
		$(document).ready(function(){
    $('[data-toggle="tooltip"]').tooltip();   
});
		</script>

<style type="text/css">
#dis{
	display: none;
	margin-left: 70px;
	position: fixed;
	top: 50px;
	width: 68%;
	padding:20px;
	z-index:99999;
}
  .loader {
	position: fixed;
	left: 0px;
	top: 0px;
	width: 100%;
	height: 100%;
	z-index: 9999;
	background: url('../../img/loading.gif') 50% 50% no-repeat rgb(249,249,249);
	opacity: .5;
}

#square {
background-color: #ECECFF;
-webkit-box-shadow: 0px 0px 2px rgba(50, 50, 50, 0.31);
    -moz-box-shadow:    0px 0px 5px rgba(50, 50, 50, 0.31);
    box-shadow:         0px 0px 10px rgba(50, 50, 50, 0.31);
padding:20px;
}
.add {
border-radius: 100%;
padding-top:15px;
padding-bottom: 17px;
padding-left: 15px;
padding-right: 17px;
font-size:24px;		
}
.add:focus{
outline: 0px;
}
.btn {
border-radius: 100%;
padding-top:25px;
padding-bottom: 25px;
padding-left: 25px;
padding-right: 25px;
font-size:36px;
			    -webkit-box-shadow: 0px 0px 10px rgba(50, 50, 50, 20);
    -moz-box-shadow:    0px 0px 10px rgba(50, 50, 50, 20);
    box-shadow:         0px 0px 10px rgba(50, 50, 50, 20);
}
.btn:focus{
outline: 0px;
}
  @media only screen and (max-width: 768px) 
{ 
#dis{
	top: 75px;
	margin-left: 0;
	width:70%
}

</style>
    <div id="dis">
    <!-- here message will be displayed -->
	</div>

<div class="title"> Update </div>
	 <form method='post' id='emp-UpdateForm' action="#">
 
<div id="square">
<div class="row">
<input type='hidden' name='id' value='<?php echo $row['job_id']; ?>' />
                  <div class="col-sm-6">
              <b>Job Rank</b>
 <div style="margin-bottom: 10px;" class="input-group">
			  <span class="input-group-addon"><i class="glyphicon glyphicon-sort-by-attributes"></i></span>
			<input type='text' name='rank' id="rank" value="<?php echo $row['rank']; ?>"  placeholder='' readonly="" class="form-control" required /> 
         </div>
 </div>

         <div class="col-sm-2">
             <b>Job Grade </b> 
			  <div style="margin-bottom: 10px;" class="input-group">
			  <span class="input-group-addon"><i class="glyphicon glyphicon-signal"></i></span>
			  <input type="text" name='grade' id="grade" class='form-control' value="<?php echo $id; ?>" maxlength="2" placeholder='' readonly="" required>

         </div>
		 </div>
		 </div>
		 <div class="row">
 <div class="col-sm-2">
			 <b>Start Range</b>
			  <div style="margin-bottom: 10px;" class="input-group">
			  <span class="input-group-addon"><i class="glyphicon glyphicon-upload"></i></span>
             <input type='text' name='start' id="start" class='form-control' value="<?php echo $row['start_range']; ?>" placeholder='' readonly="" maxlength="3" onkeypress='return event.charCode >= 48 && event.charCode <= 57' required>
         </div>
		 </div>
		  <div class="col-sm-2">
			 <b>End Range</b>
			  <div style="margin-bottom: 10px;" class="input-group">
			  <span class="input-group-addon"><i class="glyphicon glyphicon-download"></i></span>
             <input type='text' name='end' id="end" class='form-control' value="<?php echo $row['end_range']; ?>" placeholder='' maxlength="3" readonly="" onkeypress='return event.charCode >= 48 && event.charCode <= 57' required>
         </div>
		 </div>
		 		 			 <div id="errrange" style="color:#FF0000; font-size:12px;"></div>
		

		  <div class="col-sm-12">
             <b>Description</b>
			  <div style="margin-bottom: 10px;" class="input-group">
			  <span class="input-group-addon"><i class="glyphicon glyphicon-comment"></i></span>
             <textarea name='descrip' id="descrip" class='form-control' required><?php echo $row['descrip']; ?></textarea>  
         </div>
		 </div>
		  </div>
		     
     </form>    
            <button type="btn-save" class="btn btn-success" name="btn-save" id="btn-save" data-toggle="tooltip" data-placement="right" title="Save Record">
    		<span class="glyphicon glyphicon-floppy-save"></span>
			</button>  
			</div>
		</div>

 <script>
 
(function() {
		var count1 = parseInt(1, 10);        
        var count2 = parseInt(1, 10);
        var count3 = parseInt(1, 10);
		var count4 = parseInt(1, 10);        
        var count5 = parseInt(1, 10);      
		        var counttotal = parseInt(0, 10);
<!----- FOR READY FUNCTION ----> 
$(document).ready(function() { 
            if ($('#rank').val() == '') {
                count1 = 1;
$("#errrank").text("*This is a required field");
$("#rank").css("border","red solid 1px");
$('#btn-save').attr('disabled', 'disabled');
            }
else {
count1=0;
$("#errname").text("");
$("#rank").css("border","green solid 1px");
}
if (count1 == 1 || count2 == 1 || count3 == 1 || count4 == 1 || count5 == 1){       
            $('#btn-save').attr('disabled', 'disabled');
        } else {
            $('#btn-save').removeAttr('disabled');}

})
<!-----grade----->
$(document).ready(function() { 
if ($('#grade').val() == '') {
                count2 = 1;
$("#errrank").text("*This is a required field");
$("#grade").css("border","red solid 1px");
$('#btn-save').attr('disabled', 'disabled');
            }
else {
count2=0;
$("#errname").text("");
$("#grade").css("border","green solid 1px");
}
if (count1 == 1 || count2 == 1 || count3 == 1 || count4 == 1 || count5 == 1){       
            $('#btn-save').attr('disabled', 'disabled');
        } else {
            $('#btn-save').removeAttr('disabled');}

})

<!-----start range----->
$(document).ready(function() {        		 
if ($('#start').val() == '') {
                count3 = 1;
$("#errrank").text("*This is a required field");
$("#start").css("border","red solid 1px");
$('#btn-save').attr('disabled', 'disabled');
            }
else {
count3=0;
$("#errname").text("");
$("#start").css("border","green solid 1px");
}
if (count1 == 1 || count2 == 1 || count3 == 1 || count4 == 1 || count5 == 1){       
            $('#btn-save').attr('disabled', 'disabled');
        } else {
            $('#btn-save').removeAttr('disabled');}

})

<!-----end range----->
$(document).ready(function() {      		 
if ($('#end').val() == '') {
                count4 = 1;
$("#errrank").text("*This is a required field");
$("#end").css("border","red solid 1px");
$('#btn-save').attr('disabled', 'disabled');
            }
else {
count4=0;
$("#errname").text("");
$("#end").css("border","green solid 1px");
}
if (count1 == 1 || count2 == 1 || count3 == 1 || count4 == 1 || count5 == 1){       
            $('#btn-save').attr('disabled', 'disabled');
        } else {
            $('#btn-save').removeAttr('disabled');}

})

<!-----description----->
$(document).ready(function() { 
if ($('#decrip').val() == '') {
                count5 = 1;
$("#errrank").text("*This is a required field");
$("#descrip").css("border","red solid 1px");
$('#btn-save').attr('disabled', 'disabled');
            }
else {
count5=0;
$("#errname").text("");
$("#descrip").css("border","green solid 1px");
}
if (count1 == 1 || count2 == 1 || count3 == 1 || count4 == 1 || count5 == 1){       
            $('#btn-save').attr('disabled', 'disabled');
        } else {
            $('#btn-save').removeAttr('disabled');}

})


<!----- FOR KeyUP FUNCTION ----> 
 $('#rank').keyup(function() {       		     		 
            if ($('#rank').val() == '') {
                count1 = 1;
$("#errrank").text("*This is a required field");
$("#rank").css("border","red solid 1px");
$('#btn-save').attr('disabled', 'disabled');
            }
else {
count1=0;
$("#errname").text("");
$("#rank").css("border","green solid 1px");
}
if (count1 == 1 || count2 == 1 || count3 == 1 || count4 == 1 || count5 == 1){       
            $('#btn-save').attr('disabled', 'disabled');
        } else {
            $('#btn-save').removeAttr('disabled');}

})
<!-----grade----->
 $('#grade').keyup(function() {       		 
if ($('#grade').val() == '') {
                count2 = 1;
$("#errrank").text("*This is a required field");
$("#grade").css("border","red solid 1px");
$('#btn-save').attr('disabled', 'disabled');
            }
else {
count2=0;
$("#errname").text("");
$("#grade").css("border","green solid 1px");
}
if (count1 == 1 || count2 == 1 || count3 == 1 || count4 == 1 || count5 == 1){       
            $('#btn-save').attr('disabled', 'disabled');
        } else {
            $('#btn-save').removeAttr('disabled');}

})

<!-----start range----->
 $('#start').keyup(function() {       		 
if ($('#start').val() == '' || $('#start').val() <= 102 || $('#start').val() >= 669 || $('#start').val() >= $('#end').val()) {
                count3 = 1;
$("#errrange").text("*min range 103 | max range 730");
$("#start").css("border","red solid 1px");
$('#btn-save').attr('disabled', 'disabled');
            }
else {
count3=0;
$("#errrange").text("");
$("#start").css("border","green solid 1px");
}
if (count1 == 1 || count2 == 1 || count3 == 1 || count4 == 1 || count5 == 1){       
            $('#btn-save').attr('disabled', 'disabled');
        } else {
            $('#btn-save').removeAttr('disabled');}

})

<!-----end range----->
 $('#end').keyup(function() {       		 
if ($('#end').val() == '' || $('#end').val() >= 731 || $('#end').val() <= 164 || $('#end').val() <= $('#start').val()) {
                count4 = 1;
$("#errrange").text("*min range 103 | max range 730");
$("#end").css("border","red solid 1px");
$('#btn-save').attr('disabled', 'disabled');
            }
else {
count4=0;
$("#errrange").text("");
$("#end").css("border","green solid 1px");
}
if (count1 == 1 || count2 == 1 || count3 == 1 || count4 == 1 || count5 == 1){       
            $('#btn-save').attr('disabled', 'disabled');
        } else {
            $('#btn-save').removeAttr('disabled');}

})

<!-----description----->
 $('#descrip').keyup(function() {       		 
if ($('#decrip').val() == '') {
                count5 = 1;
$("#errrank").text("*This is a required field");
$("#descrip").css("border","red solid 1px");
$('#btn-save').attr('disabled', 'disabled');
            }
else {
count5=0;
$("#errname").text("");
$("#descrip").css("border","green solid 1px");
}
if (count1 == 1 || count2 == 1 || count3 == 1 || count4 == 1 || count5 == 1){       
            $('#btn-save').attr('disabled', 'disabled');
        } else {
            $('#btn-save').removeAttr('disabled');}

})



})()


</script>
    