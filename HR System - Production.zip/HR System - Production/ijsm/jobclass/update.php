<?php
require_once '../../assets/dbconfig.php';
require_once '../../assets/connection.php';
	
	if($_POST)
	{	$id = $_POST['id'];	
		$rank = $_POST['rank'];
		$grade = $_POST['grade'];
		$start = $_POST['start'];
		$end= $_POST['end'];
		$descrip = $_POST['descrip'];
		
		
		$stmt = $db_con->prepare("UPDATE job_classification SET rank=:rank, grade=:grade, start_range=:start, end_range=:end, descrip=:des WHERE grade=:id");
			$stmt->bindParam(":rank", $rank);
			$stmt->bindParam(":grade", $grade);
			$stmt->bindParam(":start", $start);
			$stmt->bindParam(":end", $end);
			$stmt->bindParam(":des", $descrip);
			$stmt->bindParam(":id", $id);
			
		if($stmt->execute())
		{
		$trail = mysql_query("INSERT INTO trail (type, per_action, description, emp_id) VALUES ('Job Classifcation', 'UPDATED', 'ID No. $id', '$user_check')", $connection);
			echo "Updating...";
		}
		else{
			echo "Query Problem";
		}
	}

?>