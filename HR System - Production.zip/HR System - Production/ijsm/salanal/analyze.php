<?php
require_once '../../assets/dbconfig.php';
require_once '../../assets/connection.php';
		
$sal_sql=mysql_query("select sal_range from emp_job_data where emp_job_id='1'", $connection);
$row3 = mysql_fetch_assoc($sal_sql);
$salrange =$row3['sal_range'];


?>
<?php 
if($_GET['edit_id'])
{
	$id = $_GET['edit_id'];
	$percent = $_GET['percent'];
	$stmt=$db_con->prepare("SELECT * FROM emp_personal_data WHERE emp_id=:id");
	$stmt->execute(array(':id'=>$id));	
	$row=$stmt->fetch(PDO::FETCH_ASSOC);			
	$name =$row['emp_name'];
	$fname =$row['fname'];
	
	$name_sql=mysql_query("select * from emp_job_data where emp_id='$id'", $connection);
	$row2 = mysql_fetch_assoc($name_sql);
	$salary =$row2['current'];
	$allowance =$row2['alw'];
	$pos =$row2['title'];
	$stat =$row2['category'];	
	$jobid =$row2['job_id'];
	$getdate_sal_pre =$row2['adj_salary_pre'];
	$hired = date('F d, Y', strtotime($row2['hired']));	
	$allow = (float)str_replace(",","",$allowance);
	$salaryanal = (float)str_replace(",","",$salary);	
	$percent2 = $percent/100;
	$analsalary = (round(($salaryanal*$percent2)+$salaryanal, 2));
	$analsalaryprint = number_format($analsalary, 2, ".", ",");
	//allowance
	$wallowadd = $allow + $analsalary;
	$wallow = number_format($wallowadd, 2, ".", ",");
	
	if($getdate_sal_pre == ""){
	$date_sal_pre = 'None';}
	else{
	$date_sal_pre = date('F d, Y', strtotime($getdate_sal_pre));}
}
?>
        <?php
$rank1_sql=mysql_query("select rank from job_classification where job_id='$jobid'", $connection);
$rows = mysql_fetch_assoc($rank1_sql);
$rank = $rows['rank'];
		
$rank1_sql=mysql_query("select rank from job_classification where job_id='1'", $connection);
$rows1 = mysql_fetch_assoc($rank1_sql);
$rank1 = $rows1['rank'];

$rank2_sql=mysql_query("select rank from job_classification where job_id='2'", $connection);
$rows2 = mysql_fetch_assoc($rank2_sql);
$rank2 = $rows2['rank'];

$rank3_sql=mysql_query("select rank from job_classification where job_id='3'", $connection);
$rows3 = mysql_fetch_assoc($rank3_sql);
$rank3 = $rows3['rank'];

$rank4_sql=mysql_query("select rank from job_classification where job_id='4'", $connection);
$rows4 = mysql_fetch_assoc($rank4_sql);
$rank4 = $rows4['rank'];

$rank5_sql=mysql_query("select rank from job_classification where job_id='5'", $connection);
$rows5 = mysql_fetch_assoc($rank5_sql);
$rank5 = $rows5['rank'];

$rank6_sql=mysql_query("select rank from job_classification where job_id='6'", $connection);
$rows6 = mysql_fetch_assoc($rank6_sql);
$rank6 = $rows6['rank'];

$rank7_sql=mysql_query("select rank from job_classification where job_id='7'", $connection);
$rows7 = mysql_fetch_assoc($rank7_sql);
$rank7 = $rows7['rank'];

$rank8_sql=mysql_query("select rank from job_classification where job_id='8'", $connection);
$rows8 = mysql_fetch_assoc($rank8_sql);
$rank8 = $rows8['rank'];

$rank9_sql=mysql_query("select rank from job_classification where job_id='9'", $connection);
$rows9 = mysql_fetch_assoc($rank9_sql);
$rank9 = $rows9['rank'];

$rank10_sql=mysql_query("select rank from job_classification where job_id='10'", $connection);
$rows10 = mysql_fetch_assoc($rank10_sql);
$rank10 = $rows10['rank'];

$rank11_sql=mysql_query("select rank from job_classification where job_id='11'", $connection);
$rows11 = mysql_fetch_assoc($rank11_sql);
$rank11 = $rows11['rank'];

$rank12_sql=mysql_query("select rank from job_classification where job_id='12'", $connection);
$rows12 = mysql_fetch_assoc($rank12_sql);
$rank12 = $rows12['rank'];

$rank13_sql=mysql_query("select rank from job_classification where job_id='13'", $connection);
$rows13 = mysql_fetch_assoc($rank13_sql);
$rank13 = $rows13['rank'];

$rank14_sql=mysql_query("select rank from job_classification where job_id='14'", $connection);
$rows14 = mysql_fetch_assoc($rank14_sql);
$rank14 = $rows14['rank'];
			?>

<?php
$getsal = $salrange;
$rf1_1 = (((float)$getsal*313)/12);
$rf1_2 = $rf1_1*0.0375+$rf1_1;
$rf1_3 = $rf1_2*0.0375+$rf1_2;
$rf1_4 = $rf1_3*0.0375+$rf1_3;
$rf1_5 = $rf1_4*0.0375+$rf1_4;
$rf1_6 = $rf1_5*0.0375+$rf1_5;

$getrf1_1 = (round($rf1_1, 2));
$getrf1_2 = (round($rf1_2, 2));
$getrf1_3 = (round($rf1_3, 2));
$getrf1_4 = (round($rf1_4, 2));
$getrf1_5 = (round($rf1_5, 2));
$getrf1_6 = (round($rf1_6, 2));


//rank and file 2
$rf2_1 = $rf1_3*0.04+$rf1_3;
$rf2_2 = $rf2_1*0.05+$rf2_1;
$rf2_3 = $rf2_2*0.05+$rf2_2;
$rf2_4 = $rf2_3*0.05+$rf2_3;
$rf2_5 = $rf2_4*0.05+$rf2_4;

$getrf2_1 = (round($rf2_1, 2));
$getrf2_2 = (round($rf2_2, 2));
$getrf2_3 = (round($rf2_3, 2));
$getrf2_4 = (round($rf2_4, 2));
$getrf2_5 = (round($rf2_5, 2));

//Staff 1
$s1_1 = $rf2_3*0.06+$rf2_3;
$s1_2 = $s1_1*0.05+$s1_1;
$s1_3 = $s1_2*0.05+$s1_2;
$s1_4 = $s1_3*0.05+$s1_3;
$s1_5 = $s1_4*0.05+$s1_4;

$gets1_1 = (round($s1_1, 2));
$gets1_2 = (round($s1_2, 2));
$gets1_3 = (round($s1_3, 2));
$gets1_4 = (round($s1_4, 2));
$gets1_5 = (round($s1_5, 2));

//Staff 2
$s2_1 = $s1_3*0.06+$s1_3;
$s2_2 = $s2_1*0.05+$s2_1;
$s2_3 = $s2_2*0.05+$s2_2;
$s2_4 = $s2_3*0.05+$s2_3;
$s2_5 = $s2_4*0.05+$s2_4;

$gets2_1 = (round($s2_1, 2));
$gets2_2 = (round($s2_2, 2));
$gets2_3 = (round($s2_3, 2));
$gets2_4 = (round($s2_4, 2));
$gets2_5 = (round($s2_5, 2));

//Professional
$pro_1 = $s2_3*0.08+$s2_3;
$pro_2 = $pro_1*0.05+$pro_1;
$pro_3 = $pro_2*0.05+$pro_2;
$pro_4 = $pro_3*0.05+$pro_3;
$pro_5 = $pro_4*0.05+$pro_4;

$getpro_1 = (round($pro_1, 2));
$getpro_2 = (round($pro_2, 2));
$getpro_3 = (round($pro_3, 2));
$getpro_4 = (round($pro_4, 2));
$getpro_5 = (round($pro_5, 2));

//Section Head 1
$sh1_1 = $pro_3*0.08+$pro_3;
$sh1_2 = $sh1_1*0.05+$sh1_1;
$sh1_3 = $sh1_2*0.05+$sh1_2;
$sh1_4 = $sh1_3*0.05+$sh1_3;
$sh1_5 = $sh1_4*0.05+$sh1_4;

$getsh1_1 = (round($sh1_1, 2));
$getsh1_2 = (round($sh1_2, 2));
$getsh1_3 = (round($sh1_3, 2));
$getsh1_4 = (round($sh1_4, 2));
$getsh1_5 = (round($sh1_5, 2));

//Section Head 2
$sh2_1 = $sh1_3*0.08+$sh1_3;
$sh2_2 = $sh2_1*0.05+$sh2_1;
$sh2_3 = $sh2_2*0.05+$sh2_2;
$sh2_4 = $sh2_3*0.05+$sh2_3;
$sh2_5 = $sh2_4*0.05+$sh2_4;

$getsh2_1 = (round($sh2_1, 2));
$getsh2_2 = (round($sh2_2, 2));
$getsh2_3 = (round($sh2_3, 2));
$getsh2_4 = (round($sh2_4, 2));
$getsh2_5 = (round($sh2_5, 2));

//Department Head 1
$dh1_1 = $sh2_3*0.10+$sh2_3;
$dh1_2 = $dh1_1*0.05+$dh1_1;
$dh1_3 = $dh1_2*0.05+$dh1_2;
$dh1_4 = $dh1_3*0.05+$dh1_3;
$dh1_5 = $dh1_4*0.05+$dh1_4;

$getdh1_1 = (round($dh1_1, 2));
$getdh1_2 = (round($dh1_2, 2));
$getdh1_3 = (round($dh1_3, 2));
$getdh1_4 = (round($dh1_4, 2));
$getdh1_5 = (round($dh1_5, 2));

//Department Head 2
$dh2_1 = $dh1_3*0.10+$dh1_3;
$dh2_2 = $dh2_1*0.05+$dh2_1;
$dh2_3 = $dh2_2*0.05+$dh2_2;
$dh2_4 = $dh2_3*0.05+$dh2_3;
$dh2_5 = $dh2_4*0.05+$dh2_4;

$getdh2_1 = (round($dh2_1, 2));
$getdh2_2 = (round($dh2_2, 2));
$getdh2_3 = (round($dh2_3, 2));
$getdh2_4 = (round($dh2_4, 2));
$getdh2_5 = (round($dh2_5, 2));

//Group Head I
$gh1_1 = $dh2_3*0.12+$dh2_3;
$gh1_2 = $gh1_1*0.05+$gh1_1;
$gh1_3 = $gh1_2*0.05+$gh1_2;
$gh1_4 = $gh1_3*0.05+$gh1_3;
$gh1_5 = $gh1_4*0.05+$gh1_4;

$getgh1_1 = (round($gh1_1, 2));
$getgh1_2 = (round($gh1_2, 2));
$getgh1_3 = (round($gh1_3, 2));
$getgh1_4 = (round($gh1_4, 2));
$getgh1_5 = (round($gh1_5, 2));

//Group Head 2
$gh2_1 = $gh1_3*0.12+$gh1_3;
$gh2_2 = $gh2_1*0.05+$gh2_1;
$gh2_3 = $gh2_2*0.05+$gh2_2;
$gh2_4 = $gh2_3*0.05+$gh2_3;
$gh2_5 = $gh2_4*0.05+$gh2_4;

$getgh2_1 = (round($gh2_1, 2));
$getgh2_2 = (round($gh2_2, 2));
$getgh2_3 = (round($gh2_3, 2));
$getgh2_4 = (round($gh2_4, 2));
$getgh2_5 = (round($gh2_5, 2));

//Executive I
$exe_1 = $gh2_3*0.15+$gh2_3;
$exe_2 = $exe_1*0.05+$exe_1;
$exe_3 = $exe_2*0.05+$exe_2;
$exe_4 = $exe_3*0.05+$exe_3;
$exe_5 = $exe_4*0.05+$exe_4;

$getexe_1 = (round($exe_1, 2));
$getexe_2 = (round($exe_2, 2));
$getexe_3 = (round($exe_3, 2));
$getexe_4 = (round($exe_4, 2));
$getexe_5 = (round($exe_5, 2));

//exe2cutive I
$exe2_1 = $exe_3*0.15+$exe_3;
$exe2_2 = $exe2_1*0.05+$exe2_1;
$exe2_3 = $exe2_2*0.05+$exe2_2;
$exe2_4 = $exe2_3*0.05+$exe2_3;
$exe2_5 = $exe2_4*0.05+$exe2_4;

$getexe2_1 = (round($exe2_1, 2));
$getexe2_2 = (round($exe2_2, 2));
$getexe2_3 = (round($exe2_3, 2));
$getexe2_4 = (round($exe2_4, 2));
$getexe2_5 = (round($exe2_5, 2));

//Executive III
$exe3_1 = $exe2_3*0.15+$exe2_3;
$exe3_2 = $exe3_1*0.05+$exe3_1;
$exe3_3 = $exe3_2*0.05+$exe3_2;
$exe3_4 = $exe3_3*0.05+$exe3_3;
$exe3_5 = $exe3_4*0.05+$exe3_4;

$getexe3_1 = (round($exe3_1, 2));
$getexe3_2 = (round($exe3_2, 2));
$getexe3_3 = (round($exe3_3, 2));
$getexe3_4 = (round($exe3_4, 2));
$getexe3_5 = (round($exe3_5, 2));



//$salary = $row['current']; 
$salary2 = (float)str_replace(",","",$salary);
//$rank = $row['rank'];
if ($rank == $rank1){
if ($salary2 < $getrf1_1){
		$stat_text = "<div class='label label-default' style='font-size:12px;'>Below the Range by ".(round((($salary2-$getrf1_1)/$salary2)*100, 2))."%</div>";
		}
 else if ($salary2 >= $getrf1_1 && $salary2 <= $getrf1_2)
		{
		$stat_text = '<div class="label label-primary" style="font-size:12px;">Within Developmental by '.(round((($salary2-$getrf1_1)/($getrf1_2-$getrf1_1))*100, 2)).'% </div>';
		}
 else if ($salary2 >= $getrf1_2 && $salary2 <= $getrf1_3)
		{
		$stat_text = "<div class='label label-info' style='font-size:12px;'>Within Intermidiate by ".(round((($salary2-$getrf1_2)/($getrf1_3-$getrf1_2))*100, 2))."% </div>";
		}
 else if ($salary2 >= $getrf1_3 && $salary2 <= $getrf1_4)
		{
		$stat_text = "<div class='label label-success' style='font-size:12px;'>Within Advanced by ".(round((($salary2-$getrf1_3)/($getrf1_4-$getrf1_3))*100, 2))."%</div>";
		}
 else if ($salary2 >= $getrf1_4 && $salary2 <= $getrf1_5)
		{
		$stat_text = "<div class='label label-warning' style='font-size:12px;'>Within Proficient by ".(round((($salary2-$getrf1_4)/($getrf1_5-$getrf1_4))*100, 2))."%</div>";
		}
		else 
		$stat_text = "<div class='label label-danger' style='font-size:12px;'>Above the Range by ".(round((($salary2-$getrf1_5)/$salary2)*100, 2))."%</div>";
		}

// rank and file 2
else if ($rank == $rank2){
if ($salary2 < $getrf2_1){
		$stat_text = "<div class='label label-default' style='font-size:12px;'>Below the Range by ".(round((($salary2-$getrf2_1)/$salary2)*100, 2))."%</div>";
		}
 else if ($salary2 >= $getrf2_1 && $salary2 <= $getrf2_2)
		{
		$stat_text = '<div class="label label-primary" style="font-size:12px;">Within Developmental by '.(round((($salary2-$getrf2_1)/($getrf2_2-$getrf2_1))*100, 2)).'% </div>';
		}
 else if ($salary2 >= $getrf2_2 && $salary2 <= $getrf2_3)
		{
		$stat_text = "<div class='label label-info' style='font-size:12px;'>Within Intermidiate by ".(round((($salary2-$getrf2_2)/($getrf2_3-$getrf2_2))*100, 2))."% </div>";
		}
 else if ($salary2 >= $getrf2_3 && $salary2 <= $getrf2_4)
		{
		$stat_text = "<div class='label label-success' style='font-size:12px;'>Within Advanced by ".(round((($salary2-$getrf2_3)/($getrf2_4-$getrf2_3))*100, 2))."%</div>";
		}
 else if ($salary2 >= $getrf2_4 && $salary2 <= $getrf2_5)
		{
		$stat_text = "<div class='label label-warning' style='font-size:12px;'>Within Proficient by ".(round((($salary2-$getrf2_4)/($getrf2_5-$getrf2_4))*100, 2))."%</div>";
		}
		else 
		$stat_text = "<div class='label label-danger' style='font-size:12px;'>Above the Range by ".(round((($salary2-$getrf2_5)/$salary2)*100, 2))."%</div>";
		}
// staff 1
else if ($rank == $rank3){
if ($salary2 < $gets1_1){
		$stat_text = "<div class='label label-default' style='font-size:12px;'>Below the Range by ".(round((($salary2-$gets1_1)/$salary2)*100, 2))."%</div>";
		}
 else if ($salary2 >= $gets1_1 && $salary2 <= $gets1_2)
		{
		$stat_text = '<div class="label label-primary" style="font-size:12px;">Within Developmental by '.(round((($salary2-$gets1_1)/($gets1_2-$gets1_1))*100, 2)).'% </div>';
		}
 else if ($salary2 >= $gets1_2 && $salary2 <= $gets1_3)
		{
		$stat_text = "<div class='label label-info' style='font-size:12px;'>Within Intermidiate by ".(round((($salary2-$gets1_2)/($gets1_3-$gets1_2))*100, 2))."% </div>";
		}
 else if ($salary2 >= $gets1_3 && $salary2 <= $gets1_4)
		{
		$stat_text = "<div class='label label-success' style='font-size:12px;'>Within Advanced by ".(round((($salary2-$gets1_3)/($gets1_4-$gets1_3))*100, 2))."%</div>";
		}
 else if ($salary2 >= $gets1_4 && $salary2 <= $gets1_5)
		{
		$stat_text = "<div class='label label-warning' style='font-size:12px;'>Within Proficient by ".(round((($salary2-$gets1_4)/($gets1_5-$gets1_4))*100, 2))."%</div>";
		}
		else 
		$stat_text = "<div class='label label-danger' style='font-size:12px;'>Above the Range by ".(round((($salary2-$gets1_5)/$salary2)*100, 2))."%</div>";
		}
		
		// staff 2
else if ($rank == $rank4){
if ($salary2 < $gets2_1){
		$stat_text = "<div class='label label-default' style='font-size:12px;'>Below the Range by ".(round((($salary2-$gets2_1)/$salary2)*100, 2))."%</div>";
		}
 else if ($salary2 >= $gets2_1 && $salary2 <= $gets2_2)
		{
		$stat_text = '<div class="label label-primary" style="font-size:12px;">Within Developmental by '.(round((($salary2-$gets2_1)/($gets2_2-$gets2_1))*100, 2)).'% </div>';
		}
 else if ($salary2 >= $gets2_2 && $salary2 <= $gets2_3)
		{
		$stat_text = "<div class='label label-info' style='font-size:12px;'>Within Intermidiate by ".(round((($salary2-$gets2_2)/($gets2_3-$gets2_2))*100, 2))."% </div>";
		}
 else if ($salary2 >= $gets2_3 && $salary2 <= $gets2_4)
		{
		$stat_text = "<div class='label label-success' style='font-size:12px;'>Within Advanced by ".(round((($salary2-$gets2_3)/($gets2_4-$gets2_3))*100, 2))."%</div>";
		}
 else if ($salary2 >= $gets2_4 && $salary2 <= $gets2_5)
		{
		$stat_text = "<div class='label label-warning' style='font-size:12px;'>Within Proficient by ".(round((($salary2-$gets2_4)/($gets2_5-$gets2_4))*100, 2))."%</div>";
		}
		else 
		$stat_text = "<div class='label label-danger' style='font-size:12px;'>Above the Range by ".(round((($salary2-$gets2_5)/$salary2)*100, 2))."%</div>";
		}
		// professional
else if ($rank == $rank5){
if ($salary2 < $getpro_1){
		$stat_text = "<div class='label label-default' style='font-size:12px;'>Below the Range by ".(round((($salary2-$getpro_1)/$salary2)*100, 2))."%</div>";
		}
 else if ($salary2 >= $getpro_1 && $salary2 <= $getpro_2)
		{
		$stat_text = '<div class="label label-primary" style="font-size:12px;">Within Developmental by '.(round((($salary2-$getpro_1)/($getpro_2-$getpro_1))*100, 2)).'% </div>';
		}
 else if ($salary2 >= $getpro_2 && $salary2 <= $getpro_3)
		{
		$stat_text = "<div class='label label-info' style='font-size:12px;'>Within Intermidiate by ".(round((($salary2-$getpro_2)/($getpro_3-$getpro_2))*100, 2))."% </div>";
		}
 else if ($salary2 >= $getpro_3 && $salary2 <= $getpro_4)
		{
		$stat_text = "<div class='label label-success' style='font-size:12px;'>Within Advanced by ".(round((($salary2-$getpro_3)/($getpro_4-$getpro_3))*100, 2))."%</div>";
		}
 else if ($salary2 >= $getpro_4 && $salary2 <= $getpro_5)
		{
		$stat_text = "<div class='label label-warning' style='font-size:12px;'>Within Proficient by ".(round((($salary2-$getpro_4)/($getpro_5-$getpro_4))*100, 2))."%</div>";
		}
		else 
		$stat_text = "<div class='label label-danger' style='font-size:12px;'>Above the Range by ".(round((($salary2-$getpro_5)/$salary2)*100, 2))."%</div>";
		}
		// section head 1
else if ($rank == $rank6){
if ($salary2 < $getsh1_1){
		$stat_text = "<div class='label label-default' style='font-size:12px;'>Below the Range by ".(round((($salary2-$getsh1_1)/$salary2)*100, 2))."%</div>";
		}
 else if ($salary2 >= $getsh1_1 && $salary2 <= $getsh1_2)
		{
		$stat_text = '<div class="label label-primary" style="font-size:12px;">Within Developmental by '.(round((($salary2-$getsh1_1)/($getsh1_2-$getsh1_1))*100, 2)).'% </div>';
		}
 else if ($salary2 >= $getsh1_2 && $salary2 <= $getsh1_3)
		{
		$stat_text = "<div class='label label-info' style='font-size:12px;'>Within Intermidiate by ".(round((($salary2-$getsh1_2)/($getsh1_3-$getsh1_2))*100, 2))."% </div>";
		}
 else if ($salary2 >= $getsh1_3 && $salary2 <= $getsh1_4)
		{
		$stat_text = "<div class='label label-success' style='font-size:12px;'>Within Advanced by ".(round((($salary2-$getsh1_3)/($getsh1_4-$getsh1_3))*100, 2))."%</div>";
		}
 else if ($salary2 >= $getsh1_4 && $salary2 <= $getsh1_5)
		{
		$stat_text = "<div class='label label-warning' style='font-size:12px;'>Within Proficient by ".(round((($salary2-$getsh1_4)/($getsh1_5-$getsh1_4))*100, 2))."%</div>";
		}
		else 
		$stat_text = "<div class='label label-danger' style='font-size:12px;'>Above the Range by ".(round((($salary2-$getsh1_5)/$salary2)*100, 2))."%</div>";
		}
				// section head 2
else if ($rank == $rank7){
if ($salary2 < $getsh2_1){
		$stat_text = "<div class='label label-default' style='font-size:12px;'>Below the Range by ".(round((($salary2-$getsh2_1)/$salary2)*100, 2))."%</div>";
		}
 else if ($salary2 >= $getsh2_1 && $salary2 <= $getsh2_2)
		{
		$stat_text = '<div class="label label-primary" style="font-size:12px;">Within Developmental by '.(round((($salary2-$getsh2_1)/($getsh2_2-$getsh2_1))*100, 2)).'% </div>';
		}
 else if ($salary2 >= $getsh2_2 && $salary2 <= $getsh2_3)
		{
		$stat_text = "<div class='label label-info' style='font-size:12px;'>Within Intermidiate by ".(round((($salary2-$getsh2_2)/($getsh2_3-$getsh2_2))*100, 2))."% </div>";
		}
 else if ($salary2 >= $getsh2_3 && $salary2 <= $getsh2_4)
		{
		$stat_text = "<div class='label label-success' style='font-size:12px;'>Within Advanced by ".(round((($salary2-$getsh2_3)/($getsh2_4-$getsh2_3))*100, 2))."%</div>";
		}
 else if ($salary2 >= $getsh2_4 && $salary2 <= $getsh2_5)
		{
		$stat_text = "<div class='label label-warning' style='font-size:12px;'>Within Proficient by ".(round((($salary2-$getsh2_4)/($getsh2_5-$getsh2_4))*100, 2))."%</div>";
		}
		else 
		$stat_text = "<div class='label label-danger' style='font-size:12px;'>Above the Range by ".(round((($salary2-$getsh2_5)/$salary2)*100, 2))."%</div>";
		}
		// department head 1
else if ($rank == $rank8){
if ($salary2 < $getdh1_1){
		$stat_text = "<div class='label label-default' style='font-size:12px;'>Below the Range by ".(round((($salary2-$getdh1_1)/$salary2)*100, 2))."%</div>";
		}
 else if ($salary2 >= $getdh1_1 && $salary2 <= $getdh1_2)
		{
		$stat_text = '<div class="label label-primary" style="font-size:12px;">Within Developmental by '.(round((($salary2-$getdh1_1)/($getdh1_2-$getdh1_1))*100, 2)).'% </div>';
		}
 else if ($salary2 >= $getdh1_2 && $salary2 <= $getdh1_3)
		{
		$stat_text = "<div class='label label-info' style='font-size:12px;'>Within Intermidiate by ".(round((($salary2-$getdh1_2)/($getdh1_3-$getdh1_2))*100, 2))."% </div>";
		}
 else if ($salary2 >= $getdh1_3 && $salary2 <= $getdh1_4)
		{
		$stat_text = "<div class='label label-success' style='font-size:12px;'>Within Advanced by ".(round((($salary2-$getdh1_3)/($getdh1_4-$getdh1_3))*100, 2))."%</div>";
		}
 else if ($salary2 >= $getdh1_4 && $salary2 <= $getdh1_5)
		{
		$stat_text = "<div class='label label-warning' style='font-size:12px;'>Within Proficient by ".(round((($salary2-$getdh1_4)/($getdh1_5-$getdh1_4))*100, 2))."%</div>";
		}
		else 
		$stat_text = "<div class='label label-danger' style='font-size:12px;'>Above the Range by ".(round((($salary2-$getdh1_5)/$salary2)*100, 2))."%</div>";
		}
				// department head 2
else if ($rank == $rank9){
if ($salary2 < $getdh2_1){
		$stat_text = "<div class='label label-default' style='font-size:12px;'>Below the Range by ".(round((($salary2-$getdh2_1)/$salary2)*100, 2))."%</div>";
		}
 else if ($salary2 >= $getdh2_1 && $salary2 <= $getdh2_2)
		{
		$stat_text = '<div class="label label-primary" style="font-size:12px;">Within Developmental by '.(round((($salary2-$getdh2_1)/($getdh2_2-$getdh2_1))*100, 2)).'% </div>';
		}
 else if ($salary2 >= $getdh2_2 && $salary2 <= $getdh2_3)
		{
		$stat_text = "<div class='label label-info' style='font-size:12px;'>Within Intermidiate by ".(round((($salary2-$getdh2_2)/($getdh2_3-$getdh2_2))*100, 2))."% </div>";
		}
 else if ($salary2 >= $getdh2_3 && $salary2 < $getdh2_4)
		{
		$stat_text = "<div class='label label-success' style='font-size:12px;'>Within Advanced by ".(round((($salary2-$getdh2_3)/($getdh2_4-$getdh2_3))*100, 2))."%</div>";
		}
 else if ($salary2 >= $getdh2_4 && $salary2 <= $getdh2_5)
		{
		$stat_text = "<div class='label label-warning' style='font-size:12px;'>Within Proficient by ".(round((($salary2-$getdh2_4)/($getdh2_5-$getdh2_4))*100, 2))."%</div>";
		}
		else 
		$stat_text = "<div class='label label-danger' style='font-size:12px;'>Above the Range by ".(round((($salary2-$getdh2_5)/$salary2)*100, 2))."%</div>";
		}		
				// Group Head I
else if ($rank == $rank10){
if ($salary2 < $getgh1_1){
		$stat_text = "<div class='label label-default' style='font-size:12px;'>Below the Range by ".(round((($salary2-$getgh1_1)/$salary2)*100, 2))."%</div>";
		}
 else if ($salary2 >= $getgh1_1 && $salary2 <= $getgh1_2)
		{
		$stat_text = '<div class="label label-primary" style="font-size:12px;">Within Developmental by '.(round((($salary2-$getgh1_1)/($getgh1_2-$getgh1_1))*100, 2)).'% </div>';
		}
 else if ($salary2 >= $getgh1_2 && $salary2 <= $getgh1_3)
		{
		$stat_text = "<div class='label label-info' style='font-size:12px;'>Within Intermidiate by ".(round((($salary2-$getgh1_2)/($getgh1_3-$getgh1_2))*100, 2))."% </div>";
		}
 else if ($salary2 >= $getgh1_3 && $salary2 <= $getgh1_4)
		{
		$stat_text = "<div class='label label-success' style='font-size:12px;'>Within Advanced by ".(round((($salary2-$getgh1_3)/($getgh1_4-$getgh1_3))*100, 2))."%</div>";
		}
 else if ($salary2 >= $getgh1_4 && $salary2 <= $getgh1_5)
		{
		$stat_text = "<div class='label label-warning' style='font-size:12px;'>Within Proficient by ".(round((($salary2-$getgh1_4)/($getgh1_5-$getgh1_4))*100, 2))."%</div>";
		}
		else 
		$stat_text = "<div class='label label-danger' style='font-size:12px;'>Above the Range by ".(round((($salary2-$getgh1_5)/$salary2)*100, 2))."%</div>";
		}
				// Group Head II
else if ($rank == $rank11){
if ($salary2 < $getgh2_1){
		$stat_text = "<div class='label label-default' style='font-size:12px;'>Below the Range by ".(round((($salary2-$getgh2_1)/$salary2)*100, 2))."%</div>";
		}
 else if ($salary2 >= $getgh2_1 && $salary2 <= $getgh2_2)
		{
		$stat_text = '<div class="label label-primary" style="font-size:12px;">Within Developmental by '.(round((($salary2-$getgh2_1)/($getgh2_2-$getgh2_1))*100, 2)).'% </div>';
		}
 else if ($salary2 >= $getgh2_2 && $salary2 <= $getgh2_3)
		{
		$stat_text = "<div class='label label-info' style='font-size:12px;'>Within Intermidiate by ".(round((($salary2-$getgh2_2)/($getgh2_3-$getgh2_2))*100, 2))."% </div>";
		}
 else if ($salary2 >= $getgh2_3 && $salary2 <= $getgh2_4)
		{
		$stat_text = "<div class='label label-success' style='font-size:12px;'>Within Advanced by ".(round((($salary2-$getgh2_3)/($getgh2_4-$getgh2_3))*100, 2))."%</div>";
		}
 else if ($salary2 >= $getgh2_4 && $salary2 <= $getgh2_5)
		{
		$stat_text = "<div class='label label-warning' style='font-size:12px;'>Within Proficient by ".(round((($salary2-$getgh2_4)/($getgh2_5-$getgh2_4))*100, 2))."%</div>";
		}
		else 
		$stat_text = "<div class='label label-danger' style='font-size:12px;'>Above the Range by ".(round((($salary2-$getgh2_5)/$salary2)*100, 2))."%</div>";
		}
		
		// Executive I
else if ($rank == $rank12){
if ($salary2 < $getexe_1){
		$stat_text = "<div class='label label-default' style='font-size:12px;'>Below the Range by ".(round((($salary2-$getexe_1)/$salary2)*100, 2))."%</div>";
		}
 else if ($salary2 >= $getexe_1 && $salary2 <= $getexe_2)
		{
		$stat_text = '<div class="label label-primary" style="font-size:12px;">Within Developmental by '.(round((($salary2-$getexe_1)/($getexe_2-$getexe_1))*100, 2)).'% </div>';
		}
 else if ($salary2 >= $getexe_2 && $salary2 <= $getexe_3)
		{
		$stat_text = "<div class='label label-info' style='font-size:12px;'>Within Intermidiate by ".(round((($salary2-$getexe_2)/($getexe_3-$getexe_2))*100, 2))."% </div>";
		}
 else if ($salary2 >= $getexe_3 && $salary2 <= $getexe_4)
		{
		$stat_text = "<div class='label label-success' style='font-size:12px;'>Within Advanced by ".(round((($salary2-$getexe_3)/($getexe_4-$getexe_3))*100, 2))."%</div>";
		}
 else if ($salary2 >= $getexe_4 && $salary2 <= $getexe_5)
		{
		$stat_text = "<div class='label label-warning' style='font-size:12px;'>Within Proficient by ".(round((($salary2-$getexe_4)/($getexe_5-$getexe_4))*100, 2))."%</div>";
		}
		else 
		$stat_text = "<div class='label label-danger' style='font-size:12px;'>Above the Range by ".(round((($salary2-$getexe_5)/$salary2)*100, 2))."%</div>";
		}
						// Executive II
else if ($rank == $rank13){
if ($salary2 < $getexe2_1){
		$stat_text = "<div class='label label-default' style='font-size:12px;'>Below the Range by ".(round((($salary2-$getexe2_1)/$salary2)*100, 2))."%</div>";
		}
 else if ($salary2 >= $getexe2_1 && $salary2 <= $getexe2_2)
		{
		$stat_text = '<div class="label label-primary" style="font-size:12px;">Within Developmental by '.(round((($salary2-$getexe2_1)/($getexe2_2-$getexe2_1))*100, 2)).'% </div>';
		}
 else if ($salary2 >= $getexe2_2 && $salary2 <= $getexe2_3)
		{
		$stat_text = "<div class='label label-info' style='font-size:12px;'>Within Intermidiate by ".(round((($salary2-$getexe2_2)/($getexe2_3-$getexe2_2))*100, 2))."% </div>";
		}
 else if ($salary2 >= $getexe2_3 && $salary2 <= $getexe2_4)
		{
		$stat_text = "<div class='label label-success' style='font-size:12px;'>Within Advanced by ".(round((($salary2-$getexe2_3)/($getexe2_4-$getexe2_3))*100, 2))."%</div>";
		}
 else if ($salary2 >= $getexe2_4 && $salary2 <= $getexe2_5)
		{
		$stat_text = "<div class='label label-warning' style='font-size:12px;'>Within Proficient by ".(round((($salary2-$getexe2_4)/($getexe2_5-$getexe2_4))*100, 2))."%</div>";
		}
		else 
		$stat_text = "<div class='label label-danger' style='font-size:12px;'>Above the Range by ".(round((($salary2-$getexe2_5)/$salary2)*100, 2))."%</div>";
		}
				// Executive III
else if ($rank == $rank14){
if ($salary2 < $getexe3_1){
		$stat_text = "<div class='label label-default' style='font-size:12px;'>Below the Range by ".(round((($salary2-$getexe3_1)/$salary2)*100, 2))."%</div>";
		}
 else if ($salary2 >= $getexe3_1 && $salary2 <= $getexe3_2)
		{
		$stat_text = '<div class="label label-primary" style="font-size:12px;">Within Developmental by '.(round((($salary2-$getexe3_1)/($getexe3_2-$getexe3_1))*100, 2)).'% </div>';
		}
 else if ($salary2 >= $getexe3_2 && $salary2 <= $getexe3_3)
		{
		$stat_text = "<div class='label label-info' style='font-size:12px;'>Within Intermidiate by ".(round((($salary2-$getexe3_2)/($getexe3_3-$getexe3_2))*100, 2))."% </div>";
		}
 else if ($salary2 >= $getexe3_3 && $salary2 <= $getexe3_4)
		{
		$stat_text = "<div class='label label-success' style='font-size:12px;'>Within Advanced by ".(round((($salary2-$getexe3_3)/($getexe3_4-$getexe3_3))*100, 2))."%</div>";
		}
 else if ($salary2 >= $getexe3_4 && $salary2 <= $getexe3_5)
		{
		$stat_text = "<div class='label label-warning' style='font-size:12px;'>Within Proficient by ".(round((($salary2-$getexe3_4)/($getexe3_5-$getexe3_4))*100, 2))."%</div>";
		}
		else 
		$stat_text = "<div class='label label-danger' style='font-size:12px;'>Above the Range by ".(round((($salary2-$getexe3_5)/$salary2)*100, 2))."%</div>";
		}
?>
<?php 
if ($rank == $rank1){
if ($analsalary < $getrf1_1){
		$stat_text_anal = "<div class='label label-default' style='font-size:12px;'>Below the Range by ".(round((($analsalary-$getrf1_1)/$analsalary)*100, 2))."%</div>";
		}
 else if ($analsalary >= $getrf1_1 && $analsalary <= $getrf1_2)
		{
		$stat_text_anal = '<div class="label label-primary" style="font-size:12px;">Within Developmental by '.(round((($analsalary-$getrf1_1)/($getrf1_2-$getrf1_1))*100, 2)).'% </div>';
		}
 else if ($analsalary >= $getrf1_2 && $analsalary <= $getrf1_3)
		{
		$stat_text_anal = "<div class='label label-info' style='font-size:12px;'>Within Intermidiate by ".(round((($analsalary-$getrf1_2)/($getrf1_3-$getrf1_2))*100, 2))."% </div>";
		}
 else if ($analsalary >= $getrf1_3 && $analsalary <= $getrf1_4)
		{
		$stat_text_anal = "<div class='label label-success' style='font-size:12px;'>Within Advanced by ".(round((($analsalary-$getrf1_3)/($getrf1_4-$getrf1_3))*100, 2))."%</div>";
		}
 else if ($analsalary >= $getrf1_4 && $analsalary <= $getrf1_5)
		{
		$stat_text_anal = "<div class='label label-warning' style='font-size:12px;'>Within Proficient by ".(round((($analsalary-$getrf1_4)/($getrf1_5-$getrf1_4))*100, 2))."%</div>";
		}
		else 
		$stat_text_anal = "<div class='label label-danger' style='font-size:12px;'>Above the Range by ".(round((($analsalary-$getrf1_5)/$analsalary)*100, 2))."%</div>";
		}

// rank and file 2
else if ($rank == $rank2){
if ($analsalary < $getrf2_1){
		$stat_text_anal = "<div class='label label-default' style='font-size:12px;'>Below the Range by ".(round((($analsalary-$getrf2_1)/$analsalary)*100, 2))."%</div>";
		}
 else if ($analsalary >= $getrf2_1 && $analsalary <= $getrf2_2)
		{
		$stat_text_anal = '<div class="label label-primary" style="font-size:12px;">Within Developmental by '.(round((($analsalary-$getrf2_1)/($getrf2_2-$getrf2_1))*100, 2)).'% </div>';
		}
 else if ($analsalary >= $getrf2_2 && $analsalary <= $getrf2_3)
		{
		$stat_text_anal = "<div class='label label-info' style='font-size:12px;'>Within Intermidiate by ".(round((($analsalary-$getrf2_2)/($getrf2_3-$getrf2_2))*100, 2))."% </div>";
		}
 else if ($analsalary >= $getrf2_3 && $analsalary <= $getrf2_4)
		{
		$stat_text_anal = "<div class='label label-success' style='font-size:12px;'>Within Advanced by ".(round((($analsalary-$getrf2_3)/($getrf2_4-$getrf2_3))*100, 2))."%</div>";
		}
 else if ($analsalary >= $getrf2_4 && $analsalary <= $getrf2_5)
		{
		$stat_text_anal = "<div class='label label-warning' style='font-size:12px;'>Within Proficient by ".(round((($analsalary-$getrf2_4)/($getrf2_5-$getrf2_4))*100, 2))."%</div>";
		}
		else 
		$stat_text_anal = "<div class='label label-danger' style='font-size:12px;'>Above the Range by ".(round((($analsalary-$getrf2_5)/$analsalary)*100, 2))."%</div>";
		}
// staff 1
else if ($rank == $rank3){
if ($analsalary < $gets1_1){
		$stat_text_anal = "<div class='label label-default' style='font-size:12px;'>Below the Range by ".(round((($analsalary-$gets1_1)/$analsalary)*100, 2))."%</div>";
		}
 else if ($analsalary >= $gets1_1 && $analsalary <= $gets1_2)
		{
		$stat_text_anal = '<div class="label label-primary" style="font-size:12px;">Within Developmental by '.(round((($analsalary-$gets1_1)/($gets1_2-$gets1_1))*100, 2)).'% </div>';
		}
 else if ($analsalary >= $gets1_2 && $analsalary <= $gets1_3)
		{
		$stat_text_anal = "<div class='label label-info' style='font-size:12px;'>Within Intermidiate by ".(round((($analsalary-$gets1_2)/($gets1_3-$gets1_2))*100, 2))."% </div>";
		}
 else if ($analsalary >= $gets1_3 && $analsalary <= $gets1_4)
		{
		$stat_text_anal = "<div class='label label-success' style='font-size:12px;'>Within Advanced by ".(round((($analsalary-$gets1_3)/($gets1_4-$gets1_3))*100, 2))."%</div>";
		}
 else if ($analsalary >= $gets1_4 && $analsalary <= $gets1_5)
		{
		$stat_text_anal = "<div class='label label-warning' style='font-size:12px;'>Within Proficient by ".(round((($analsalary-$gets1_4)/($gets1_5-$gets1_4))*100, 2))."%</div>";
		}
		else 
		$stat_text_anal = "<div class='label label-danger' style='font-size:12px;'>Above the Range by ".(round((($analsalary-$gets1_5)/$analsalary)*100, 2))."%</div>";
		}
		
		// staff 2
else if ($rank == $rank4){
if ($analsalary < $gets2_1){
		$stat_text_anal = "<div class='label label-default' style='font-size:12px;'>Below the Range by ".(round((($analsalary-$gets2_1)/$analsalary)*100, 2))."%</div>";
		}
 else if ($analsalary >= $gets2_1 && $analsalary <= $gets2_2)
		{
		$stat_text_anal = '<div class="label label-primary" style="font-size:12px;">Within Developmental by '.(round((($analsalary-$gets2_1)/($gets2_2-$gets2_1))*100, 2)).'% </div>';
		}
 else if ($analsalary >= $gets2_2 && $analsalary <= $gets2_3)
		{
		$stat_text_anal = "<div class='label label-info' style='font-size:12px;'>Within Intermidiate by ".(round((($analsalary-$gets2_2)/($gets2_3-$gets2_2))*100, 2))."% </div>";
		}
 else if ($analsalary >= $gets2_3 && $analsalary <= $gets2_4)
		{
		$stat_text_anal = "<div class='label label-success' style='font-size:12px;'>Within Advanced by ".(round((($analsalary-$gets2_3)/($gets2_4-$gets2_3))*100, 2))."%</div>";
		}
 else if ($analsalary >= $gets2_4 && $analsalary <= $gets2_5)
		{
		$stat_text_anal = "<div class='label label-warning' style='font-size:12px;'>Within Proficient by ".(round((($analsalary-$gets2_4)/($gets2_5-$gets2_4))*100, 2))."%</div>";
		}
		else 
		$stat_text_anal = "<div class='label label-danger' style='font-size:12px;'>Above the Range by ".(round((($analsalary-$gets2_5)/$analsalary)*100, 2))."%</div>";
		}
		// professional
else if ($rank == $rank5){
if ($analsalary < $getpro_1){
		$stat_text_anal = "<div class='label label-default' style='font-size:12px;'>Below the Range by ".(round((($analsalary-$getpro_1)/$analsalary)*100, 2))."%</div>";
		}
 else if ($analsalary >= $getpro_1 && $analsalary <= $getpro_2)
		{
		$stat_text_anal = '<div class="label label-primary" style="font-size:12px;">Within Developmental by '.(round((($analsalary-$getpro_1)/($getpro_2-$getpro_1))*100, 2)).'% </div>';
		}
 else if ($analsalary >= $getpro_2 && $analsalary <= $getpro_3)
		{
		$stat_text_anal = "<div class='label label-info' style='font-size:12px;'>Within Intermidiate by ".(round((($analsalary-$getpro_2)/($getpro_3-$getpro_2))*100, 2))."% </div>";
		}
 else if ($analsalary >= $getpro_3 && $analsalary <= $getpro_4)
		{
		$stat_text_anal = "<div class='label label-success' style='font-size:12px;'>Within Advanced by ".(round((($analsalary-$getpro_3)/($getpro_4-$getpro_3))*100, 2))."%</div>";
		}
 else if ($analsalary >= $getpro_4 && $analsalary <= $getpro_5)
		{
		$stat_text_anal = "<div class='label label-warning' style='font-size:12px;'>Within Proficient by ".(round((($analsalary-$getpro_4)/($getpro_5-$getpro_4))*100, 2))."%</div>";
		}
		else 
		$stat_text_anal = "<div class='label label-danger' style='font-size:12px;'>Above the Range by ".(round((($analsalary-$getpro_5)/$analsalary)*100, 2))."%</div>";
		}
		// section head 1
else if ($rank == $rank6){
if ($analsalary < $getsh1_1){
		$stat_text_anal = "<div class='label label-default' style='font-size:12px;'>Below the Range by ".(round((($analsalary-$getsh1_1)/$analsalary)*100, 2))."%</div>";
		}
 else if ($analsalary >= $getsh1_1 && $analsalary <= $getsh1_2)
		{
		$stat_text_anal = '<div class="label label-primary" style="font-size:12px;">Within Developmental by '.(round((($analsalary-$getsh1_1)/($getsh1_2-$getsh1_1))*100, 2)).'% </div>';
		}
 else if ($analsalary >= $getsh1_2 && $analsalary <= $getsh1_3)
		{
		$stat_text_anal = "<div class='label label-info' style='font-size:12px;'>Within Intermidiate by ".(round((($analsalary-$getsh1_2)/($getsh1_3-$getsh1_2))*100, 2))."% </div>";
		}
 else if ($analsalary >= $getsh1_3 && $analsalary <= $getsh1_4)
		{
		$stat_text_anal = "<div class='label label-success' style='font-size:12px;'>Within Advanced by ".(round((($analsalary-$getsh1_3)/($getsh1_4-$getsh1_3))*100, 2))."%</div>";
		}
 else if ($analsalary >= $getsh1_4 && $analsalary <= $getsh1_5)
		{
		$stat_text_anal = "<div class='label label-warning' style='font-size:12px;'>Within Proficient by ".(round((($analsalary-$getsh1_4)/($getsh1_5-$getsh1_4))*100, 2))."%</div>";
		}
		else 
		$stat_text_anal = "<div class='label label-danger' style='font-size:12px;'>Above the Range by ".(round((($analsalary-$getsh1_5)/$analsalary)*100, 2))."%</div>";
		}
				// section head 2
else if ($rank == $rank7){
if ($analsalary < $getsh2_1){
		$stat_text_anal = "<div class='label label-default' style='font-size:12px;'>Below the Range by ".(round((($analsalary-$getsh2_1)/$analsalary)*100, 2))."%</div>";
		}
 else if ($analsalary >= $getsh2_1 && $analsalary <= $getsh2_2)
		{
		$stat_text_anal = '<div class="label label-primary" style="font-size:12px;">Within Developmental by '.(round((($analsalary-$getsh2_1)/($getsh2_2-$getsh2_1))*100, 2)).'% </div>';
		}
 else if ($analsalary >= $getsh2_2 && $analsalary <= $getsh2_3)
		{
		$stat_text_anal = "<div class='label label-info' style='font-size:12px;'>Within Intermidiate by ".(round((($analsalary-$getsh2_2)/($getsh2_3-$getsh2_2))*100, 2))."% </div>";
		}
 else if ($analsalary >= $getsh2_3 && $analsalary <= $getsh2_4)
		{
		$stat_text_anal = "<div class='label label-success' style='font-size:12px;'>Within Advanced by ".(round((($analsalary-$getsh2_3)/($getsh2_4-$getsh2_3))*100, 2))."%</div>";
		}
 else if ($analsalary >= $getsh2_4 && $analsalary <= $getsh2_5)
		{
		$stat_text_anal = "<div class='label label-warning' style='font-size:12px;'>Within Proficient by ".(round((($analsalary-$getsh2_4)/($getsh2_5-$getsh2_4))*100, 2))."%</div>";
		}
		else 
		$stat_text_anal = "<div class='label label-danger' style='font-size:12px;'>Above the Range by ".(round((($analsalary-$getsh2_5)/$analsalary)*100, 2))."%</div>";
		}
		// department head 1
else if ($rank == $rank8){
if ($analsalary < $getdh1_1){
		$stat_text_anal = "<div class='label label-default' style='font-size:12px;'>Below the Range by ".(round((($analsalary-$getdh1_1)/$analsalary)*100, 2))."%</div>";
		}
 else if ($analsalary >= $getdh1_1 && $analsalary <= $getdh1_2)
		{
		$stat_text_anal = '<div class="label label-primary" style="font-size:12px;">Within Developmental by '.(round((($analsalary-$getdh1_1)/($getdh1_2-$getdh1_1))*100, 2)).'% </div>';
		}
 else if ($analsalary >= $getdh1_2 && $analsalary <= $getdh1_3)
		{
		$stat_text_anal = "<div class='label label-info' style='font-size:12px;'>Within Intermidiate by ".(round((($analsalary-$getdh1_2)/($getdh1_3-$getdh1_2))*100, 2))."% </div>";
		}
 else if ($analsalary >= $getdh1_3 && $analsalary <= $getdh1_4)
		{
		$stat_text_anal = "<div class='label label-success' style='font-size:12px;'>Within Advanced by ".(round((($analsalary-$getdh1_3)/($getdh1_4-$getdh1_3))*100, 2))."%</div>";
		}
 else if ($analsalary >= $getdh1_4 && $analsalary <= $getdh1_5)
		{
		$stat_text_anal = "<div class='label label-warning' style='font-size:12px;'>Within Proficient by ".(round((($analsalary-$getdh1_4)/($getdh1_5-$getdh1_4))*100, 2))."%</div>";
		}
		else 
		$stat_text_anal = "<div class='label label-danger' style='font-size:12px;'>Above the Range by ".(round((($analsalary-$getdh1_5)/$analsalary)*100, 2))."%</div>";
		}
				// department head 2
else if ($rank == $rank9){
if ($analsalary < $getdh2_1){
		$stat_text_anal = "<div class='label label-default' style='font-size:12px;'>Below the Range by ".(round((($analsalary-$getdh2_1)/$analsalary)*100, 2))."%</div>";
		}
 else if ($analsalary >= $getdh2_1 && $analsalary <= $getdh2_2)
		{
		$stat_text_anal = '<div class="label label-primary" style="font-size:12px;">Within Developmental by '.(round((($analsalary-$getdh2_1)/($getdh2_2-$getdh2_1))*100, 2)).'% </div>';
		}
 else if ($analsalary >= $getdh2_2 && $analsalary <= $getdh2_3)
		{
		$stat_text_anal = "<div class='label label-info' style='font-size:12px;'>Within Intermidiate by ".(round((($analsalary-$getdh2_2)/($getdh2_3-$getdh2_2))*100, 2))."% </div>";
		}
 else if ($analsalary >= $getdh2_3 && $analsalary < $getdh2_4)
		{
		$stat_text_anal = "<div class='label label-success' style='font-size:12px;'>Within Advanced by ".(round((($analsalary-$getdh2_3)/($getdh2_4-$getdh2_3))*100, 2))."%</div>";
		}
 else if ($analsalary >= $getdh2_4 && $analsalary <= $getdh2_5)
		{
		$stat_text_anal = "<div class='label label-warning' style='font-size:12px;'>Within Proficient by ".(round((($analsalary-$getdh2_4)/($getdh2_5-$getdh2_4))*100, 2))."%</div>";
		}
		else 
		$stat_text_anal = "<div class='label label-danger' style='font-size:12px;'>Above the Range by ".(round((($analsalary-$getdh2_5)/$analsalary)*100, 2))."%</div>";
		}		
				// Group Head I
else if ($rank == $rank10){
if ($analsalary < $getgh1_1){
		$stat_text_anal = "<div class='label label-default' style='font-size:12px;'>Below the Range by ".(round((($analsalary-$getgh1_1)/$analsalary)*100, 2))."%</div>";
		}
 else if ($analsalary >= $getgh1_1 && $analsalary <= $getgh1_2)
		{
		$stat_text_anal = '<div class="label label-primary" style="font-size:12px;">Within Developmental by '.(round((($analsalary-$getgh1_1)/($getgh1_2-$getgh1_1))*100, 2)).'% </div>';
		}
 else if ($analsalary >= $getgh1_2 && $analsalary <= $getgh1_3)
		{
		$stat_text_anal = "<div class='label label-info' style='font-size:12px;'>Within Intermidiate by ".(round((($analsalary-$getgh1_2)/($getgh1_3-$getgh1_2))*100, 2))."% </div>";
		}
 else if ($analsalary >= $getgh1_3 && $analsalary <= $getgh1_4)
		{
		$stat_text_anal = "<div class='label label-success' style='font-size:12px;'>Within Advanced by ".(round((($analsalary-$getgh1_3)/($getgh1_4-$getgh1_3))*100, 2))."%</div>";
		}
 else if ($analsalary >= $getgh1_4 && $analsalary <= $getgh1_5)
		{
		$stat_text_anal = "<div class='label label-warning' style='font-size:12px;'>Within Proficient by ".(round((($analsalary-$getgh1_4)/($getgh1_5-$getgh1_4))*100, 2))."%</div>";
		}
		else 
		$stat_text_anal = "<div class='label label-danger' style='font-size:12px;'>Above the Range by ".(round((($analsalary-$getgh1_5)/$analsalary)*100, 2))."%</div>";
		}
				// Group Head II
else if ($rank == $rank11){
if ($analsalary < $getgh2_1){
		$stat_text_anal = "<div class='label label-default' style='font-size:12px;'>Below the Range by ".(round((($analsalary-$getgh2_1)/$analsalary)*100, 2))."%</div>";
		}
 else if ($analsalary >= $getgh2_1 && $analsalary <= $getgh2_2)
		{
		$stat_text_anal = '<div class="label label-primary" style="font-size:12px;">Within Developmental by '.(round((($analsalary-$getgh2_1)/($getgh2_2-$getgh2_1))*100, 2)).'% </div>';
		}
 else if ($analsalary >= $getgh2_2 && $analsalary <= $getgh2_3)
		{
		$stat_text_anal = "<div class='label label-info' style='font-size:12px;'>Within Intermidiate by ".(round((($analsalary-$getgh2_2)/($getgh2_3-$getgh2_2))*100, 2))."% </div>";
		}
 else if ($analsalary >= $getgh2_3 && $analsalary <= $getgh2_4)
		{
		$stat_text_anal = "<div class='label label-success' style='font-size:12px;'>Within Advanced by ".(round((($analsalary-$getgh2_3)/($getgh2_4-$getgh2_3))*100, 2))."%</div>";
		}
 else if ($analsalary >= $getgh2_4 && $analsalary <= $getgh2_5)
		{
		$stat_text_anal = "<div class='label label-warning' style='font-size:12px;'>Within Proficient by ".(round((($analsalary-$getgh2_4)/($getgh2_5-$getgh2_4))*100, 2))."%</div>";
		}
		else 
		$stat_text_anal = "<div class='label label-danger' style='font-size:12px;'>Above the Range by ".(round((($analsalary-$getgh2_5)/$analsalary)*100, 2))."%</div>";
		}
		
		// Executive I
else if ($rank == $rank12){
if ($analsalary < $getexe_1){
		$stat_text_anal = "<div class='label label-default' style='font-size:12px;'>Below the Range by ".(round((($analsalary-$getexe_1)/$analsalary)*100, 2))."%</div>";
		}
 else if ($analsalary >= $getexe_1 && $analsalary <= $getexe_2)
		{
		$stat_text_anal = '<div class="label label-primary" style="font-size:12px;">Within Developmental by '.(round((($analsalary-$getexe_1)/($getexe_2-$getexe_1))*100, 2)).'% </div>';
		}
 else if ($analsalary >= $getexe_2 && $analsalary <= $getexe_3)
		{
		$stat_text_anal = "<div class='label label-info' style='font-size:12px;'>Within Intermidiate by ".(round((($analsalary-$getexe_2)/($getexe_3-$getexe_2))*100, 2))."% </div>";
		}
 else if ($analsalary >= $getexe_3 && $analsalary <= $getexe_4)
		{
		$stat_text_anal = "<div class='label label-success' style='font-size:12px;'>Within Advanced by ".(round((($analsalary-$getexe_3)/($getexe_4-$getexe_3))*100, 2))."%</div>";
		}
 else if ($analsalary >= $getexe_4 && $analsalary <= $getexe_5)
		{
		$stat_text_anal = "<div class='label label-warning' style='font-size:12px;'>Within Proficient by ".(round((($analsalary-$getexe_4)/($getexe_5-$getexe_4))*100, 2))."%</div>";
		}
		else 
		$stat_text_anal = "<div class='label label-danger' style='font-size:12px;'>Above the Range by ".(round((($analsalary-$getexe_5)/$analsalary)*100, 2))."%</div>";
		}
						// Executive II
else if ($rank == $rank13){
if ($analsalary < $getexe2_1){
		$stat_text_anal = "<div class='label label-default' style='font-size:12px;'>Below the Range by ".(round((($analsalary-$getexe2_1)/$analsalary)*100, 2))."%</div>";
		}
 else if ($analsalary >= $getexe2_1 && $analsalary <= $getexe2_2)
		{
		$stat_text_anal = '<div class="label label-primary" style="font-size:12px;">Within Developmental by '.(round((($analsalary-$getexe2_1)/($getexe2_2-$getexe2_1))*100, 2)).'% </div>';
		}
 else if ($analsalary >= $getexe2_2 && $analsalary <= $getexe2_3)
		{
		$stat_text_anal = "<div class='label label-info' style='font-size:12px;'>Within Intermidiate by ".(round((($analsalary-$getexe2_2)/($getexe2_3-$getexe2_2))*100, 2))."% </div>";
		}
 else if ($analsalary >= $getexe2_3 && $analsalary <= $getexe2_4)
		{
		$stat_text_anal = "<div class='label label-success' style='font-size:12px;'>Within Advanced by ".(round((($analsalary-$getexe2_3)/($getexe2_4-$getexe2_3))*100, 2))."%</div>";
		}
 else if ($analsalary >= $getexe2_4 && $analsalary <= $getexe2_5)
		{
		$stat_text_anal = "<div class='label label-warning' style='font-size:12px;'>Within Proficient by ".(round((($analsalary-$getexe2_4)/($getexe2_5-$getexe2_4))*100, 2))."%</div>";
		}
		else 
		$stat_text_anal = "<div class='label label-danger' style='font-size:12px;'>Above the Range by ".(round((($analsalary-$getexe2_5)/$analsalary)*100, 2))."%</div>";
		}
				// Executive III
else if ($rank == $rank14){
if ($analsalary < $getexe3_1){
		$stat_text_anal = "<div class='label label-default' style='font-size:12px;'>Below the Range by ".(round((($analsalary-$getexe3_1)/$analsalary)*100, 2))."%</div>";
		}
 else if ($analsalary >= $getexe3_1 && $analsalary <= $getexe3_2)
		{
		$stat_text_anal = '<div class="label label-primary" style="font-size:12px;">Within Developmental by '.(round((($analsalary-$getexe3_1)/($getexe3_2-$getexe3_1))*100, 2)).'% </div>';
		}
 else if ($analsalary >= $getexe3_2 && $analsalary <= $getexe3_3)
		{
		$stat_text_anal = "<div class='label label-info' style='font-size:12px;'>Within Intermidiate by ".(round((($analsalary-$getexe3_2)/($getexe3_3-$getexe3_2))*100, 2))."% </div>";
		}
 else if ($analsalary >= $getexe3_3 && $analsalary <= $getexe3_4)
		{
		$stat_text_anal = "<div class='label label-success' style='font-size:12px;'>Within Advanced by ".(round((($analsalary-$getexe3_3)/($getexe3_4-$getexe3_3))*100, 2))."%</div>";
		}
 else if ($analsalary >= $getexe3_4 && $analsalary <= $getexe3_5)
		{
		$stat_text_anal = "<div class='label label-warning' style='font-size:12px;'>Within Proficient by ".(round((($analsalary-$getexe3_4)/($getexe3_5-$getexe3_4))*100, 2))."%</div>";
		}
		else 
		$stat_text_anal = "<div class='label label-danger' style='font-size:12px;'>Above the Range by ".(round((($analsalary-$getexe3_5)/$analsalary)*100, 2))."%</div>";
		}

?>
		


<script>
		$(document).ready(function(){

    $('[data-toggle="tooltip"]').tooltip();  
});

$("#analyze").click(function(){
var empidrate = "<?php echo $id; ?>";
var percent = $('input[name="percent"]').val();
$(".loader").fadeIn();		
  
  				  setTimeout(
  function() 
  {
  
  $(".content-loader").load('analyze.php?edit_id='+empidrate+'&percent='+percent);
    $("#btn-view").fadeIn();
    }, 2000);

	  setTimeout(
  function() 
  {

$(".loader").fadeOut();
  }, 3000);
		});

		</script>

<style type="text/css">
#dis{
	display: none;
	margin-left: 70px;
	position: fixed;
	top: 50px;
	width: 68%;
	padding:20px;
	z-index:99999;
}
  .loader {
	position: fixed;
	left: 0px;
	top: 0px;
	width: 100%;
	height: 100%;
	z-index: 9999;
	background: url('../../img/loading.gif') 50% 50% no-repeat rgb(249,249,249);
	opacity: .5;
}

#square {
background-color: #ECECFF;
-webkit-box-shadow: 0px 0px 2px rgba(50, 50, 50, 0.31);
    -moz-box-shadow:    0px 0px 5px rgba(50, 50, 50, 0.31);
    box-shadow:         0px 0px 10px rgba(50, 50, 50, 0.31);
padding:20px;
}
.check{
width:15px;
height:15px;
}


#btn-add {
position:relative;
border-radius: 100%;
top:10px;
padding-top:25px;
padding-bottom: 25px;
padding-left: 25px;
padding-right: 25px;
font-size:36px;
	-webkit-box-shadow: 0px 0px 10px rgba(50, 50, 50, 20);
    -moz-box-shadow:    0px 0px 10px rgba(50, 50, 50, 20);
    box-shadow:         0px 0px 10px rgba(50, 50, 50, 20);
}
#btn-add:focus{
outline: 0px;
}

  @media only screen and (max-width: 768px) 
{ 
#dis{
	top: 75px;
	margin-left: 0;
	width:70%
}

</style>
    <div id="dis">
    <!-- here message will be displayed -->
	</div>

<div class="row">
<div class="col-sm-4">
<b>Name:</b> <?php echo $name; ?>
</div>
<div class="col-sm-4">
<b>Position:</b> <?php echo $pos; ?></div>
<div class="col-sm-4">
<b>Job Rank:</b> <?php echo $rank; ?></div>
</div>
<div class="row">
<div class="col-sm-4">
<b>Current Salary:</b> <?php echo $salary; ?></div>
<div class="col-sm-4">
<b>Allowance:</b> <?php echo $allowance; ?></div>
<div class="col-sm-4">
<b>Status:</b> <c class="label label-primary"><?php echo $stat; ?></c></div>
</div>
<div class="row">
<div class="col-sm-4">
<b>Current Salary Status:</b> <?php echo $stat_text; ?>
</div>
<div class="col-sm-4">
<b>Date Hired:</b> <?php echo $hired; ?></div>
<div class="col-sm-4">
<b>Last Adjustment of Salary:</b> <?php echo $date_sal_pre; ?></div>
</div>
<div class="square">
<c class="title"> Analyze Salary </c><br />
Input a number in the <b>textbox</b> provided below then click <b>Analyze</b> button to see the results.<hr />
Percent you want to increase/analyze <input type="text" style="padding:5px; width:100px;" maxlength="5" onkeypress='return event.charCode >= 45 && event.charCode <= 57 && event.charCode != 47' value="<?php if($percent == 0) echo ""; else echo $percent; ?>" name="percent" id="percent" />% for the salary of <?php echo $salary; ?>.&nbsp;&nbsp;<button class="btn btn-default" id="analyze">Analyze</button>
<?php if($percent != 0)
{
?>
<br /><h4>
<c class="text text-primary">Salary + <?php echo $percent; ?>% = <?php echo $analsalaryprint; ?></c>
&nbsp;<?php echo $stat_text_anal ?></h4>
</div>
<br />
<table class="table table-bordered">
<tr>
<td><b>Description</b></td>
<td><b>Php</b></td>
</tr>
<tr>
<td>Total analyzed salary with allowance</td><td><?php echo $wallow; ?></td>
</tr>
<tr>
<td>Total analyzed salary without allowance</td><td><?php echo $analsalaryprint; ?></td>
</tr>
</table>
	<?php } ?>	

    