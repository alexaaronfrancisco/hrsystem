<?php
include('session.php');
// Establishing Connection with Server by passing server_name, user_id and password as a parameter
$connection = mysql_connect("localhost", "root", "polyester10");
// Selecting Database
$db = mysql_select_db("hrsystem", $connection);
if(session_destroy()) // Destroying All Sessions
{
$trail = mysql_query("INSERT INTO trail (type, per_action, emp_id) VALUES ('Session', 'Signed-Out', '$user_check')", $connection);
header("Location: index.php"); // Redirecting To Home Page
}
?>