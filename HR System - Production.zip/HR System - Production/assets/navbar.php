<style>
.drop {
font-size:12px;
background-color:#111;
display:none;
 text-indent: 30px;
    line-height: 30px;
}

.drop2 {
font-size:12px;
background-color:#111;
display:none;
 text-indent: 30px;
    line-height: 30px;
}

.drop3 {
font-size:12px;
background-color:#111;
display:none;
 text-indent: 30px;
    line-height: 30px;
}

.drop4 {
font-size:12px;
background-color:#111;
display:none;
 text-indent: 30px;
    line-height: 30px;
}

.drop5 {
font-size:12px;
background-color:#111;
display:none;
 text-indent: 30px;
    line-height: 30px;
}

  @media only screen and (max-width: 768px) 
{ 
#footer{
display:none;
visibility:hidden;
}
}

</style>
    <script>
    $("#menu-toggle").click(function(e) {
        e.preventDefault();
        $("#wrapper").toggleClass("toggled");
    });	    
	    $(".main").click(function(e) {
        e.preventDefault();
        $(".drop").slideToggle();
		$(".drop2").slideUp();
		$(".drop3").slideUp();
		$(".drop4").slideUp();
		$(".drop5").slideUp();
    });
		$(".ijsm").click(function(e) {
        e.preventDefault();
        $(".drop2").slideToggle();
		$(".drop").slideUp();
		$(".drop3").slideUp();
		$(".drop4").slideUp();
		$(".drop5").slideUp();
    });
	    $(".opms").click(function(e) {
        e.preventDefault();
        $(".drop3").slideToggle();
		$(".drop").slideUp();
		$(".drop2").slideUp();
		$(".drop4").slideUp();
		$(".drop5").slideUp();
    });
		$(".rprt").click(function(e) {
        e.preventDefault();
        $(".drop4").slideToggle();
		$(".drop").slideUp();
		$(".drop2").slideUp();
		$(".drop3").slideUp();
		$(".drop5").slideUp();
    });
		$(".util").click(function(e) {
        e.preventDefault();
        $(".drop5").slideToggle();
		$(".drop").slideUp();
		$(".drop2").slideUp();
		$(".drop3").slideUp();
		$(".drop4").slideUp();
    });	   
	$(".dropdowntogs").click(function(e) {
        e.preventDefault();
        $(".dropmenu").toggle();
    });
	$(document).click(function(e) {
  if ( $(e.target).closest('.dropdowntogs').length === 0 ) {
    // hide menu here
	$(".dropmenu").hide();
  }
}); 
	
		   

    </script>
