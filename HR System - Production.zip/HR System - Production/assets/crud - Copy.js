// JavaScript Document

$(document).ready(function(){
	
	/* Data Insert Starts Here */
	$(document).on('submit', '#emp-SaveForm', function() {
	  	$(this).attr("disabled","disabled");
	   $.post("create.php", $(this).serialize())
        .done(function(data){
			$("#dis").fadeOut();
			$("#dis").fadeIn('slow', function(){
				 $("#dis").html('<div class="alert alert-success"><span class="glyphicon glyphicon-ok">&nbsp;</span>'+data+'</div>'); 
				     setTimeout(function(){
        $("#dis").fadeOut();
    }, 3000);
					  $(".loader").fadeIn();
					  setTimeout(
  function() 
  {
$(".loader").fadeOut();
  }, 2000);
					  
					 setTimeout(
  function() 
  {
$(".content-loader").load('add_form.php');
  }, 3000);
		     });	
		 });   
	     return false;
    });
	/* Data Insert Ends Here */
	
	
	/* Data Delete Starts Here */
	$(".delete-link").click(function()
	{	
		$(this).attr("disabled","disabled");
		var id = $(this).attr("id");
		var del_id = id;
		var parent = $(this).parent("td").parent("tr");
		if(confirm('Are your sure to delete ID # = ' +del_id))
		{
			$.post('delete.php', {'del_id':del_id}, function(data)
			{
				parent.fadeOut('slow');
			});	
		}
		return false;
	});
	/* Data Delete Ends Here */
	
	/* Get Edit ID  */
	$(".edit-link").click(function()
	{
		$(this).attr("disabled","disabled");
		var id = $(this).attr("id");
		var edit_id = id;
		if(confirm('Are you sure to edit ID # = ' +edit_id))
		{
			$(".content-loader").fadeOut('slow', function()
			 {
				$(".content-loader").fadeIn('slow');
				$(".content-loader").load('edit_form.php?edit_id='+edit_id);
				$("#btn-add").hide();
				$("#btn-view").show();
			});
		}
		return false;
	});
	/* Get Edit ID  */
	
	/* Update Record  */
	$(document).on('submit', '#emp-UpdateForm', function() {
														 
	 	$(this).attr("disabled","disabled");
	   $.post("update.php", $(this).serialize())
        .done(function(data){
			$("#dis").fadeOut();
			$("#dis").fadeIn('slow', function(){
				 $("#dis").html('<div class="alert alert-success"><span class="glyphicon glyphicon-ok">&nbsp;</span>'+data+'</div>');
				     setTimeout(function(){
        $("#dis").fadeOut();
    }, 3000); 					
					  $(".loader").fadeIn();
					  setTimeout(
  function() 
  {
$(".loader").fadeOut();
  }, 2000);
					  
					 setTimeout(
  function() 
  {
window.location.href="index.php";
  }, 3000);
					
			
		     });	
		});   
	    return false;
    });
	/* Update Record  */
});
