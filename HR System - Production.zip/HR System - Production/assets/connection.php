<?php
session_start();
$user_check = $_SESSION['login_user'];
$connection = mysql_connect("localhost", "root", "polyester10");
$db = mysql_select_db("hrsystem", $connection);
?>