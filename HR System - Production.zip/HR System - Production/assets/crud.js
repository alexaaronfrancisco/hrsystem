// JavaScript Document

$(document).ready(function(){
	
	/* Data Insert Starts Here */
	$(document).on('submit', '#emp-SaveForm', function() {
													   $(".loader").fadeIn();
	   $(this).attr("disabled","disabled");
	   $("#btn-save").attr("disabled","disabled");
	   $.post("create.php", $(this).serialize())
        .done(function(data){
			$("#dis").fadeOut();
			$("#dis").fadeIn('slow', function(){
				 $("#dis").html('<div class="alert alert-success"><span class="glyphicon glyphicon-ok">&nbsp;</span>'+data+'</div>'); 
				     setTimeout(function(){
        $("#dis").fadeOut();
    }, 3000);
					  $(".loader").fadeIn();
					  setTimeout(
  function() 
  {
$(".loader").fadeOut();
  }, 2000);
					  
					 setTimeout(
  function() 
  {
$(".content-loader").load('add_form.php');
  }, 3000);
		     });	
		 });   
	     return false;
    });
	/* Data Insert Ends Here */	
	
/* MODAL DELETE */	

	var del;
	var parent;
	var iddel;
	/* Data Delete Starts Here */
	$(".delete-link").click(function()
	{	
	$(this).attr("disabled","disabled");
	iddel = $(this).attr("id");
	del_id = iddel;
	parent = $(this).parent("td").parent("tr");
	$("#empiddel").text(del_id);
	$("#modaldelete").modal("show");
		});
	$("#yesdelete").click(function()
	{		$("#modaldelete").modal("hide");
			$.post('delete.php', {'del_id':del_id}, function(data)
			{
				parent.fadeOut('slow');
			});	
			});
	/* Data Delete Ends Here */
	
	var idedit;
	var edit_id;
	/* Get Edit ID  */
	$(".edit-link").click(function()
	{
	
		$(this).attr("disabled","disabled");
		idedit = $(this).attr("id");
		edit_id = idedit;	
			$("#empidedit").text(edit_id);
					$("#modaledit").modal("show");
	});
	
	$("#yesedit").click(function()
		{
						$("#modaledit").modal("hide");
			$(".content-loader").fadeOut('slow', function()
			 {
				$(".content-loader").fadeIn('slow');
				$(".content-loader").load('edit_form.php?edit_id='+edit_id);
				$("#btn-add").hide();
				$("#btn-view").show();
			});
			});
	/* Get Edit ID  */

<!---- MODAL ENDS HERE ----->

	/* Update Record  */
	$(document).on('submit', '#emp-UpdateForm', function() {
														 
	 	$(this).attr("disabled","disabled");
	   $.post("update.php", $(this).serialize())
        .done(function(data){
			$("#dis").fadeOut();
			$("#dis").fadeIn('slow', function(){
				 $("#dis").html('<div class="alert alert-success"><span class="glyphicon glyphicon-ok">&nbsp;</span>'+data+'</div>');
				     setTimeout(function(){
        $("#dis").fadeOut();
    }, 3000); 					
					  $(".loader").fadeIn();
					  setTimeout(
  function() 
  {
$(".loader").fadeOut();
  }, 2000);
					  
					 setTimeout(
  function() 
  {
window.location.href="index.php";
  }, 3000);
					
			
		     });	
		});   
	    return false;
    });
	/* Update Record  */
});
