	    <link href="../../bootstrap/css/bootstrap-datepicker.css" rel="stylesheet" type="text/css"/>
		<script src="../../bootstrap/js/bootstrap-datepicker.min.js"></script>
		<script src="../../assets/bootstrap-formhelpers-phone.js"></script>
		
<?php 
require_once '../../assets/connection.php';

$perid = $_GET['id'];
$perid_sql=mysql_query("select * from getper_ans where per_id='$perid'", $connection);
$rowper = mysql_fetch_assoc($perid_sql);
$per_id =$rowper['emp_id'];
$rater =$rowper['raterid'];
$rdate =$rowper['date'];
$totalweight =$rowper['total'];
$perresult =$rowper['result'];
$ratedate = date('F d, Y | h:i A', strtotime($rdate));

$ratername_sql=mysql_query("select emp_name from emp_personal_data where emp_id='$rater'", $connection);
$rowrname = mysql_fetch_assoc($ratername_sql);
$ratername =$rowrname['emp_name'];

//get ORG CAT PER
$org_sql=mysql_query("select * from emp_job_data where emp_id='$per_id'", $connection);
$roworg = mysql_fetch_assoc($org_sql);
$orgperresult =$roworg['orgper_category'];
//name
$name_sql=mysql_query("select * from emp_personal_data where emp_id='$per_id'", $connection);
$rowname = mysql_fetch_assoc($name_sql);
$empname =$rowname['emp_name'];
$fname =$rowname['fname'];
//position and deptpartment
$pos_sql=mysql_query("select title, dept from emp_job_data where emp_id='$per_id'", $connection);
$rowpos = mysql_fetch_assoc($pos_sql);
$pos = $rowpos['title'];
$dept = $rowpos['dept'];
//wpg score
$score_sql=mysql_query("select * from getper_ans where per_id='$perid'", $connection);
$rowscored = mysql_fetch_assoc($score_sql);
$wpgscores =$rowscored['WPG_cal'];
$wpgtotalscore =$rowscored['WPG_score'];
$wpgscorearray = explode(", ",$wpgscores);
$wpgtotalscorearray = explode(" | ",$wpgtotalscore);
//wpg
$wpg_sql=mysql_query("select * from wpg_percent where emp_id='$per_id'", $connection);
$rowwpg = mysql_fetch_assoc($wpg_sql);
$wpgentry =$rowwpg['goal'];
$wpgentryval =$rowwpg['value'];
$wpgentryarray = explode(" + ",$wpgentry);
$wpgentryvalarray = explode(", ",$wpgentryval);
$wpgcountarray = count($wpgentryarray);

//wpa score
$score_sql2=mysql_query("select * from getper_ans where per_id='$perid'", $connection);
$rowscored2 = mysql_fetch_assoc($score_sql2);
$wpascores =$rowscored2['WPA_cal'];
$wpatotalscore =$rowscored2['WPA_score'];
$wpascorearray = explode(", ",$wpascores);
$wpacountscorearray = count($wpascorearray);
$wpatotalscorearray = explode(" | ",$wpatotalscore);

//WPA
$count_sql=mysql_query("select * from wpa_percent", $connection);
$row5 = mysql_num_rows($count_sql);

//ORG. Percent

$stafflevel = mysql_query("select * from emp_job_data where emp_id='$per_id' AND job_id BETWEEN 1 AND 4", $connection);
		$staffrow = mysql_num_rows($stafflevel);
		$visorlevel = mysql_query("select * from emp_job_data where emp_id='$per_id' AND job_id BETWEEN 5 AND 7", $connection);
		$visorrow = mysql_num_rows($visorlevel);
		$manalevel = mysql_query("select * from emp_job_data where emp_id='$per_id' AND job_id BETWEEN 8 AND 11", $connection);
		$manarow = mysql_num_rows($manalevel);
		$wpgperget = "";
		$wpaperget = "";
		
		if ($staffrow == 1){
		//WPG
		$wpgper = mysql_query("select percent from org_percent where org_percent_id = 1", $connection);
		$wpgrow = mysql_fetch_assoc($wpgper);
		$wpgperget =$wpgrow['percent'];
		//WPA
		$wpaper = mysql_query("select percent from org_percent where org_percent_id = 2", $connection);
		$wparow = mysql_fetch_assoc($wpaper);
		$wpaperget =$wparow['percent'];
		}
		else if ($visorrow == 1){
		//WPG
		$wpgper = mysql_query("select percent from org_percent where org_percent_id = 3", $connection);
		$wpgrow = mysql_fetch_assoc($wpgper);
		$wpgperget =$wpgrow['percent'];
		//WPA
		$wpaper = mysql_query("select percent from org_percent where org_percent_id = 4", $connection);
		$wparow = mysql_fetch_assoc($wpaper);
		$wpaperget =$wparow['percent'];
		}
		else if ($manarow == 1){
		//WPG
		$wpgper = mysql_query("select percent from org_percent where org_percent_id = 5", $connection);
		$wpgrow = mysql_fetch_assoc($wpgper);
		$wpgperget =$wpgrow['percent'];
		//WPA
		$wpaper = mysql_query("select percent from org_percent where org_percent_id = 6", $connection);
		$wparow = mysql_fetch_assoc($wpaper);
		$wpaperget =$wparow['percent'];
		}

?>

<script>
/*window.onbeforeunload = function (evt) {
   if(window.nounloadcheck == true) return; // ignore
  var message = 'Changes you saved may not be saved.';
  if (typeof evt == 'undefined') {
  evt = window.event;
  }
  if (evt) {
  evt.returnValue = message;
  }
  return message;
  }
*/

		
 $(document).ready(function(){
    var hContent = $("body").height(); // get the height of your content
    var hWindow = $(window).height();  // get the height of the visitor's browser window

    // if the height of your content is bigger than the height of the 
    // browser window, we have a scroll bar
    if(hContent>hWindow) {
	$('.footer').css("position","absolute");
        return true;    
    }

    return false;
});
<!----- PRINT IT ------->

$("#print").click(function() {
	 $("#modalprint").modal('show');
});


$("#yes").click(function() {
	 			 		$("#modalprint").modal("hide");
						$("#logo").removeAttr("style");
											 	$("#scorecard").attr("style","display:none;");
					 	$(".footer").attr("style","display:none;");
		 				$(".hideprint").attr("style","display:none;");
					 	$(".hidesal").attr("style","display:none;");
						$("#bday").css("border","0px solid grey");
						$("textarea").css("border","0px solid grey");
			var printit = $("#printthis").html()
            $("#printme").html(printit);
            window.print();
									$("textarea").css("border","1px solid grey");
			$("#bday").css("border","1px solid green");
			$("#logo").attr("style","display:none;");
			$(".hideprint").removeAttr("style");
						$("#scorecard").removeAttr("style");
			$(".footer").removeAttr("style");
			$(".hidesal").removeAttr("style");
			$("#printme").html("");
			


	 });



		</script>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <link href="../../bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css"/>
	<link href="../../bootstrap/css/sidebar.css" rel="stylesheet" type="text/css"/>
<script src="../../bootstrap/js/bootstrap.js"></script>
<script src="../../bootstrap/js/jquery-1.12.0.js"></script>
<script src="../../bootstrap/js/bootstrap.min.js"></script>
	    <link href="../../bootstrap/css/bootstrap-datepicker.css" rel="stylesheet" type="text/css"/>
		<script src="../../bootstrap/js/bootstrap-datepicker.min.js"></script>
		
		
</head>
<style>
@import url('https://fonts.googleapis.com/css?family=Tauri');
body{font-family: 'Tauri', sans-serif;}
.title{font-size:18px;
padding-bottom: 20px;
color: #0066CC;
width:100%;}
#result{
	display: none;
	margin-left: 70px;
	position: fixed;
	top: 0px;
	width: 70%;
	padding:20px;
	z-index:99999;
}
textarea {
width:100%;
  height: 110px;
}

  @page { size: Portrait; }

.panel-title {
color:#FFFFFF;
}

@media print {
#hidesal{
display:none;}
#hideprint{
display:none;}
#page-content-wrapper{
top:0;
}
#details {
font-size:12px;
}
	#printthis, #printthis * {
	visibility: visible;
  }	
	
@page { size: Portrait; }
}
  

  @media only screen and (max-width: 768px) 
{ 
#result{
	top: 75px;
	margin-left: 0;
	width:70%
}
}
</style>
<body>
 <div id="result">
    <!-- here message will be displayed -->
	</div>
	
	<!-- Modal -->

  <div class="modal fade" id="modalprint" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h3 class="modal-title text-primary"><span class="glyphicon glyphicon-print"> </span> Print Scorecard</h3>
        </div>
        <div class="modal-body">
		<br />
          <p>Are you sure you want to print <?php echo $fname."'s"; ?> scorecard?</p>
        </div>
        <div class="modal-footer">
		  <button type="button" id="no" value="no" data-dismiss="modal" class="btn btn-default" > Cancel </button>
		  <button type="button" id="yes" value="yes" class="btn btn-primary" autofocus > Ok </button>
		
        </div>
      </div>
      
    </div>
  </div>	
  <div id="printthis">
	<center>
	<img src="../../img/comlogo.jpg" width="200" height="50">
	<h3>ORGANIZATIONAL PERFORMANCE MANAGEMENT SYSTEM</h3>
	<i><h4>Scorecard</h4></i>
	<div id="scorecard">
	   <div class="row">
	<div class="col-xs-0 col-md-1"></div>
	 <div class="col-xs-6 col-md-2">
            
            <div class="panel status panel-primary">
                <div class="panel-heading" style="background:#0000FF;">
                    <h1 class="panel-title text-center">Substandard</h1>
                </div>
                <div class="panel-body text-center">                        
                    <strong>1.00 - 1.25</strong>
                </div>
            </div>

        </div>          
	
        <div class="col-xs-6 col-md-2">
            
            <div class="panel status panel-success">
                <div class="panel-heading" style="background:#009900;">
                    <h1 class="panel-title text-center">Marginal</h1>
                </div>
                <div class="panel-body text-center">                        
                    <strong>1.26 - 1.50</strong>
                </div>
            </div>

        </div>          
        <div class="col-xs-6 col-md-2">
          
            <div class="panel status panel-info">
                <div class="panel-heading" style="background:#00CCFF;">
                    <h1 class="panel-title text-center">Normative</h1>
                </div>
                <div class="panel-body text-center">                        
                    <strong>1.51 - 3.49</strong>
                </div>
            </div>

        </div>
        <div class="col-xs-6 col-md-2">
           
            <div class="panel status panel-warning">
                <div class="panel-heading" style="background:#FF9900;">
                    <h1 class="panel-title text-center">Proficient</h1>
                </div>
                <div class="panel-body text-center">                        
                    <strong>3.50 - 3.75</strong>
                </div>
            </div>

         
        </div>
        <div class="col-xs-6 col-md-2">
          
            <div class="panel status panel-danger">
                <div class="panel-heading" style="background:#FF0000;">
                    <h1 class="panel-title text-center">Exemplary</h1>
                </div>
                <div class="panel-body text-center">                        
                    <strong>3.76 - 4.00</strong>
                </div>
            </div>

        </div>
			<div class="col-xs-0 col-md-1"></div>
			</div>
</div>
</center>
        <table cellspacing="0" width="100%" id="details" class="table table-bordered table-condensed table-responsive" style="font-size:12px;" >
		<tbody>
		<tr>
		<td><b>Employee Name : </b> <?php echo $empname; ?></td>
		<td><b>Position : </b> <?php echo $pos; ?></td>
		<td><b>Department/Section : </b> <?php echo $dept; ?></td>
		</tr>
		<tr>
		<td><b>Rater Name : </b> <?php echo $ratername; ?></td>
		<td><b>Date Rated : </b> <?php echo $ratedate; ?></td>
		</tr>
		</tbody>
		</table>
        <table cellspacing="0" width="100%" id="example" class="table table-bordered table-hover table-condensed table-responsive" style="font-size:14px;" >
		<tbody>
<tr style="background-color:#C7DCDC;">
	<td><b>PART I.	Work Performance Goals (WPG)</b></td>
	<td><b>% Weights</b></td>
	<td><b>Weighted Score</b></td>	
	</tr>
	<?php $wpgadd = 0;
			while($wpgadd != $wpgcountarray){
			?>
			<tr>
			<td><ul style="list-style-type:none">
			  <li><?php echo $wpgentryarray[$wpgadd]; ?></li>
			</ul> </td>
			<td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<?php echo $wpgentryvalarray[$wpgadd]."%"; ?></td>
			<td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<?php echo $wpgscorearray[$wpgadd]; ?></td> 
		  	</tr>
			<?php $wpgadd++; } ?>
			<tr style="background-color:#C7DCDC;">
			<td><b>TOTAL</b></td>
			<td><b>100%</b></td>
			<td><b><?php echo number_format($wpgtotalscorearray[0],2); ?></b></td>
			</tr>
</tbody></table>
        <table cellspacing="0" width="100%" id="example" class="table table-bordered table-hover table-condensed table-responsive" style="font-size:14px;" >
		<tbody>
				<tr style="background-color:#FFFF99;">
	<td><b>PART II.	Work Performance Appraisal (WPA)</b></td>
	<td><b>% Weights</b></td>
	<td><b>Weighted Score</b></td>	
	</tr>
	<?php		
	$d = 0;
$c = 0;
$b = 0;
$a = 1;
$z = 0;	
$getsubtotal = 0;
$getcountarr = 0;
while ($b < $row5){
//category
$cat_sql=mysql_query("select * from wpa_percent where wpa_percent_id=$a", $connection);
$row6 = mysql_fetch_assoc($cat_sql);
$cat_entry =$row6['category'];
//tanong
$tanong_entry =$row6['question'];
$convert_tanong=explode(" + ",$tanong_entry);
$convert_ques = $convert_tanong;
$countarr = count($convert_ques);
//values
$val_entry =$row6['percent'];
$convert_val=explode(", ",$val_entry);
$getcountarr+=$countarr;
while ($z < $getcountarr){
$getsubtotal+=$wpascorearray[$z];
$z++;}

?>
	<tr style="background-color:#FFFFCC;">
	<td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<b><?php echo $cat_entry; ?></b></td>
	<td><b><?php echo array_sum($convert_val)."%"; ?></b></td>
	<td><b><?php echo "Subtotal : ".$getsubtotal; ?></b></td>
	</tr> <?php
	while($c < $countarr){
			?>
			<tr>
			<td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<?php echo $convert_tanong[$c]; ?></td>
			<td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<?php echo $convert_val[$c]."%"; ?></td>
			<?php if($d != $getcountarr){ ?>
			<td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<?php echo $wpascorearray[$d]; ?></td> 
		  	</tr>
			<?php } $c++; $d++; }
$a++;			
$b++;
$c=0;
$getsubtotal=0;
}
?>

			<tr style="background-color:#FFFF99;">
			<td><b>TOTAL</b></td>
			<td><b>100%</b></td>
			<td><b><?php echo number_format($wpatotalscorearray[0],2); ?></b></td>
			</tr>
			</tbody>
        </table>			
			<table cellspacing="0" width="100%" id="example" class="table table-bordered table-hover table-condensed table-responsive" style="font-size:14px;" >
		<tbody>
		<tr style="background-color:#FFCCFF;">
		<td align="center">SCORECARD SUMMARY</td>
		</tr>
		<tr>
		<td><b>Performance Dimensions</b></td>
		<td><b>Scores</b></td>
		<td><b>% Weight</b></td>
		<td><b>Weighted Score</b></td>
		<td><b>Indv. Performance Category</b></td>
		<td><b>Org. Performance Category</b></td>
		</tr>
		<tr>
		<td><ul style="list-style-type:none">
			  <li> I. Work Performace Goal</li>
			</ul> </td>
		<td style="background-color:#C7DCDC;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<b><?php echo number_format($wpgtotalscorearray[0],2); ?></b></td>
		<td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<?php echo $wpgperget."%"; ?></td>
		<td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<b><?php echo $wpgtotalscorearray[1]; ?></b></td>
		<td style="background-color:#999999;"></td>
				<td style="background-color:#999999;"></td>
		</tr>
		<tr>
		<td><ul style="list-style-type:none">
			  <li> II. Work Performace Attributes</li>
			</ul> </td>
		<td style="background-color:#FFFF99;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<b><?php echo number_format($wpatotalscorearray[0],2); ?></b></td>
		<td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<?php echo $wpaperget."%"; ?></td>
		<td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<b><?php echo $wpatotalscorearray[1]; ?></b></td>
		<td style="background-color:#999999;"></td>
				<td style="background-color:#999999;"></td>
		</tr>
		<tr>		
		<td><b>Final Weighted Performance Score</b></td>
		<td></td>
		<td></td>
		<td><b><?php echo number_format($totalweight,2); ?></b></td>
		<td><b><?php echo $perresult; ?></b></td>
		<td><b><?php echo $orgperresult; ?></b></td>
		</tr>
			
		</tbody>
        </table>	
		
		<center><div id="logo" style="display:none;">
		Powered by: <img src="../../img/logo.jpg" width="200" height="50">
		</div>
		</center>
		
		</div>
    </body>
</html>