	    <link href="../../bootstrap/css/bootstrap-datepicker.css" rel="stylesheet" type="text/css"/>
		<script src="../../bootstrap/js/bootstrap-datepicker.min.js"></script>
		<script src="../../assets/bootstrap-formhelpers-phone.js"></script>
		
<?php 
require_once '../../assets/connection.php';

$perid = $_GET['id'];
$perid_sql=mysql_query("select emp_id from ern_data where ern_id='$perid'", $connection);
$rowper = mysql_fetch_assoc($perid_sql);
$per_id =$rowper['emp_id'];

$name_sql=mysql_query("select emp_name from emp_personal_data where emp_id='$per_id'", $connection);
$rowname = mysql_fetch_assoc($name_sql);
$name =$rowname['emp_name'];

$fname_sql=mysql_query("select fname from emp_personal_data where emp_id='$per_id'", $connection);
$rowfname = mysql_fetch_assoc($fname_sql);
$fname =$rowfname['fname'];

$data_sql=mysql_query("select dept, title from emp_job_data where emp_id='$per_id'", $connection);
$rowdata = mysql_fetch_assoc($data_sql);
$datadept =$rowdata['dept'];
$datapos =$rowdata['title'];

?>
<script>
/*window.onbeforeunload = function (evt) {
   if(window.nounloadcheck == true) return; // ignore
  var message = 'Changes you saved may not be saved.';
  if (typeof evt == 'undefined') {
  evt = window.event;
  }
  if (evt) {
  evt.returnValue = message;
  }
  return message;
  }
*/
$('input[name="bday"]').change(function(){
            if ($('#bday').val() == '') {                
$("#bday").css("border","1px solid red");
$("#print").attr('disabled','disabled');
            }
else {
$("#bday").css("border","1px solid green");
$("#err_sal").text("");
$("#print").removeAttr('disabled');
}

});
 	


 $(document).ready(function(){
$('input[name="bday"]').datepicker({
		autoclose: true,
		format: "M dd, yyyy",
		startView: 'month'     
		})
		$("#bday").css("border","1px solid red");
        });
		
 $(document).ready(function(){
    var hContent = $("body").height(); // get the height of your content
    var hWindow = $(window).height();  // get the height of the visitor's browser window

    // if the height of your content is bigger than the height of the 
    // browser window, we have a scroll bar
    if(hContent>hWindow) {
	$('.footer').css("position","absolute");
        return true;    
    }

    return false;
});
<!----- PRINT IT ------->

$("#print").click(function() {
	 $("#modalprint").modal('show');
});


$("#yes").click(function() {
var ern_id = <?php echo $perid; ?>;
var datepass = $("#bday").val();
 			$.ajax({
            type: "POST",
            url: "getresult.php", //process to update
			data: {perid : ern_id , datepass : datepass},										
            success: function(){}
});

	 			 		$("#modalprint").modal("hide");
						$("#logo").removeAttr("style");
												$("#power").removeAttr("style");
					 	$(".footer").attr("style","display:none;");
		 				$(".hideprint").attr("style","display:none;");
					 	$(".hidesal").attr("style","display:none;");						
						$("#bday").css("border","0px solid grey");
						$("textarea").css("border","0px solid grey");
			var printit = $("#printthis").html()
            $("#printme").html(printit);
            window.print();
									$("textarea").css("border","1px solid grey");
			$("#bday").css("border","1px solid green");
			$("#logo").attr("style","display:none;");
						$("#power").attr("style","display:none;");
			$(".hideprint").removeAttr("style");
			$(".footer").removeAttr("style");
			$(".hidesal").removeAttr("style");
			$("#printme").html("");
			


	 });



		</script>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <link href="../../bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css"/>
	<link href="../../bootstrap/css/sidebar.css" rel="stylesheet" type="text/css"/>
<script src="../../bootstrap/js/bootstrap.js"></script>
<script src="../../bootstrap/js/jquery-1.12.0.js"></script>
<script src="../../bootstrap/js/bootstrap.min.js"></script>
	    <link href="../../bootstrap/css/bootstrap-datepicker.css" rel="stylesheet" type="text/css"/>
		<script src="../../bootstrap/js/bootstrap-datepicker.min.js"></script>
		
			<script>
	function Comma(Num) { //function to add commas to textboxes
        Num += '';
        Num = Num.replace(',', ''); Num = Num.replace(',', ''); Num = Num.replace(',', '');
        Num = Num.replace(',', ''); Num = Num.replace(',', ''); Num = Num.replace(',', '');
        x = Num.split('.');
        x1 = x[0];
        x2 = x.length > 1 ? '.' + x[1] : '';
        var rgx = /(\d+)(\d{3})/;
        while (rgx.test(x1))
            x1 = x1.replace(rgx, '$1' + ',' + '$2');
        return x1 + x2;
    }
</script>
		
</head>
<style>
@import url('https://fonts.googleapis.com/css?family=Tauri');
body{font-family: 'Tauri', sans-serif;}
.title{font-size:18px;
padding-bottom: 20px;
color: #0066CC;
width:100%;}
#result{
	display: none;
	margin-left: 70px;
	position: fixed;
	top: 0px;
	width: 70%;
	padding:20px;
	z-index:99999;
}
textarea {
width:100%;
  height: 80px;
}

  @page { size: Portrait; }

@media print {
#hidesal{
display:none;}
#hideprint{
display:none;}

.sidebar-nav, #footer{
display:none;}

#wrapper.toggled, #sidebar-wrapper{
padding-left:0px;
}
#page-content-wrapper{
top:0;
}


	#body * {
	visibility: hidden;
  }		
	#printthis, #printthis * {
	visibility: visible;
  }	
	
@page { size: Portrait; }
}
  

  @media only screen and (max-width: 768px) 
{ 
#result{
	top: 75px;
	margin-left: 0;
	width:70%
}
}
</style>
<body>
 <div id="result">
	</div>
	
	<!-- Modal -->

  <div class="modal fade" id="modalprint" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h3 class="modal-title text-primary"><span class="glyphicon glyphicon-print"> </span> Print E.R.N.</h3>
        </div>
        <div class="modal-body">
		<br />
          <p>Are you sure you want to print <?php echo $fname."'s"; ?> E.R.N.?</p>
        </div>
        <div class="modal-footer">
		  <button type="button" id="no" value="no" data-dismiss="modal" class="btn btn-default" > Cancel </button>
		  <button type="button" id="yes" value="yes" class="btn btn-primary" autofocus > Ok </button>
		
        </div>
      </div>
      
    </div>
  </div>	
	<center>
	<img src="../../img/comlogo.jpg" width="200" height="50">
	<h2>EMPLOYEE'S RECORD NOTICE (E.R.N.)</h2>
	<i><h5>Private and Confidential</h5></i>

	 <table class="table table-bordered" id="table" style="padding-left:50px; font-size:16px;">
    <tbody>
	<tr>
        <td style="font-weight:bold;">Employee's Full Name (Surname/First Name/Middle Name)</td>
        <td style="font-weight:bold;">Date (Month/Day/Year)</td>
	</tr>
		<tr>
        <td><?php echo $name; ?></td>
        <td><?php echo date('F d, Y'); ?></td>
	</tr>
	<tr>
        <td style="font-weight:bold;">Position</td>
        <td style="font-weight:bold;">Group / Department / Section</td>	
	</tr>
			<tr>
        <td><?php echo $datapos; ?></td>
        <td><?php echo $datadept; ?></td>
	</tr>
	<br>
	  <table class="table table-bordered" id="table" style="font-size:20px">
    <thead>
      <tr>
        <th>Particulars</th>
        <th>From</th>
		<th>To</th>
      </tr>
    </thead>
	</tr>
			<tr>
			<?php 
			$pos_sql=mysql_query("select old_pos, new_pos from ern_data where ern_id='$perid'", $connection);
			$rowpos = mysql_fetch_assoc($pos_sql);
$oldpos =$rowpos['old_pos'];
$newpos =$rowpos['new_pos'];
?>
		<td>Position</td>
        <td><?php echo $oldpos; ?></td>
        <td><?php echo $newpos; ?></td>
	</tr>
				<tr>
			<?php 
			$rank_sql=mysql_query("select old_rank, new_rank from ern_data where ern_id='$perid'", $connection);
			$rowrank = mysql_fetch_assoc($rank_sql);
$oldrank =$rowrank['old_rank'];
$newrank =$rowrank['new_rank'];
?>
		<td>Job Level / Rank</td>
        <td><?php echo $oldrank; ?></td>
        <td><?php echo $newrank; ?></td>
	</tr>
	<tr>
		<td>Nature of Adjustment</td>
        <td></td>
		<td></td>
	</tr>
	<tr>
			<?php 
			$status_sql=mysql_query("select old_status, new_status from ern_data where ern_id='$perid'", $connection);
			$rowstatus = mysql_fetch_assoc($status_sql);
$oldstatus =$rowstatus['old_status'];
$newstatus =$rowstatus['new_status'];
?>
		<td>Employment Status</td>
        <td><?php echo $oldstatus; ?></td>
        <td><?php echo $newstatus; ?></td>
	</tr>
	<tr>
				<?php 
			$dept_sql=mysql_query("select old_dept, new_dept from ern_data where ern_id='$perid'", $connection);
			$rowdept = mysql_fetch_assoc($dept_sql);
$olddept =$rowdept['old_dept'];
$newdept =$rowdept['new_dept'];
?>
		<td>Section / Department</td>
        <td><?php echo $olddept; ?></td>
        <td><?php echo $newdept; ?></td>
	</tr>
		<tr>
				<?php 
			$salary_sql=mysql_query("select old_salary, new_salary from ern_data where ern_id='$perid'", $connection);
			$rowsalary = mysql_fetch_assoc($salary_sql);
$oldsalary =$rowsalary['old_salary'];
$newsalary =$rowsalary['new_salary'];
?>
		<td>Basic Monthly Pay (PHP)</td>
        <td><?php echo $oldsalary; ?></td>
        <td><?php echo $newsalary; ?></td>
	</tr>

	<tr>
	<?php
			$alw_sql=mysql_query("select old_alw, new_alw from ern_data where ern_id='$perid'", $connection);
			$rowalw = mysql_fetch_assoc($alw_sql);
$oldalw =$rowalw['old_alw'];
$newalw =$rowalw['new_alw'];
?>
		<td>Allowances</td>
        <td><?php echo $oldalw; ?></td>
        <td><?php echo $newalw; ?></td>
	</tr>
	<tr>
		<td>Benefits</td>
        <td><textarea style="font-size:14px;" maxlength="135"></textarea></td>
        <td><textarea style="font-size:14px;" maxlength="135"></textarea></td>
	</tr>
	<tr>
	<td>Others</td>
        <td>XXX</td>
        <td><textarea style="font-size:14px;" maxlength="135"></textarea></td>
	</tr>
	<tr>
	<?php 
	$convertoldsal = str_replace(",","",$oldsalary);
	$convertnewsal = str_replace(",","",$newsalary);
	$convertoldalw = str_replace(",","",$oldalw);
	$convertnewalw = str_replace(",","",$newalw);
	$oldsal = floatval($convertoldsal);
	$oldalw = floatval($convertoldalw);
	$newsal = floatval($convertnewsal);
	$newalw = floatval($convertnewalw);
	$old_total = $oldsal+$oldalw;
	$new_total = $newsal+$newalw;
	?>
	<td>Total (BMP + Monthly Allowance)</td>
        <td><?php echo number_format($old_total,2); ?></td>
        <td><?php echo number_format($new_total,2); ?></td>
	</tr>
	<tr>
		<td>Effective Date</td>
        <td>XXX</td>
        <td><input type='text' tabindex="2" name='bday' id="bday" style="width:100%; padding-left:10px" placeholder='Select Date' readonly="true" data-behavior="datepicker" required> </td>
	</tr>
</table>
	
	</center>
	<br><br>
<table width="100%" style="font-size:14px;">
<tr><td>
Recommended by:<br><br><br>
</td><td>
Endorsed by:<br><br><br>
</td><td>
Approved by:<br><br><br>
</td><td>
Accepted by:<br><br><br></td>
</tr>
<tr><td>
_________________________
</td><td>
_________________________
</td><td>
_________________________
</td><td>
_________________________
</td>
</tr>
<tr><td>
Department Head
</td><td>
Group Head / CFO
</td><td>
President
</td><td>
Employee
</td>
</tr>
</table>
<br /><br />
<div id="power" style="display:none;"><center>Powered by: <img src="../../img/logo.jpg" width="200" height="50"> </center></div>

    </body>
</html>