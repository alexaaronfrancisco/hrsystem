<?php
require_once '../../assets/dbconfig.php';
require_once '../../assets/connection.php';
if($_POST){
$per_id = $_POST['perid'];
$datepass = $_POST['datepass'];
$status = "done";		
			
			//Get Answer 
			$stmt = $db_con->prepare("UPDATE ern_data SET effec_date=:date, status=:stat WHERE ern_id=:id");
			$stmt->bindParam(":date", $datepass);
			$stmt->bindParam(":stat", $status);
			$stmt->bindParam(":id", $per_id);
			
			if($stmt->execute())
			{		
			$entry_sql=mysql_query("select emp_id from ern_data where ern_id='$per_id'", $connection);
			$row2 = mysql_fetch_assoc($entry_sql);
			$gettheid =$row2['emp_id'];
			$name_sql=mysql_query("select emp_name from emp_personal_data where emp_id='$gettheid'", $connection);
			$row2 = mysql_fetch_assoc($name_sql);
			$getthename =$row2['emp_name'];
			$trail = mysql_query("INSERT INTO trail (type, per_action, description, emp_id) VALUES ('Report', 'SET', 'E.R.N. for $getthename', '$user_check')", $connection);
			echo "Updating...";
			}
			else{
				echo "Query Problem";
			}	
		}
?>