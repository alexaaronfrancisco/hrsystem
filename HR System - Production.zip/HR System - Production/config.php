<?php
session_start(); // Starting Session
$success='';
$error=''; // Variable To Store Error Message
if (isset($_POST['submit'])) {
$username=$_POST['username'];
$password=$_POST['password'];
if (empty($_POST['username']) || empty($_POST['password'])) {
$error = '<div class="text text-danger"><strong>Error!</strong>Employee Number or Password is invalid!</div>';
}
else
{
// Define $username and $password
//$username=$_POST['username'];
//$password=$_POST['password'];
// Establishing Connection with Server by passing server_name, user_id and password as a parameter
$connection = mysql_connect("localhost", "root", "polyester10");
$db = mysql_select_db("hrsystem", $connection);
// To protect MySQL injection for Security purpose
//$username = stripslashes($username);
//$password = stripslashes($password);
//$username = mysql_real_escape_string($username);
//$password = mysql_real_escape_string($password);
// Selecting Database

// SQL query to fetch information of registerd users and finds user match.
$query = mysql_query("select * from emp_personal_data where  emp_pass='$password' AND emp_id='$username'", $connection);
$query1 = mysql_query("select * from emp_personal_data where emp_pass='$password' AND emp_id='$username' AND emp_status = 'admin'", $connection);
$query2 = mysql_query("select * from emp_job_data where emp_id='$username' AND job_id BETWEEN 5 AND 7", $connection);
$query3 = mysql_query("select * from emp_job_data where emp_id='$username' AND job_id BETWEEN 8 AND 11", $connection);
$query4 = mysql_query("select * from emp_job_data where emp_id='$username' AND job_id BETWEEN 12 AND 14", $connection);
$rows = mysql_num_rows($query);
$rows1 = mysql_num_rows($query1);
$rows2 = mysql_num_rows($query2);
$rows3 = mysql_num_rows($query3);
$rows4 = mysql_num_rows($query4);
if ($rows == 1) {
	$trail = mysql_query("INSERT INTO trail (type, per_action, emp_id) VALUES ('Session', 'Signed-In', '$username')", $connection);
	if ($rows1 == 1){
$_SESSION['login_user']=$username;
header('Location: home/'); // Redirecting To Other Page
}	
	
	else{	
	if($rows2 == 1){
$_SESSION['login_user']=$username; // Initializing Session
header("location: active/staff/"); // Redirecting To Other Page
}
	else if($rows3 == 1){
$_SESSION['login_user']=$username; // Initializing Session
header("location: active/supervisory/"); // Redirecting To Other Page
}
	else if($rows4 == 1){
$_SESSION['login_user']=$username; // Initializing Session
header("location: active/managerial/"); // Redirecting To Other Page
}
//
}
}
else {
$error = '<div class="text text-danger" style="color:#FF0000;"><strong>Error!</strong> Employee Number and Password does not match!</div><br>';
}
mysql_close($connection); // Closing Connection
}
}
?>