<?php
session_start();
require_once 'dbconfig.php'; 
$connection = mysql_connect("localhost", "root", "");
$db = mysql_select_db("hrsystem", $connection);
if($_POST){
$per_id = $_POST['perid'];
$emp_id = $_SESSION['empid'];
if ($_POST['tdate'] != ''){
$tdate = $_POST['tdate']."-00";}
else{
$tdate = "";}
$_SESSION['tdatesession'] = $tdate;
$fdate = $_SESSION['fdatesession'];

			$stmt = $db_con->prepare("UPDATE getper_ans SET WPG_to=:to WHERE per_id=:id");
			$stmt->bindParam(":to", $tdate);
			$stmt->bindParam(":id", $per_id);

	if ($tdate != ""){
		$monthfrom = mysql_query("select WPG_from from getper_ans where per_id = '$per_id'", $connection);
		$frow = mysql_fetch_assoc($monthfrom);
		$fres =$frow['WPG_from'];	
//		$monthto = mysql_query("select WPG_to from getper_ans where per_id = '$per_id'", $connection);
//		$trow = mysql_fetch_assoc($monthto);
//		$tres =$trow['WPG_to'];	
		$bigay=mysql_query("select AVG(total) AS avgtotal from monthly_wpg where emp_id = '$emp_id' AND (month >= '$fres' AND month <= '$tdate')", $connection);
		$rowbigay = mysql_fetch_assoc($bigay);
		$lagay =$rowbigay['avgtotal'];

		if($stmt->execute())
		{
		$lagaymoto = number_format((float)$lagay, 2, '.', '');;
		echo $lagaymoto;		
		}
		else echo "wala";
		}
		else{
			echo "Query Problem";
		}
		}
?>