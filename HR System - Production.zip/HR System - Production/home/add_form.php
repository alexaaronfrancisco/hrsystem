<?php 
session_start();
$connection = mysql_connect("localhost", "root", "");
$db = mysql_select_db("hrsystem", $connection);
$perid = $_GET['id'];
$perid_sql=mysql_query("select emp_id from getper_ans where per_id='$perid'", $connection);
$rowper = mysql_fetch_assoc($perid_sql);
$per_id =$rowper['emp_id'];

$name_sql=mysql_query("select emp_name from emp_personal_data where emp_id='$per_id'", $connection);
$rowname = mysql_fetch_assoc($name_sql);
$name =$rowname['emp_name'];

$_SESSION['empid'] = $per_id;
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <link href="../bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css"/>
	<link href="../bootstrap/css/sidebar.css" rel="stylesheet" type="text/css"/>
<script src="../bootstrap/js/bootstrap.js"></script>
<script src="../bootstrap/js/jquery-1.12.0.js"></script>
<script src="../bootstrap/js/bootstrap.min.js"></script>
	    <link href="../bootstrap/css/bootstrap-datepicker.css" rel="stylesheet" type="text/css"/>
		<script src="../bootstrap/js/bootstrap-datepicker.min.js"></script>
<script>
		 $(document).ready(function(){
//$('.from').datepicker({
//		format: "MM/yyyy",
//		startView: 'months'     
//		})
 //       });*/
//	format: "mm/yyyy",
//    startView: "months", 
//    minViewMode: "months",
//});
 
var startDate = new Date();
var fechaFin = new Date();
var FromEndDate = new Date();
var ToEndDate = new Date();


$('.from').datepicker({
    autoclose: true,
	minViewMode: 1,
	startDate: '2017-01',
    format: 'yyyy-mm'
}).on('changeDate', function(selected){
        startDate = new Date(selected.date.valueOf());
        startDate.setDate(startDate.getDate(new Date(selected.date.valueOf())));
        $('.to').datepicker('setStartDate', startDate);
    }); 
	
	$('.to').datepicker({
    autoclose: true,
    minViewMode: 1,
    format: 'yyyy-mm'
}).on('changeDate', function(selected){
        FromEndDate = new Date(selected.date.valueOf());
        FromEndDate.setDate(FromEndDate.getDate(new Date(selected.date.valueOf())));
        $('.from').datepicker('setEndDate', FromEndDate);
    });

});
		
		$(document).ready(function(){
    $('[data-toggle="tooltip"]').tooltip();   
});


	
$(".from").change(function(){
if($("#fmonth").val != ""){
 var from = $("#fmonth").val();
 $(this).attr("disabled","disabled");
  $(this).css("border","#009900 1px solid");
  $("#tmonth").removeAttr("disabled","disabled");
  $("#ok").removeAttr("style");
  var perid = <?php echo $perid; ?>;
  $.ajax({
            type: "POST",
            url: "from.php", //process to add
            data: {fdate:from , perid: perid} ,					
            success: function(data){}
});
  
  }
 else
 $("#fromtext").text('');
 });
 
 $(".to").change(function(){
if($("#tmonth").val != ""){
 var to = $("#tmonth").val();
  $("#passwpg").removeAttr("disabled","disabled");
   $(this).css("border","#009900 1px solid");
    var perid = <?php echo $perid; ?>;
  $.ajax({
            type: "POST",
            url: "to.php", //process to add
            data: {tdate:to , perid: perid} ,					
            success: function(data){
			getwpgdata(data)
			$("#wpgscore").text(data);
			$("#contwpg").removeAttr("style");}
});
}
 else
 $("#totext").text('');
 });
 function getwpgdata(data)
{
 var wpgscore = data;

 <!-----SUBMIT ----->
  $("#passwpg").click(function(){
  var perid = <?php echo $perid; ?>;
    $.ajax({
            type: "POST",
            url: "getresult.php", //process to add
            data: {perid: perid , wpgscore: wpgscore} ,					
            success: function(data){
			$(".loader").fadeIn();
			$("#result").css('display','block') 
			$("#result").fadeIn('slow')
			$("#result").html('<div class="alert alert-success"><span class="glyphicon glyphicon-ok">&nbsp;</span>'+data+'</div>');
				     setTimeout(function(){
        $("#result").fadeOut();
    }, 2000); 
			 setTimeout(
  function() 
  {
$(".loader").fadeOut();
  }, 2000);
   setTimeout(
  function() 
  {
				 location.reload();
				 				 window.scrollTo(0,0);
  }, 2000);
  
   }
});
});
}
$("#reset").click(function() {

				 if (confirm("Do you want to reset?")==true)
				 $("#fmonth").val("");
				 $("#tmonth").val("");
				 $("#fmonth").removeAttr("disabled","disabled");
				 $("#fmonth").css("border","1px solid grey");
				 $("#tmonth").attr("disabled","disabled");
				 $("#tmonth").css("border","1px solid grey");
				 $("#contwpg").attr("style","display:none");
				 $("#passwpg").attr("disabled","disabled");

				 
				 });

$(".close").click(function() {

				 if (confirm("Do you want to close 'Get WPG Score'?")==true)
				 location.reload();
				 				 window.scrollTo(0,0);
				 });


</script>
<style>
#result{
	display: none;
	margin-left: 70px;
	position: fixed;
	top: 0px;
	width: 70%;
	padding:20px;
	z-index:99999;
}
  @media only screen and (max-width: 768px) 
{ 
#result{
	top: 75px;
	margin-left: 0;
	width:70%
}
}
</style>
 <div id="result">
    <!-- here message will be displayed -->
	</div>
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close">&times;</button>
        <h4 class="modal-title text text-primary">Get WPG Score</h4>
      </div>
      <div class="modal-body">
      <!----BODY----->
	  <div class="row">
	  		  <div class="col-sm-12">
             	Employee Name : <b><?php echo $name; ?> </b>
         </div>
		 </div>
		 <br />
	  <div class="row">
	  		  <div class="col-sm-8">
             	<b>From </b>
			  <div class="input-group">
			  <span class="input-group-addon"><i class="glyphicon glyphicon-calendar"></i></span>
            <input type='text' name='fmonth' id="fmonth" class='from btn btn-default' placeholder='Month and Year' readonly="true" data-behavior="datepicker" required> 
         </div>
		 </div> 
		 </div> 
		 <br />
		 	  <div class="row">
	  		  <div class="col-sm-8">
             	<b>To</b>
			  <div class="input-group">
			  <span class="input-group-addon"><i class="glyphicon glyphicon-calendar"></i></span>
             <input type='text' name='tmonth' id="tmonth" class='to btn btn-default' placeholder='Month and Year' disabled="disabled" readonly="true" data-behavior="datepicker" required> 

         </div>
		 </div>		 		 
      </div>
	  <br />
	  <h4><span id="contwpg" class="label label-primary" style="display:none;"> Total WPG: <span id="wpgscore"></span></span></h4>
	  </div>
      <div class="modal-footer">
		  <button type="button" id="passwpg" class="btn btn-success" disabled="disabled" data-toggle="tooltip" data-placement="bottom" title="Submit">Submit</button>
        <button type="button" id="reset" class="btn btn-default" data-toggle="tooltip" data-placement="bottom" title="Reset">Reset</button>
      </div>
    </div>

  </div>
</div>
<?php 
$wpgscore = "<span id='wpgscore'></span>";
$_SESSION["wpgscore"] = $wpgscore;
?>


    </body>
</html>