<?php
session_start();
require_once 'dbconfig.php'; 
$connection = mysql_connect("localhost", "root", "");
$db = mysql_select_db("hrsystem", $connection);
if($_POST){
$per_id = $_POST['perid'];
if ($_POST['fdate'] != ''){
$fdate = $_POST['fdate']."-00";}
else{
$fdate = "";}
$_SESSION['fdatesession'] = $fdate;
$tdate = $_SESSION['tdatesession'];

			$stmt = $db_con->prepare("UPDATE getper_ans SET WPG_from=:from WHERE per_id=:id");
			$stmt->bindParam(":from", $fdate);
			$stmt->bindParam(":id", $per_id);
		
		if($stmt->execute())
		{
			echo $per_id;
		}
		else{
			echo "Query Problem";
		}
		}
?>