<?php
session_start();
require_once 'dbconfig.php'; 
$connection = mysql_connect("localhost", "root", "");
$db = mysql_select_db("hrsystem", $connection);
if($_POST){
$per_id = $_POST['perid'];
$emp_id = $_SESSION['empid'];
$wpgscore = $_POST['wpgscore'];
$status = "complete";
			
		//WPA Score
		$wpascore = mysql_query("select WPA_score from getper_ans where per_id= '$per_id'", $connection);
		$wpascorow = mysql_fetch_assoc($wpascore);
		$wpascoget = $wpascorow['WPA_score'];
		//WPG
		$wpgper = mysql_query("select percent from org_percent where org_percent_id = 1", $connection);
		$wpgrow = mysql_fetch_assoc($wpgper);
		$wpgperget =$wpgrow['percent'];
		//WPA
		$wpaper = mysql_query("select percent from org_percent where org_percent_id = 2", $connection);
		$wparow = mysql_fetch_assoc($wpaper);
		$wpaperget =$wparow['percent'];
		
		$computewpg = ($wpgscore*$wpgperget)/100;
		$computewpa = ($wpascoget*$wpaperget)/100;
		$numresult2 = $computewpg + $computewpa;
		$numresult = number_format((float)$numresult2, 2, '.', '');;
		$wordresult = "";
		//substandard
			$countnor = 0;
			$incper = 0;
			$substart = 1.01;
			$marstart = 1.27;
			$norstart = 2.02;
			$nor2start = 2.51;
			$prostart = 3.02;
			$pro2start = 3.61;
			$exestart = 3.77;
			
		if ($numresult >= 1.00 && $numresult <= 1.25){
			$incper = -6.83;
			while ($numresult >= $substart){
			$substart+=.01;
			$incper+=.05;
			} 
			$wordresult = "Substandard";}
			//Marginal
		else if ($numresult >= 1.26 && $numresult <= 2.00){
			$incper = -5.53;
			while ($numresult >= $marstart){
			$substart+=.01;
			$incper+=.05;
			}
			$wordresult = "Marginal";}
			//Normative

		else if ($numresult >= 2.01 && $numresult <= 2.49){
			$incper = -1.78;
			while ($numresult >= $norstart){
			$norstart+=.01;
			$incper+=.05;
			}
			$wordresult = "Normative";}
		else if ($numresult >= 2.5 && $numresult <= 3.00){
				$incper = .67;
			while ($numresult >= $nor2start){
				if($countnor == 0){
			$nor2start+=.01;
			$incper+=.08;
			$countnor+=1;
			}
				else {
			$nor2start+=.01;
			$incper+=.07;
			$countnor-=1;
			}
			}
			$wordresult = "Normative";}	
			//proficient
			
		else if ($numresult >= 3.01 && $numresult <= 3.59){
			$incper = 4.50;	
			while ($numresult >= $prostart){
				if($countnor == 0){
			$prostart+=.01;
			$incper+=.08;
			$countnor+=1;
			}
				else {
			$prostart+=.01;
			$incper+=.07;
			$countnor-=1;
			}
			} 
			$wordresult = "Proficient";}
		else if ($numresult >= 3.60 && $numresult <= 3.75){
			$incper = 8.05;
			while ($numresult >= $pro2start){
			$pro2start+=.01;
			$incper+=.05;
			}
			$wordresult = "Proficient";}
			//exemplary
		else if ($numresult >= 3.76 && $numresult <= 4.00){
			$incper = 8.85;
			while ($numresult >= $exestart){
			$exestart+=.01;
			$incper+=.05;
			}
			$wordresult = "Exemplary";}
			
			
		$getsal = mysql_query("select current from emp_job_data where emp_id= '$emp_id'", $connection);
		$getsalrow = mysql_fetch_assoc($getsal);
		$sal = $getsalrow['current'];
		$exsal = str_replace(",","",$sal);		
				$consal = (float)$exsal;		

		$salinc = ($consal*$incper)/100;
		$addinc = $consal + $salinc;
		$recsal = number_format((float)$addinc, 2, '.', ',');;
			
			//WPG Score
		//	$stmt = $db_con->prepare("UPDATE getper_ans SET WPG_score=:sco WHERE per_id=:id");
		//	$stmt->bindParam(":sco", $wpgscore);
		//	$stmt->bindParam(":id", $per_id);
			
			//Employee Job Data
			
			$stmt2 = $db_con->prepare("UPDATE emp_job_data SET per_category=:per , rec_salary=:rec WHERE emp_id=:id");
			$stmt2->bindParam(":per", $wordresult);
			$stmt2->bindParam(":rec", $recsal);
			$stmt2->bindParam(":id", $emp_id);
			if($stmt2->execute())
			{		
			}
			else{
				echo "Query Problem";
			}
			
			//Get Answer 
			$stmt = $db_con->prepare("UPDATE getper_ans SET WPG_score=:sco, total=:tot, result=:res, status=:stat WHERE per_id=:id");
			$stmt->bindParam(":sco", $wpgscore);
			$stmt->bindParam(":tot", $numresult);
			$stmt->bindParam(":res", $wordresult);
			$stmt->bindParam(":stat", $status);
			$stmt->bindParam(":id", $per_id);
			
			if($stmt->execute())
			{		
			echo "Updating...!";
			}
			else{
				echo "Query Problem";
			}	
		}
?>