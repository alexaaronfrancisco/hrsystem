<?php
include('../../session.php');
if ($login_session != "admin")
{
header("Location: HTTP/1.1 401 Unauthorized Access");
}
$name_sql=mysql_query("select fname from emp_personal_data where emp_id='$user_check'", $connection);
$row2 = mysql_fetch_assoc($name_sql);
$getthename =$row2['fname'];

$sal_sql=mysql_query("select sal_range from emp_job_data where emp_job_id='1'", $connection);
$row3 = mysql_fetch_assoc($sal_sql);
$salrange =$row3['sal_range'];

?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<title>Employee Job Data</title>
<!--<link href="bootstrap/css/bootstrap.min.css" rel="stylesheet" media="screen">-->
<!--<link href="bootstrap/css/bootstrap-theme.min.css" rel="stylesheet" media="screen"> -->
  <link rel="shortcut icon" href="../../img/logo.ico" type="image/x-icon">
<link href="../../assets/datatables.min.css" rel="stylesheet" type="text/css">
    <link href="../../bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css"/>
	    <link href="../../bootstrap/css/sidebar.css" rel="stylesheet" type="text/css"/>
<script src="../../bootstrap/js/bootstrap.js"></script>
<script src="../../bootstrap/js/jquery-1.12.0.js"></script>
<script src="../../bootstrap/js/bootstrap.min.js"></script>
<script type="text/javascript">
$(document).ready(function(){
	
	$("#btn-view").hide();
	
	$("#btn-add").click(function(){
		$(".content-loader").fadeOut('slow', function()
		{
		$(".loader").show();
		setTimeout(
  function() 
  {
$(".loader").fadeOut();
  }, 1000);
			$(".content-loader").fadeIn('slow');
			$(".content-loader").load('add_form.php');
			
			$("#btn-add").hide();
			$("#btn-view").show();
		});
	});
	
	$("#btn-view").click(function(){
		
		$("body").fadeOut('slow', function()
		{
			$("body").load('index.php');
			$("body").fadeIn('slow');
			window.location.href="index.php";
		});
	});
	
});

$(document).ready(function(){
    $('[data-toggle="tooltip"]').tooltip();   
});

$(window).load(function() {
	$(".loader").fadeOut("slow");
})
 $(document).ready(function(){
    var hContent = $("body").height(); // get the height of your content
    var hWindow = $(window).height();  // get the height of the visitor's browser window

    // if the height of your content is bigger than the height of the 
    // browser window, we have a scroll bar
    if(hContent>hWindow) {
	$('.footer').css("position","absolute");
        return true;    
    }

    return false;
});

</script>
<style>
@import url('https://fonts.googleapis.com/css?family=Tauri');
body{font-family: 'Tauri', sans-serif;}
.title{font-size:18px;
padding-bottom: 20px;
color: #0066CC;
width:100%;}

.footer {
z-index:2;
width:100%;
position:fixed;
display: block;
  right: 0;
  bottom: 0;
  left: 0;
  font-size:12px;
  padding: 1rem;
  background-color: #efefef;
  text-align: right;}
  
  .loader {
	position: fixed;
	left: 0px;
	top: 0px;
	width: 100%;
	height: 100%;
	z-index: 9999;
	background: url('../../img/loading.gif') 50% 50% no-repeat rgb(249,249,249);
	opacity: .5;
}

  .icon {
  float:left;
  display:block;
  padding-top: 10px;
  }
  
  .back {
  display:none;
  border:none;
  }
  .add {
  border:none;
border-radius: 100%;
padding-top:15px;
padding-bottom: 17px;
padding-left: 17px;
padding-right: 15px;
font-size:24px;

}
.add:focus{
outline: 0px;
}
.sidebar-brand{
background-color:#FFFFFF;
}
.sidebar-brand img {
width: 225px;
height:57px;

}

  @media only screen and (max-width: 768px) 
{ 
.footer {
margin-top: 50px;
width:100%;
position: relative;
font-size: 10px;
background-color: #fff;
}

.sidebar-brand img {
width: 190px;
height:45px;

}
}

</style>


</head>

<body>
<!-- Modal -->

  <div class="modal fade" id="modalern" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h3 class="modal-title text-primary"><span class="glyphicon glyphicon-print"> </span> Added New Record</h3>
        </div>
        <div class="modal-body">
		<br />
          <p>Do you want to redirect to Employee's Record Notice?</p>
        </div>
        <div class="modal-footer">
		  <button type="button" id="no" value="no" data-dismiss="modal" class="btn btn-default" > No </button>
		  <button type="button" id="yes" value="yes" class="btn btn-primary" autofocus > Yes </button>
		
        </div>
      </div>
      
    </div>
  </div>	
<!------------------------------------------->
<div class="loader"></div>
      

        <!-- Sidebar -->
		<div class="stat" style="position:static;">
		<div class="sticktop" style="top:0; display:block; position: fixed; z-index:1000; right:0; left:0;">
		<div class="sidebar-brand">
                    <a href="#">
                       <img src="../../img/logo.jpg"> 
                    </a>
                </div>
				<div class="drops">
		<div class="dropdowntogs">
                               <a href="#"><span class="glyphicon glyphicon-user"> </span> &nbsp;&nbsp;<b>Admin</b> <?php echo $getthename ?></a></div>
				<div class="dropmenu">
			<!---	<a href="#"><span class="glyphicon glyphicon-wrench"> </span> Edit Profile</a><div></div>---->
				<a href="../../chgpass.php"><span class="glyphicon glyphicon-lock"> </span> Change Password</a>
				<hr></hr>
				<a href="../../logout.php"><span class="glyphicon glyphicon-log-out"> </span> Log-out</a>
				</div>
				</div>							

		<div class="toggles"><a href="#menu-toggle" id="menu-toggle"><span class="glyphicon glyphicon-menu-hamburger"></span></a></div>       
                </div>
				</div>
				 <div id="wrapper">
<div id="sidebar-wrapper">
            <ul class="sidebar-nav">
			<div class="menunav"></div>
				<li>
				<a href="../../home/"><span class="glyphicon glyphicon-home icon"></span> Home</a>
                </li>
                <li>
				<div class="main">
                    <a href="#" class="active"><i class="glyphicon glyphicon-cog icon"></i> Maintenance</a></div>
					<div class="drop" style="display:block;">
					<a href="../../maintenance/emperdata">Employee Personal Data</a>
					<a href="" class="active" style="background-color:#fff; color:#000000;">Employee Job Data</a>
					<a href="../../maintenance/emprater">Employee Rater</a>
					</div>
					</li>
					<li>
				<div class="ijsm">
                    <a href="#"><i class="glyphicon glyphicon-briefcase icon"></i>IJSM</a></div>
					<div class="drop2">
					<a href="../../ijsm/jobclass">Job Classification</a>
					<a href="../../ijsm/jobrating">Job Rating Plan</a>
					<a href="../../ijsm/jobeva">Job Evaluation</a>
					<a href="../../ijsm/salstruct">Salary Structure</a>
					<a href="../../ijsm/salanal">Salary Analysis</a>
					</div>
					</li>
					<li>
				<div class="opms">
                    <a href="#"><i class="glyphicon glyphicon-list-alt icon"></i>OPMS</a></div>
					<div class="drop3">
					<a href="../../opms/wpg">Manage WPG</a>
					<a href="../../opms/wperfpercent">Manage WPA</a>
					<a href="../../opms/orgper">Manage OPMS</a>
					<a href="../../opms/getper">OPMS Form</a>
					</div>
                </li>
                <li>
								<div class="rprt">
                    <a href="#"><i class="glyphicon glyphicon-duplicate icon"></i>Report</a></div>
											
									<div class="drop4">
					<a href="../../rprt/ern">E.R.N.</a>
					<a href="../../rprt/tabul">OPMS Tabulation</a>
                    <a href="../../rprt/percat">Indv. Performance Category</a>
					<a href="../../rprt/orgcat">Org. Performance Category</a>
				</div>
                </li>
                <li>
				<div class="util">
                    <a href="#"><i class="glyphicon glyphicon-wrench icon"></i>Utilities</a></div>
					<div class="drop5">
					<a href="../../util/trail">Audit Trail</a>
					<a href="../../util/showinact">Show inactive</a>
					<a href="../../util/localbup">Data Back-up</a>

					</div>
                </li>
            </ul>							
			<div class="move" style="position:relative; z-index:-1; min-height:600px;">				
														<div id="footer" style=" position:absolute; margin-left:10px; left:0; bottom:0; text-align:center; font-size:10px;  width:200px; margin-right:10px; color:#CCCCCC; ">
				<b>Copyright </b> <span class="glyphicon glyphicon-copyright-mark"></span> <b><?php echo date(' Y')?></b> All Rights Reserved. <br /> Confluent Management Inc. <br /> <b>Version</b> 2.0
				</div>			</div>
							
        </div>				
        <!-- /#sidebar-wrapper -->
        <!-- Page Content -->
<!--table--->				

        <div id="page-content-wrapper">
            <div class="container-fluid">
                        	        <button class="btn btn-primary add" type="button" id="btn-add" data-toggle="tooltip" data-placement="right" title="Add Record"> <span class="glyphicon glyphicon-plus"></span></button>
					 <button class="btn-primary add back" type="button" id="btn-view" data-toggle="tooltip" data-placement="right" title="Back to table list"> <span class="glyphicon glyphicon-arrow-left"></span></button>
		<hr />
        <div class="content-loader">
		<div class="title">Browse Employee Job Data</div>
        <table cellspacing="0" width="100%" id="example" class="table table-striped table-hover table-condensed table-responsive" style="font-size:12px;" >
        <thead>
        <tr>
        <th>ID</th>
        <th>Name</th>
		<th>Job Rank</th>
     <!----   <th>Birthday</th> ---->
	 <th>Department</th>
        <th>Position</th>
		<th>Category</th>
        <th>Current Salary</th>
	<!----	<th>Home Address</th> ---->
		<th>Status</th>
      	<th style="display:none;"></th>
		<th style="display:none;"></th>
        </tr>
        </thead>
        <tbody>
        <?php
        require_once '../../assets/dbconfig.php';
   		
$rank1_sql=mysql_query("select rank from job_classification where job_id='1'", $connection);
$rows1 = mysql_fetch_assoc($rank1_sql);
$rank1 = $rows1['rank'];

$rank2_sql=mysql_query("select rank from job_classification where job_id='2'", $connection);
$rows2 = mysql_fetch_assoc($rank2_sql);
$rank2 = $rows2['rank'];

$rank3_sql=mysql_query("select rank from job_classification where job_id='3'", $connection);
$rows3 = mysql_fetch_assoc($rank3_sql);
$rank3 = $rows3['rank'];

$rank4_sql=mysql_query("select rank from job_classification where job_id='4'", $connection);
$rows4 = mysql_fetch_assoc($rank4_sql);
$rank4 = $rows4['rank'];

$rank5_sql=mysql_query("select rank from job_classification where job_id='5'", $connection);
$rows5 = mysql_fetch_assoc($rank5_sql);
$rank5 = $rows5['rank'];

$rank6_sql=mysql_query("select rank from job_classification where job_id='6'", $connection);
$rows6 = mysql_fetch_assoc($rank6_sql);
$rank6 = $rows6['rank'];

$rank7_sql=mysql_query("select rank from job_classification where job_id='7'", $connection);
$rows7 = mysql_fetch_assoc($rank7_sql);
$rank7 = $rows7['rank'];

$rank8_sql=mysql_query("select rank from job_classification where job_id='8'", $connection);
$rows8 = mysql_fetch_assoc($rank8_sql);
$rank8 = $rows8['rank'];

$rank9_sql=mysql_query("select rank from job_classification where job_id='9'", $connection);
$rows9 = mysql_fetch_assoc($rank9_sql);
$rank9 = $rows9['rank'];

$rank10_sql=mysql_query("select rank from job_classification where job_id='10'", $connection);
$rows10 = mysql_fetch_assoc($rank10_sql);
$rank10 = $rows10['rank'];

$rank11_sql=mysql_query("select rank from job_classification where job_id='11'", $connection);
$rows11 = mysql_fetch_assoc($rank11_sql);
$rank11 = $rows11['rank'];

$rank12_sql=mysql_query("select rank from job_classification where job_id='12'", $connection);
$rows12 = mysql_fetch_assoc($rank12_sql);
$rank12 = $rows12['rank'];

$rank13_sql=mysql_query("select rank from job_classification where job_id='13'", $connection);
$rows13 = mysql_fetch_assoc($rank13_sql);
$rank13 = $rows13['rank'];

$rank14_sql=mysql_query("select rank from job_classification where job_id='14'", $connection);
$rows14 = mysql_fetch_assoc($rank14_sql);
$rank14 = $rows14['rank'];

		
 $stmt = $db_con->prepare("SELECT emp_job_id, emp_job_data.emp_id, job_classification.rank, emp_personal_data.emp_name, dept, title, category, current FROM emp_job_data LEFT JOIN emp_personal_data ON emp_job_data.emp_id=emp_personal_data.emp_ID LEFT JOIN job_classification ON emp_job_data.job_id=job_classification.job_id WHERE emp_personal_data.emp_status != 'inactive' ORDER BY emp_job_id DESC");
        $stmt->execute();
		while($row=$stmt->fetch(PDO::FETCH_ASSOC))
		{
			?>

<?php
$getsal = $salrange;
$rf1_1 = (((float)$getsal*313)/12);
$rf1_2 = $rf1_1*0.0375+$rf1_1;
$rf1_3 = $rf1_2*0.0375+$rf1_2;
$rf1_4 = $rf1_3*0.0375+$rf1_3;
$rf1_5 = $rf1_4*0.0375+$rf1_4;
$rf1_6 = $rf1_5*0.0375+$rf1_5;

$getrf1_1 = (round($rf1_1, 2));
$getrf1_2 = (round($rf1_2, 2));
$getrf1_3 = (round($rf1_3, 2));
$getrf1_4 = (round($rf1_4, 2));
$getrf1_5 = (round($rf1_5, 2));
$getrf1_6 = (round($rf1_6, 2));


//rank and file 2
$rf2_1 = $rf1_3*0.04+$rf1_3;
$rf2_2 = $rf2_1*0.05+$rf2_1;
$rf2_3 = $rf2_2*0.05+$rf2_2;
$rf2_4 = $rf2_3*0.05+$rf2_3;
$rf2_5 = $rf2_4*0.05+$rf2_4;

$getrf2_1 = (round($rf2_1, 2));
$getrf2_2 = (round($rf2_2, 2));
$getrf2_3 = (round($rf2_3, 2));
$getrf2_4 = (round($rf2_4, 2));
$getrf2_5 = (round($rf2_5, 2));

//Staff 1
$s1_1 = $rf2_3*0.06+$rf2_3;
$s1_2 = $s1_1*0.05+$s1_1;
$s1_3 = $s1_2*0.05+$s1_2;
$s1_4 = $s1_3*0.05+$s1_3;
$s1_5 = $s1_4*0.05+$s1_4;

$gets1_1 = (round($s1_1, 2));
$gets1_2 = (round($s1_2, 2));
$gets1_3 = (round($s1_3, 2));
$gets1_4 = (round($s1_4, 2));
$gets1_5 = (round($s1_5, 2));

//Staff 2
$s2_1 = $s1_3*0.06+$s1_3;
$s2_2 = $s2_1*0.05+$s2_1;
$s2_3 = $s2_2*0.05+$s2_2;
$s2_4 = $s2_3*0.05+$s2_3;
$s2_5 = $s2_4*0.05+$s2_4;

$gets2_1 = (round($s2_1, 2));
$gets2_2 = (round($s2_2, 2));
$gets2_3 = (round($s2_3, 2));
$gets2_4 = (round($s2_4, 2));
$gets2_5 = (round($s2_5, 2));

//Professional
$pro_1 = $s2_3*0.08+$s2_3;
$pro_2 = $pro_1*0.05+$pro_1;
$pro_3 = $pro_2*0.05+$pro_2;
$pro_4 = $pro_3*0.05+$pro_3;
$pro_5 = $pro_4*0.05+$pro_4;

$getpro_1 = (round($pro_1, 2));
$getpro_2 = (round($pro_2, 2));
$getpro_3 = (round($pro_3, 2));
$getpro_4 = (round($pro_4, 2));
$getpro_5 = (round($pro_5, 2));

//Section Head 1
$sh1_1 = $pro_3*0.08+$pro_3;
$sh1_2 = $sh1_1*0.05+$sh1_1;
$sh1_3 = $sh1_2*0.05+$sh1_2;
$sh1_4 = $sh1_3*0.05+$sh1_3;
$sh1_5 = $sh1_4*0.05+$sh1_4;

$getsh1_1 = (round($sh1_1, 2));
$getsh1_2 = (round($sh1_2, 2));
$getsh1_3 = (round($sh1_3, 2));
$getsh1_4 = (round($sh1_4, 2));
$getsh1_5 = (round($sh1_5, 2));

//Section Head 2
$sh2_1 = $sh1_3*0.08+$sh1_3;
$sh2_2 = $sh2_1*0.05+$sh2_1;
$sh2_3 = $sh2_2*0.05+$sh2_2;
$sh2_4 = $sh2_3*0.05+$sh2_3;
$sh2_5 = $sh2_4*0.05+$sh2_4;

$getsh2_1 = (round($sh2_1, 2));
$getsh2_2 = (round($sh2_2, 2));
$getsh2_3 = (round($sh2_3, 2));
$getsh2_4 = (round($sh2_4, 2));
$getsh2_5 = (round($sh2_5, 2));

//Department Head 1
$dh1_1 = $sh2_3*0.10+$sh2_3;
$dh1_2 = $dh1_1*0.05+$dh1_1;
$dh1_3 = $dh1_2*0.05+$dh1_2;
$dh1_4 = $dh1_3*0.05+$dh1_3;
$dh1_5 = $dh1_4*0.05+$dh1_4;

$getdh1_1 = (round($dh1_1, 2));
$getdh1_2 = (round($dh1_2, 2));
$getdh1_3 = (round($dh1_3, 2));
$getdh1_4 = (round($dh1_4, 2));
$getdh1_5 = (round($dh1_5, 2));

//Department Head 2
$dh2_1 = $dh1_3*0.10+$dh1_3;
$dh2_2 = $dh2_1*0.05+$dh2_1;
$dh2_3 = $dh2_2*0.05+$dh2_2;
$dh2_4 = $dh2_3*0.05+$dh2_3;
$dh2_5 = $dh2_4*0.05+$dh2_4;

$getdh2_1 = (round($dh2_1, 2));
$getdh2_2 = (round($dh2_2, 2));
$getdh2_3 = (round($dh2_3, 2));
$getdh2_4 = (round($dh2_4, 2));
$getdh2_5 = (round($dh2_5, 2));

//Group Head I
$gh1_1 = $dh2_3*0.12+$dh2_3;
$gh1_2 = $gh1_1*0.05+$gh1_1;
$gh1_3 = $gh1_2*0.05+$gh1_2;
$gh1_4 = $gh1_3*0.05+$gh1_3;
$gh1_5 = $gh1_4*0.05+$gh1_4;

$getgh1_1 = (round($gh1_1, 2));
$getgh1_2 = (round($gh1_2, 2));
$getgh1_3 = (round($gh1_3, 2));
$getgh1_4 = (round($gh1_4, 2));
$getgh1_5 = (round($gh1_5, 2));

//Group Head 2
$gh2_1 = $gh1_3*0.12+$gh1_3;
$gh2_2 = $gh2_1*0.05+$gh2_1;
$gh2_3 = $gh2_2*0.05+$gh2_2;
$gh2_4 = $gh2_3*0.05+$gh2_3;
$gh2_5 = $gh2_4*0.05+$gh2_4;

$getgh2_1 = (round($gh2_1, 2));
$getgh2_2 = (round($gh2_2, 2));
$getgh2_3 = (round($gh2_3, 2));
$getgh2_4 = (round($gh2_4, 2));
$getgh2_5 = (round($gh2_5, 2));

//Executive I
$exe_1 = $gh2_3*0.15+$gh2_3;
$exe_2 = $exe_1*0.05+$exe_1;
$exe_3 = $exe_2*0.05+$exe_2;
$exe_4 = $exe_3*0.05+$exe_3;
$exe_5 = $exe_4*0.05+$exe_4;

$getexe_1 = (round($exe_1, 2));
$getexe_2 = (round($exe_2, 2));
$getexe_3 = (round($exe_3, 2));
$getexe_4 = (round($exe_4, 2));
$getexe_5 = (round($exe_5, 2));

//exe2cutive I
$exe2_1 = $exe_3*0.15+$exe_3;
$exe2_2 = $exe2_1*0.05+$exe2_1;
$exe2_3 = $exe2_2*0.05+$exe2_2;
$exe2_4 = $exe2_3*0.05+$exe2_3;
$exe2_5 = $exe2_4*0.05+$exe2_4;

$getexe2_1 = (round($exe2_1, 2));
$getexe2_2 = (round($exe2_2, 2));
$getexe2_3 = (round($exe2_3, 2));
$getexe2_4 = (round($exe2_4, 2));
$getexe2_5 = (round($exe2_5, 2));

//Executive III
$exe3_1 = $exe2_3*0.15+$exe2_3;
$exe3_2 = $exe3_1*0.05+$exe3_1;
$exe3_3 = $exe3_2*0.05+$exe3_2;
$exe3_4 = $exe3_3*0.05+$exe3_3;
$exe3_5 = $exe3_4*0.05+$exe3_4;

$getexe3_1 = (round($exe3_1, 2));
$getexe3_2 = (round($exe3_2, 2));
$getexe3_3 = (round($exe3_3, 2));
$getexe3_4 = (round($exe3_4, 2));
$getexe3_5 = (round($exe3_5, 2));




$salary = $row['current']; 
$salary2 = (float)str_replace(",","",$salary);
$rank = $row['rank'];
if ($rank == $rank1){
if ($salary2 < $getrf1_1){
		$stat_text = "<div class='label label-default' style='font-size:12px;'>Below the Range</div>";
		}
 else if ($salary2 >= $getrf1_1 && $salary2 <= $getrf1_2)
		{
		$stat_text = '<div class="label label-primary" style="font-size:12px;">Within Developmental</div>';
		}
 else if ($salary2 >= $getrf1_2 && $salary2 <= $getrf1_3)
		{
		$stat_text = "<div class='label label-info' style='font-size:12px;'>Within Intermidiate</div>";
		}
 else if ($salary2 >= $getrf1_3 && $salary2 <= $getrf1_4)
		{
		$stat_text = "<div class='label label-success' style='font-size:12px;'>Within Advanced</div>";
		}
 else if ($salary2 >= $getrf1_4 && $salary2 <= $getrf1_5)
		{
		$stat_text = "<div class='label label-warning' style='font-size:12px;'>Within Proficient</div>";
		}	
		else 
		$stat_text = "<div class='label label-danger' style='font-size:12px;'>Above the Range</div>";
		}

// rank and file 2
else if ($rank == $rank2){
if ($salary2 < $getrf2_1){
		$stat_text = "<div class='label label-default' style='font-size:12px;'>Below the Range</div>";
		}
 else if ($salary2 >= $getrf2_1 && $salary2 <= $getrf2_2)
		{
		$stat_text = '<div class="label label-primary" style="font-size:12px;">Within Developmental</div>';
		}
 else if ($salary2 >= $getrf2_2 && $salary2 <= $getrf2_3)
		{
		$stat_text = "<div class='label label-info' style='font-size:12px;'>Within Intermidiate</div>";
		}
 else if ($salary2 >= $getrf2_3 && $salary2 <= $getrf2_4)
		{
		$stat_text = "<div class='label label-success' style='font-size:12px;'>Within Advanced</div>";
		}
 else if ($salary2 >= $getrf2_4 && $salary2 <= $getrf2_5)
		{
		$stat_text = "<div class='label label-warning' style='font-size:12px;'>Within Proficient</div>";
		}
		else 
		$stat_text = "<div class='label label-danger' style='font-size:12px;'>Above the Range</div>";
		}
// staff 1
else if ($rank == $rank3){
if ($salary2 < $gets1_1){
		$stat_text = "<div class='label label-default' style='font-size:12px;'>Below the Range</div>";
		}
 else if ($salary2 >= $gets1_1 && $salary2 <= $gets1_2)
		{
		$stat_text = '<div class="label label-primary" style="font-size:12px;">Within Developmental</div>';
		}
 else if ($salary2 >= $gets1_2 && $salary2 <= $gets1_3)
		{
		$stat_text = "<div class='label label-info' style='font-size:12px;'>Within Intermidiate</div>";
		}
 else if ($salary2 >= $gets1_3 && $salary2 <= $gets1_4)
		{
		$stat_text = "<div class='label label-success' style='font-size:12px;'>Within Advanced</div>";
		}
 else if ($salary2 >= $gets1_4 && $salary2 <= $gets1_5)
		{
		$stat_text = "<div class='label label-warning' style='font-size:12px;'>Within Proficient</div>";
		}
		else 
		$stat_text = "<div class='label label-danger' style='font-size:12px;'>Above the Range</div>";
		}
		
		// staff 2
else if ($rank == $rank4){
if ($salary2 < $gets2_1){
		$stat_text = "<div class='label label-default' style='font-size:12px;'>Below the Range</div>";
		}
 else if ($salary2 >= $gets2_1 && $salary2 <= $gets2_2)
		{
		$stat_text = '<div class="label label-primary" style="font-size:12px;">Within Developmental</div>';
		}
 else if ($salary2 >= $gets2_2 && $salary2 <= $gets2_3)
		{
		$stat_text = "<div class='label label-info' style='font-size:12px;'>Within Intermidiate</div>";
		}
 else if ($salary2 >= $gets2_3 && $salary2 <= $gets2_4)
		{
		$stat_text = "<div class='label label-success' style='font-size:12px;'>Within Advanced</div>";
		}
 else if ($salary2 >= $gets2_4 && $salary2 <= $gets2_5)
		{
		$stat_text = "<div class='label label-warning' style='font-size:12px;'>Within Proficient</div>";
		}
		else 
		$stat_text = "<div class='label label-danger' style='font-size:12px;'>Above the Range</div>";
		}
		// professional
else if ($rank == $rank5){
if ($salary2 < $getpro_1){
		$stat_text = "<div class='label label-default' style='font-size:12px;'>Below the Range</div>";
		}
 else if ($salary2 >= $getpro_1 && $salary2 <= $getpro_2)
		{
		$stat_text = '<div class="label label-primary" style="font-size:12px;">Within Developmental</div>';
		}
 else if ($salary2 >= $getpro_2 && $salary2 <= $getpro_3)
		{
		$stat_text = "<div class='label label-info' style='font-size:12px;'>Within Intermidiate</div>";
		}
 else if ($salary2 >= $getpro_3 && $salary2 <= $getpro_4)
		{
		$stat_text = "<div class='label label-success' style='font-size:12px;'>Within Advanced</div>";
		}
 else if ($salary2 >= $getpro_4 && $salary2 <= $getpro_5)
		{
		$stat_text = "<div class='label label-warning' style='font-size:12px;'>Within Proficient</div>";
		}		
		else 
		$stat_text = "<div class='label label-danger' style='font-size:12px;'>Above the Range</div>";
		}
		// section head 1
else if ($rank == $rank6){
if ($salary2 < $getsh1_1){
		$stat_text = "<div class='label label-default' style='font-size:12px;'>Below the Range</div>";
		}
 else if ($salary2 >= $getsh1_1 && $salary2 <= $getsh1_2)
		{
		$stat_text = '<div class="label label-primary" style="font-size:12px;">Within Developmental</div>';
		}
 else if ($salary2 >= $getsh1_2 && $salary2 <= $getsh1_3)
		{
		$stat_text = "<div class='label label-info' style='font-size:12px;'>Within Intermidiate</div>";
		}
 else if ($salary2 >= $getsh1_3 && $salary2 <= $getsh1_4)
		{
		$stat_text = "<div class='label label-success' style='font-size:12px;'>Within Advanced</div>";
		}
 else if ($salary2 >= $getsh1_4 && $salary2 <= $getsh1_5)
		{
		$stat_text = "<div class='label label-warning' style='font-size:12px;'>Within Proficient</div>";
		}
		else 
		$stat_text = "<div class='label label-danger' style='font-size:12px;'>Above the Range</div>";
		}
		// section head 2
else if ($rank == $rank7){
if ($salary2 < $getsh2_1){
		$stat_text = "<div class='label label-default' style='font-size:12px;'>Below the Range</div>";
		}
 else if ($salary2 >= $getsh2_1 && $salary2 <= $getsh2_2)
		{
		$stat_text = '<div class="label label-primary" style="font-size:12px;">Within Developmental</div>';
		}
 else if ($salary2 >= $getsh2_2 && $salary2 <= $getsh2_3)
		{
		$stat_text = "<div class='label label-info' style='font-size:12px;'>Within Intermidiate</div>";
		}
 else if ($salary2 >= $getsh2_3 && $salary2 <= $getsh2_4)
		{
		$stat_text = "<div class='label label-success' style='font-size:12px;'>Within Advanced</div>";
		}
 else if ($salary2 >= $getsh2_4 && $salary2 <= $getsh2_5)
		{
		$stat_text = "<div class='label label-warning' style='font-size:12px;'>Within Proficient</div>";
		}
		else 
		$stat_text = "<div class='label label-danger' style='font-size:12px;'>Above the Range</div>";
		}
		// department head 1
else if ($rank == $rank8){
if ($salary2 < $getdh1_1){
		$stat_text = "<div class='label label-default' style='font-size:12px;'>Below the Range</div>";
		}
 else if ($salary2 >= $getdh1_1 && $salary2 <= $getdh1_2)
		{
		$stat_text = '<div class="label label-primary" style="font-size:12px;">Within Developmental</div>';
		}
 else if ($salary2 >= $getdh1_2 && $salary2 <= $getdh1_3)
		{
		$stat_text = "<div class='label label-info' style='font-size:12px;'>Within Intermidiate</div>";
		}
 else if ($salary2 >= $getdh1_3 && $salary2 <= $getdh1_4)
		{
		$stat_text = "<div class='label label-success' style='font-size:12px;'>Within Advanced</div>";
		}
 else if ($salary2 >= $getdh1_4 && $salary2 <= $getdh1_5)
		{
		$stat_text = "<div class='label label-warning' style='font-size:12px;'>Within Proficient</div>";
		}
		else 
		$stat_text = "<div class='label label-danger' style='font-size:12px;'>Above the Range</div>";
		}
		// department head 2
else if ($rank == $rank9){
if ($salary2 < $getdh2_1){
		$stat_text = "<div class='label label-default' style='font-size:12px;'>Below the Range</div>";
		}
 else if ($salary2 >= $getdh2_1 && $salary2 <= $getdh2_2)
		{
		$stat_text = '<div class="label label-primary" style="font-size:12px;">Within Developmental</div>';
		}
 else if ($salary2 >= $getdh2_2 && $salary2 <= $getdh2_3)
		{
		$stat_text = "<div class='label label-info' style='font-size:12px;'>Within Intermidiate</div>";
		}
 else if ($salary2 >= $getdh2_3 && $salary2 <= $getdh2_4)
		{
		$stat_text = "<div class='label label-success' style='font-size:12px;'>Within Advanced</div>";
		}
 else if ($salary2 >= $getdh2_4 && $salary2 <= $getdh2_5)
		{
		$stat_text = "<div class='label label-warning' style='font-size:12px;'>Within Proficient</div>";
		}
		else 
		$stat_text = "<div class='label label-danger' style='font-size:12px;'>Above the Range</div>";
		}
		
				// Group Head I
else if ($rank == $rank10){
if ($salary2 < $getgh1_1){
		$stat_text = "<div class='label label-default' style='font-size:12px;'>Below the Range</div>";
		}
 else if ($salary2 >= $getgh1_1 && $salary2 <= $getgh1_2)
		{
		$stat_text = '<div class="label label-primary" style="font-size:12px;">Within Developmental</div>';
		}
 else if ($salary2 >= $getgh1_2 && $salary2 <= $getgh1_3)
		{
		$stat_text = "<div class='label label-info' style='font-size:12px;'>Within Intermidiate</div>";
		}
 else if ($salary2 >= $getgh1_3 && $salary2 <= $getgh1_4)
		{
		$stat_text = "<div class='label label-success' style='font-size:12px;'>Within Advanced</div>";
		}
 else if ($salary2 >= $getgh1_4 && $salary2 <= $getgh1_5)
		{
		$stat_text = "<div class='label label-warning' style='font-size:12px;'>Within Proficient</div>";
		}
		else 
		$stat_text = "<div class='label label-danger' style='font-size:12px;'>Above the Range</div>";
		}

				// Group Head II
else if ($rank == $rank11){
if ($salary2 < $getgh2_1){
		$stat_text = "<div class='label label-default' style='font-size:12px;'>Below the Range</div>";
		}
 else if ($salary2 >= $getgh2_1 && $salary2 <= $getgh2_2)
		{
		$stat_text = '<div class="label label-primary" style="font-size:12px;">Within Developmental</div>';
		}
 else if ($salary2 >= $getgh2_2 && $salary2 <= $getgh2_3)
		{
		$stat_text = "<div class='label label-info' style='font-size:12px;'>Within Intermidiate</div>";
		}
 else if ($salary2 >= $getgh2_3 && $salary2 <= $getgh2_4)
		{
		$stat_text = "<div class='label label-success' style='font-size:12px;'>Within Advanced</div>";
		}
 else if ($salary2 >= $getgh2_4 && $salary2 <= $getgh2_5)
		{
		$stat_text = "<div class='label label-warning' style='font-size:12px;'>Within Proficient</div>";
		}
		else 
		$stat_text = "<div class='label label-danger' style='font-size:12px;'>Above the Range</div>";
		}
		
		// Executive I
else if ($rank == $rank12){
if ($salary2 < $getexe_1){
		$stat_text = "<div class='label label-default' style='font-size:12px;'>Below the Range</div>";
		}
 else if ($salary2 >= $getexe_1 && $salary2 <= $getexe_2)
		{
		$stat_text = '<div class="label label-primary" style="font-size:12px;">Within Developmental</div>';
		}
 else if ($salary2 >= $getexe_2 && $salary2 <= $getexe_3)
		{
		$stat_text = "<div class='label label-info' style='font-size:12px;'>Within Intermidiate</div>";
		}
 else if ($salary2 >= $getexe_3 && $salary2 <= $getexe_4)
		{
		$stat_text = "<div class='label label-success' style='font-size:12px;'>Within Advanced</div>";
		}
 else if ($salary2 >= $getexe_4 && $salary2 <= $getexe_5)
		{
		$stat_text = "<div class='label label-warning' style='font-size:12px;'>Within Proficient</div>";
		}
		else 
		$stat_text = "<div class='label label-danger' style='font-size:12px;'>Above the Range</div>";
		}
				// Executive II
else if ($rank == $rank13){
if ($salary2 < $getexe2_1){
		$stat_text = "<div class='label label-default' style='font-size:12px;'>Below the Range</div>";
		}
 else if ($salary2 >= $getexe2_1 && $salary2 <= $getexe2_2)
		{
		$stat_text = '<div class="label label-primary" style="font-size:12px;">Within Developmental</div>';
		}
 else if ($salary2 >= $getexe2_2 && $salary2 <= $getexe2_3)
		{
		$stat_text = "<div class='label label-info' style='font-size:12px;'>Within Intermidiate</div>";
		}
 else if ($salary2 >= $getexe2_3 && $salary2 <= $getexe2_4)
		{
		$stat_text = "<div class='label label-success' style='font-size:12px;'>Within Advanced</div>";
		}
 else if ($salary2 >= $getexe2_4 && $salary2 <= $getexe2_5)
		{
		$stat_text = "<div class='label label-warning' style='font-size:12px;'>Within Proficient</div>";
		}
		else 
		$stat_text = "<div class='label label-danger' style='font-size:12px;'>Above the Range</div>";
		}

				// Executive III
else if ($rank == $rank14){
if ($salary2 < $getexe3_1){
		$stat_text = "<div class='label label-default' style='font-size:12px;'>Below the Range</div>";
		}
 else if ($salary2 >= $getexe3_1 && $salary2 <= $getexe3_2)
		{
		$stat_text = '<div class="label label-primary" style="font-size:12px;">Within Developmental</div>';
		}
 else if ($salary2 >= $getexe3_2 && $salary2 <= $getexe3_3)
		{
		$stat_text = "<div class='label label-info' style='font-size:12px;'>Within Intermidiate</div>";
		}
 else if ($salary2 >= $getexe3_3 && $salary2 <= $getexe3_4)
		{
		$stat_text = "<div class='label label-success' style='font-size:12px;'>Within Advanced</div>";
		}
 else if ($salary2 >= $getexe3_4 && $salary2 <= $getexe3_5)
		{
		$stat_text = "<div class='label label-warning' style='font-size:12px;'>Within Proficient</div>";
		}
		else 
		$stat_text = "<div class='label label-danger' style='font-size:12px;'>Above the Range</div>";
		}

?>
		
			<tr>
			<td><?php echo $row['emp_id']; ?></td>
			<td><?php echo $row['emp_name']; ?></td>
			<td><?php echo $row['rank']; ?></td>
			<td><?php echo $row['dept']; ?></td>
		<td><?php echo $row['title']; ?></td>
			<td><?php echo $row['category']; ?></td>
			<td><?php echo $row['current']; ?></td>
			<td align="center"><?php echo $stat_text; ?></td>
			<td align="center">
			<a id="<?php echo $row['emp_id']; ?>" class="edit-link" href="#" title="Edit">
		<button class="btn btn-default"  data-toggle="tooltip" data-placement="top" title="Edit / Preview" ><span class="glyphicon glyphicon-pencil" style="font-size:10px;"></span></button>
            </a></td>
			<td align="center"><a id="<?php echo $row['emp_id']; ?>" class="delete-link" href="#" title="Delete">
		<button class="btn btn-danger"  data-toggle="tooltip" data-placement="top" title="Delete"><span class="glyphicon glyphicon-trash" style="font-size:10px;"></span></button>
            </a></td>

			</tr>
			
			<?php $stat_text = "";
		}
		?>
        </tbody>
        </table>

    
                    </div>
                </div>
			
        <!-- /#page-content-wrapper -->

    </div>
	 </div>
    <!-- /#wrapper -->
     <!-- Menu Toggle Script -->
	 	 <!---- MODAL STARTS HERE (EDIT LINK) ---->
	 
	 
  <div class="modal fade" id="modaledit" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h3 class="modal-title text-primary"><span class="glyphicon glyphicon-pencil"> </span> Edit/Preview Data</h3>
        </div>
        <div class="modal-body">
          <p>Do you want to edit/preview Employee No. <c id="empidedit"></c>?</p>
        </div>
        <div class="modal-footer">
		  <button type="button" id="no" value="no" data-dismiss="modal" class="btn btn-default" > No </button>
		  <button type="button" id="yesedit" value="yes" class="btn btn-primary" autofocus > Yes </button>
		
        </div>
      </div>
      
    </div>
  </div>	
  
  	 <!---- MODAL STARTS HERE (DELETE LINK) ---->
	 
	   <div class="modal fade" id="modaldelete" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h3 class="modal-title text-danger"><span class="glyphicon glyphicon-trash"> </span> Delete</h3>
        </div>
        <div class="modal-body">
          <p>Do you want to set <i>inactive</i> Employee No. <c id="empiddel"></c>?</p>
        </div>
        <div class="modal-footer">
		  <button type="button" id="no" value="no" data-dismiss="modal" class="btn btn-default" > No </button>
		  <button type="button" id="yesdelete" value="yes" class="btn btn-primary" autofocus > Yes </button>
		
        </div>
      </div>
      
    </div>
  </div>	
	 
	 
	 <!---- MODAL ENDS HERE ------>

	 
	 
<?php include('../../assets/navbar.php'); ?>   
<script src="../../bootstrap/js/bootstrap.min.js"></script>
<script type="text/javascript" src="../../assets/datatables.min.js"></script>
<script type="text/javascript" src="../../assets/crud.js"></script>

<script type="text/javascript" charset="utf-8">
$(document).ready(function() {
	$('#example').DataTable({
	aaSorting : [[0, 'desc']]
	});

	$('#example')
	.removeClass( 'display' )
	.addClass('table table-bordered');
	 
});

</script>
</body>
</html>