<?php
require_once '../../assets/dbconfig.php';
require_once '../../assets/connection.php';

if($_GET['edit_id'])
{
	$id = $_GET['edit_id'];	
	$stmt=$db_con->prepare("SELECT * FROM emp_job_data WHERE emp_id=:id");
	$stmt->execute(array(':id'=>$id));	
	$row=$stmt->fetch(PDO::FETCH_ASSOC);
	$stmt2 = $db_con->prepare("SELECT emp_name FROM emp_personal_data INNER JOIN emp_job_data ON emp_job_data.emp_id=emp_personal_data.emp_ID WHERE emp_job_data.emp_id=:id");
    $stmt2->execute(array(':id'=>$id));
	$row2=$stmt2->fetch(PDO::FETCH_ASSOC);
	$stmt3 = $db_con->prepare("SELECT rank FROM job_classification INNER JOIN emp_job_data ON emp_job_data.job_id=job_classification.job_id WHERE emp_id=:id");
    $stmt3->execute(array(':id'=>$id));
	$row3=$stmt3->fetch(PDO::FETCH_ASSOC);
}
?>
	    <link href="../../bootstrap/css/bootstrap-datepicker.css" rel="stylesheet" type="text/css"/>
		<link href="../../bootstrap/css/blink.css" rel="stylesheet" type="text/css"/>
		<script src="../../bootstrap/js/bootstrap-datepicker.min.js"></script>
				<script src="../../assets/bootstrap-formhelpers-phone.js"></script>

<script>


 $(document).ready(function(){
$('input[name="bday"]').datepicker({
		format: "mm/dd/yyyy",
		startView: 'month'   
		})
        });
		
		$(document).ready(function(){
    $('[data-toggle="tooltip"]').tooltip();   
});


$(document).ready(function() {
    $("#apply").click(function(e){
	e.preventDefault();
	if(confirm('Apply recommended salary?'))
	{
        $.ajax({
            type: "POST",
            url: "applyrecsalary.php", //process to add
            data: $('form#emp-UpdateForm').serialize(),					
            success: function(data){
			$(".loader").fadeIn();
			$("#dis").fadeOut();
						$("#dis").css('display','block') 
			$("#dis").fadeIn('slow') 
		$("#dis").html('<div class="alert alert-success"><span class="glyphicon glyphicon-ok">&nbsp;</span>'+data+'</div>');
				     setTimeout(function(){
        $("#dis").fadeOut();
    }, 2000); 
					  setTimeout(
  function() 
  {
$(".loader").fadeOut();
  }, 2000);
  								setTimeout(function(){
location.reload();
    }, 2000);  
	}		  
        });
		}
return false;
		});
		});

function Comma(Num) { //function to add commas to textboxes
        Num += '';
        Num = Num.replace(',', ''); Num = Num.replace(',', ''); Num = Num.replace(',', '');
        Num = Num.replace(',', ''); Num = Num.replace(',', ''); Num = Num.replace(',', '');
        x = Num.split('.');
        x1 = x[0];
        x2 = x.length > 1 ? '.' + x[1] : '';
        var rgx = /(\d+)(\d{3})/;
        while (rgx.test(x1))
            x1 = x1.replace(rgx, '$1' + ',' + '$2');
        return x1 + x2;
    }
		</script>
<style type="text/css">
#dis{
	display: none;
	margin-left: 70px;
	position: fixed;
	top: 50px;
	width: 68%;
	padding:20px;
	z-index:99999;
}
  .loader {
	position: fixed;
	left: 0px;
	top: 0px;
	width: 100%;
	height: 100%;
	z-index: 9999;
	background: url('../../img/loading.gif') 50% 50% no-repeat rgb(249,249,249);
	opacity: .5;
}

#square {
background-color: #ECECFF;
-webkit-box-shadow: 0px 0px 2px rgba(50, 50, 50, 0.31);
    -moz-box-shadow:    0px 0px 5px rgba(50, 50, 50, 0.31);
    box-shadow:         0px 0px 10px rgba(50, 50, 50, 0.31);
padding:20px;
}
.add {
border-radius: 100%;
padding-top:15px;
padding-bottom: 17px;
padding-left: 15px;
padding-right: 17px;
font-size:24px;		
}
.add:focus{
outline: 0px;
}
#btn-save {
border-radius: 100%;
padding-top:25px;
padding-bottom: 25px;
padding-left: 25px;
padding-right: 25px;
font-size:36px;
			    -webkit-box-shadow: 0px 0px 10px rgba(50, 50, 50, 20);
    -moz-box-shadow:    0px 0px 10px rgba(50, 50, 50, 20);
    box-shadow:         0px 0px 10px rgba(50, 50, 50, 20);
}
#btn-save:focus{
outline: 0px;
}
#apply{
display:none;
}
  @media only screen and (max-width: 768px) 
{ 
#dis{
	top: 75px;
	margin-left: 0;
	width:70%
}

</style>
<?php 
require_once '../../assets/dbconfig.php';

$rank1_sql=mysql_query("select rank from job_classification where job_id='1'", $connection);
$rows1 = mysql_fetch_assoc($rank1_sql);
$rank1 = $rows1['rank'];

$rank2_sql=mysql_query("select rank from job_classification where job_id='2'", $connection);
$rows2 = mysql_fetch_assoc($rank2_sql);
$rank2 = $rows2['rank'];

$rank3_sql=mysql_query("select rank from job_classification where job_id='3'", $connection);
$rows3 = mysql_fetch_assoc($rank3_sql);
$rank3 = $rows3['rank'];

$rank4_sql=mysql_query("select rank from job_classification where job_id='4'", $connection);
$rows4 = mysql_fetch_assoc($rank4_sql);
$rank4 = $rows4['rank'];

$rank5_sql=mysql_query("select rank from job_classification where job_id='5'", $connection);
$rows5 = mysql_fetch_assoc($rank5_sql);
$rank5 = $rows5['rank'];

$rank6_sql=mysql_query("select rank from job_classification where job_id='6'", $connection);
$rows6 = mysql_fetch_assoc($rank6_sql);
$rank6 = $rows6['rank'];

$rank7_sql=mysql_query("select rank from job_classification where job_id='7'", $connection);
$rows7 = mysql_fetch_assoc($rank7_sql);
$rank7 = $rows7['rank'];

$rank8_sql=mysql_query("select rank from job_classification where job_id='8'", $connection);
$rows8 = mysql_fetch_assoc($rank8_sql);
$rank8 = $rows8['rank'];

$rank9_sql=mysql_query("select rank from job_classification where job_id='9'", $connection);
$rows9 = mysql_fetch_assoc($rank9_sql);
$rank9 = $rows9['rank'];

$rank10_sql=mysql_query("select rank from job_classification where job_id='10'", $connection);
$rows10 = mysql_fetch_assoc($rank10_sql);
$rank10 = $rows10['rank'];

$rank11_sql=mysql_query("select rank from job_classification where job_id='11'", $connection);
$rows11 = mysql_fetch_assoc($rank11_sql);
$rank11 = $rows11['rank'];

$rank12_sql=mysql_query("select rank from job_classification where job_id='12'", $connection);
$rows12 = mysql_fetch_assoc($rank12_sql);
$rank12 = $rows12['rank'];

$rank13_sql=mysql_query("select rank from job_classification where job_id='13'", $connection);
$rows13 = mysql_fetch_assoc($rank13_sql);
$rank13 = $rows13['rank'];

$rank14_sql=mysql_query("select rank from job_classification where job_id='14'", $connection);
$rows14 = mysql_fetch_assoc($rank14_sql);
$rank14 = $rows14['rank'];

$sal_sql=mysql_query("select sal_range from emp_job_data where emp_job_id='1'", $connection);
$row4 = mysql_fetch_assoc($sal_sql);
$salrange =$row4['sal_range'];
$getsal = $salrange;
$rf1_1 = (((float)$getsal*313)/12);
$rf1_2 = $rf1_1*0.03125+$rf1_1;
$rf1_3 = $rf1_2*0.03125+$rf1_2;
$rf1_4 = $rf1_3*0.03125+$rf1_3;
$rf1_5 = $rf1_4*0.03125+$rf1_4;
$rf1_6 = $rf1_5*0.03125+$rf1_5;

$getrf1_1 = (round($rf1_1, 2));
$getrf1_2 = (round($rf1_2, 2));
$getrf1_3 = (round($rf1_3, 2));
$getrf1_4 = (round($rf1_4, 2));
$getrf1_5 = (round($rf1_5, 2));
$getrf1_6 = (round($rf1_6, 2));


//rank and file 2
$rf2_1 = $rf1_3*0.04+$rf1_3;
$rf2_2 = $rf2_1*0.05+$rf2_1;
$rf2_3 = $rf2_2*0.05+$rf2_2;
$rf2_4 = $rf2_3*0.05+$rf2_3;
$rf2_5 = $rf2_4*0.05+$rf2_4;

$getrf2_1 = (round($rf2_1, 2));
$getrf2_2 = (round($rf2_2, 2));
$getrf2_3 = (round($rf2_3, 2));
$getrf2_4 = (round($rf2_4, 2));
$getrf2_5 = (round($rf2_5, 2));

//Staff 1
$s1_1 = $rf2_3*0.06+$rf2_3;
$s1_2 = $s1_1*0.05+$s1_1;
$s1_3 = $s1_2*0.05+$s1_2;
$s1_4 = $s1_3*0.05+$s1_3;
$s1_5 = $s1_4*0.05+$s1_4;

$gets1_1 = (round($s1_1, 2));
$gets1_2 = (round($s1_2, 2));
$gets1_3 = (round($s1_3, 2));
$gets1_4 = (round($s1_4, 2));
$gets1_5 = (round($s1_5, 2));

//Staff 2
$s2_1 = $s1_3*0.06+$s1_3;
$s2_2 = $s2_1*0.05+$s2_1;
$s2_3 = $s2_2*0.05+$s2_2;
$s2_4 = $s2_3*0.05+$s2_3;
$s2_5 = $s2_4*0.05+$s2_4;

$gets2_1 = (round($s2_1, 2));
$gets2_2 = (round($s2_2, 2));
$gets2_3 = (round($s2_3, 2));
$gets2_4 = (round($s2_4, 2));
$gets2_5 = (round($s2_5, 2));

//Professional
$pro_1 = $s2_3*0.08+$s2_3;
$pro_2 = $pro_1*0.05+$pro_1;
$pro_3 = $pro_2*0.05+$pro_2;
$pro_4 = $pro_3*0.05+$pro_3;
$pro_5 = $pro_4*0.05+$pro_4;

$getpro_1 = (round($pro_1, 2));
$getpro_2 = (round($pro_2, 2));
$getpro_3 = (round($pro_3, 2));
$getpro_4 = (round($pro_4, 2));
$getpro_5 = (round($pro_5, 2));

//Section Head 1
$sh1_1 = $pro_3*0.08+$pro_3;
$sh1_2 = $sh1_1*0.05+$sh1_1;
$sh1_3 = $sh1_2*0.05+$sh1_2;
$sh1_4 = $sh1_3*0.05+$sh1_3;
$sh1_5 = $sh1_4*0.05+$sh1_4;

$getsh1_1 = (round($sh1_1, 2));
$getsh1_2 = (round($sh1_2, 2));
$getsh1_3 = (round($sh1_3, 2));
$getsh1_4 = (round($sh1_4, 2));
$getsh1_5 = (round($sh1_5, 2));

//Section Head 2
$sh2_1 = $sh1_3*0.08+$sh1_3;
$sh2_2 = $sh2_1*0.05+$sh2_1;
$sh2_3 = $sh2_2*0.05+$sh2_2;
$sh2_4 = $sh2_3*0.05+$sh2_3;
$sh2_5 = $sh2_4*0.05+$sh2_4;

$getsh2_1 = (round($sh2_1, 2));
$getsh2_2 = (round($sh2_2, 2));
$getsh2_3 = (round($sh2_3, 2));
$getsh2_4 = (round($sh2_4, 2));
$getsh2_5 = (round($sh2_5, 2));

//Department Head 1
$dh1_1 = $sh2_3*0.10+$sh2_3;
$dh1_2 = $dh1_1*0.05+$dh1_1;
$dh1_3 = $dh1_2*0.05+$dh1_2;
$dh1_4 = $dh1_3*0.05+$dh1_3;
$dh1_5 = $dh1_4*0.05+$dh1_4;

$getdh1_1 = (round($dh1_1, 2));
$getdh1_2 = (round($dh1_2, 2));
$getdh1_3 = (round($dh1_3, 2));
$getdh1_4 = (round($dh1_4, 2));
$getdh1_5 = (round($dh1_5, 2));

//Department Head 2
$dh2_1 = $dh1_3*0.10+$dh1_3;
$dh2_2 = $dh2_1*0.05+$dh2_1;
$dh2_3 = $dh2_2*0.05+$dh2_2;
$dh2_4 = $dh2_3*0.05+$dh2_3;
$dh2_5 = $dh2_4*0.05+$dh2_4;

$getdh2_1 = (round($dh2_1, 2));
$getdh2_2 = (round($dh2_2, 2));
$getdh2_3 = (round($dh2_3, 2));
$getdh2_4 = (round($dh2_4, 2));
$getdh2_5 = (round($dh2_5, 2));

//Group Head I
$gh1_1 = $dh2_3*0.12+$dh2_3;
$gh1_2 = $gh1_1*0.05+$gh1_1;
$gh1_3 = $gh1_2*0.05+$gh1_2;
$gh1_4 = $gh1_3*0.05+$gh1_3;
$gh1_5 = $gh1_4*0.05+$gh1_4;

$getgh1_1 = (round($gh1_1, 2));
$getgh1_2 = (round($gh1_2, 2));
$getgh1_3 = (round($gh1_3, 2));
$getgh1_4 = (round($gh1_4, 2));
$getgh1_5 = (round($gh1_5, 2));

//Group Head 2
$gh2_1 = $gh1_3*0.12+$gh1_3;
$gh2_2 = $gh2_1*0.05+$gh2_1;
$gh2_3 = $gh2_2*0.05+$gh2_2;
$gh2_4 = $gh2_3*0.05+$gh2_3;
$gh2_5 = $gh2_4*0.05+$gh2_4;

$getgh2_1 = (round($gh2_1, 2));
$getgh2_2 = (round($gh2_2, 2));
$getgh2_3 = (round($gh2_3, 2));
$getgh2_4 = (round($gh2_4, 2));
$getgh2_5 = (round($gh2_5, 2));

//Executive I
$exe_1 = $gh2_3*0.15+$gh2_3;
$exe_2 = $exe_1*0.05+$exe_1;
$exe_3 = $exe_2*0.05+$exe_2;
$exe_4 = $exe_3*0.05+$exe_3;
$exe_5 = $exe_4*0.05+$exe_4;

$getexe_1 = (round($exe_1, 2));
$getexe_2 = (round($exe_2, 2));
$getexe_3 = (round($exe_3, 2));
$getexe_4 = (round($exe_4, 2));
$getexe_5 = (round($exe_5, 2));

//exe2cutive I
$exe2_1 = $exe_3*0.15+$exe_3;
$exe2_2 = $exe2_1*0.05+$exe2_1;
$exe2_3 = $exe2_2*0.05+$exe2_2;
$exe2_4 = $exe2_3*0.05+$exe2_3;
$exe2_5 = $exe2_4*0.05+$exe2_4;

$getexe2_1 = (round($exe2_1, 2));
$getexe2_2 = (round($exe2_2, 2));
$getexe2_3 = (round($exe2_3, 2));
$getexe2_4 = (round($exe2_4, 2));
$getexe2_5 = (round($exe2_5, 2));

//Executive III
$exe3_1 = $exe2_3*0.15+$exe2_3;
$exe3_2 = $exe3_1*0.05+$exe3_1;
$exe3_3 = $exe3_2*0.05+$exe3_2;
$exe3_4 = $exe3_3*0.05+$exe3_3;
$exe3_5 = $exe3_4*0.05+$exe3_4;

$getexe3_1 = (round($exe3_1, 2));
$getexe3_2 = (round($exe3_2, 2));
$getexe3_3 = (round($exe3_3, 2));
$getexe3_4 = (round($exe3_4, 2));
$getexe3_5 = (round($exe3_5, 2));


$pre_salary= $row['pre_salary'];
$pre_text= "";
if ($row["pre_salary"] != 0)
{
$pre_text = "Previous Salary : ";
}

$percat= $row['per_category'];
$per_text= "";
if ($row["per_category"] != "")
{
$per_text = "Performance Category : ";
}

$stat_text = "";
$salary = $row['current']; 
$salary2 = (float)str_replace(",","",$salary);
$rank = $row3['rank'];
if ($rank == $rank1){
if ($salary2 < $getrf1_1){
		$stat_text = "<div class='label label-default' style='font-size:12px;'>Below the Range</div>";
		}
 else if ($salary2 >= $getrf1_1 && $salary2 <= $getrf1_2)
		{
		$stat_text = '<div class="label label-primary" style="font-size:12px;">Within Developmental</div>';
		}
 else if ($salary2 >= $getrf1_2 && $salary2 <= $getrf1_3)
		{
		$stat_text = "<div class='label label-info' style='font-size:12px;'>Within Intermidiate</div>";
		}
 else if ($salary2 >= $getrf1_3 && $salary2 <= $getrf1_4)
		{
		$stat_text = "<div class='label label-success' style='font-size:12px;'>Within Advanced</div>";
		}
 else if ($salary2 >= $getrf1_4 && $salary2 <= $getrf1_5)
		{
		$stat_text = "<div class='label label-warning' style='font-size:12px;'>Within Proficient</div>";
		}	
		else 
		$stat_text = "<div class='label label-danger' style='font-size:12px;'>Above the Range</div>";
		}

// rank and file 2
else if ($rank == $rank2){
if ($salary2 < $getrf2_1){
		$stat_text = "<div class='label label-default' style='font-size:12px;'>Below the Range</div>";
		}
 else if ($salary2 >= $getrf2_1 && $salary2 <= $getrf2_2)
		{
		$stat_text = '<div class="label label-primary" style="font-size:12px;">Within Developmental</div>';
		}
 else if ($salary2 >= $getrf2_2 && $salary2 <= $getrf2_3)
		{
		$stat_text = "<div class='label label-info' style='font-size:12px;'>Within Intermidiate</div>";
		}
 else if ($salary2 >= $getrf2_3 && $salary2 <= $getrf2_4)
		{
		$stat_text = "<div class='label label-success' style='font-size:12px;'>Within Advanced</div>";
		}
 else if ($salary2 >= $getrf2_4 && $salary2 <= $getrf2_5)
		{
		$stat_text = "<div class='label label-warning' style='font-size:12px;'>Within Proficient</div>";
		}
		else 
		$stat_text = "<div class='label label-danger' style='font-size:12px;'>Above the Range</div>";
		}
// staff 1
else if ($rank == $rank3){
if ($salary2 < $gets1_1){
		$stat_text = "<div class='label label-default' style='font-size:12px;'>Below the Range</div>";
		}
 else if ($salary2 >= $gets1_1 && $salary2 <= $gets1_2)
		{
		$stat_text = '<div class="label label-primary" style="font-size:12px;">Within Developmental</div>';
		}
 else if ($salary2 >= $gets1_2 && $salary2 <= $gets1_3)
		{
		$stat_text = "<div class='label label-info' style='font-size:12px;'>Within Intermidiate</div>";
		}
 else if ($salary2 >= $gets1_3 && $salary2 <= $gets1_4)
		{
		$stat_text = "<div class='label label-success' style='font-size:12px;'>Within Advanced</div>";
		}
 else if ($salary2 >= $gets1_4 && $salary2 <= $gets1_5)
		{
		$stat_text = "<div class='label label-warning' style='font-size:12px;'>Within Proficient</div>";
		}
		else 
		$stat_text = "<div class='label label-danger' style='font-size:12px;'>Above the Range</div>";
		}
		
		// staff 2
else if ($rank == $rank4){
if ($salary2 < $gets2_1){
		$stat_text = "<div class='label label-default' style='font-size:12px;'>Below the Range</div>";
		}
 else if ($salary2 >= $gets2_1 && $salary2 <= $gets2_2)
		{
		$stat_text = '<div class="label label-primary" style="font-size:12px;">Within Developmental</div>';
		}
 else if ($salary2 >= $gets2_2 && $salary2 <= $gets2_3)
		{
		$stat_text = "<div class='label label-info' style='font-size:12px;'>Within Intermidiate</div>";
		}
 else if ($salary2 >= $gets2_3 && $salary2 <= $gets2_4)
		{
		$stat_text = "<div class='label label-success' style='font-size:12px;'>Within Advanced</div>";
		}
 else if ($salary2 >= $gets2_4 && $salary2 <= $gets2_5)
		{
		$stat_text = "<div class='label label-warning' style='font-size:12px;'>Within Proficient</div>";
		}
		else 
		$stat_text = "<div class='label label-danger' style='font-size:12px;'>Above the Range</div>";
		}
		// professional
else if ($rank == $rank5){
if ($salary2 < $getpro_1){
		$stat_text = "<div class='label label-default' style='font-size:12px;'>Below the Range</div>";
		}
 else if ($salary2 >= $getpro_1 && $salary2 <= $getpro_2)
		{
		$stat_text = '<div class="label label-primary" style="font-size:12px;">Within Developmental</div>';
		}
 else if ($salary2 >= $getpro_2 && $salary2 <= $getpro_3)
		{
		$stat_text = "<div class='label label-info' style='font-size:12px;'>Within Intermidiate</div>";
		}
 else if ($salary2 >= $getpro_3 && $salary2 <= $getpro_4)
		{
		$stat_text = "<div class='label label-success' style='font-size:12px;'>Within Advanced</div>";
		}
 else if ($salary2 >= $getpro_4 && $salary2 <= $getpro_5)
		{
		$stat_text = "<div class='label label-warning' style='font-size:12px;'>Within Proficient</div>";
		}		
		else 
		$stat_text = "<div class='label label-danger' style='font-size:12px;'>Above the Range</div>";
		}
		// section head 1
else if ($rank == $rank6){
if ($salary2 < $getsh1_1){
		$stat_text = "<div class='label label-default' style='font-size:12px;'>Below the Range</div>";
		}
 else if ($salary2 >= $getsh1_1 && $salary2 <= $getsh1_2)
		{
		$stat_text = '<div class="label label-primary" style="font-size:12px;">Within Developmental</div>';
		}
 else if ($salary2 >= $getsh1_2 && $salary2 <= $getsh1_3)
		{
		$stat_text = "<div class='label label-info' style='font-size:12px;'>Within Intermidiate</div>";
		}
 else if ($salary2 >= $getsh1_3 && $salary2 <= $getsh1_4)
		{
		$stat_text = "<div class='label label-success' style='font-size:12px;'>Within Advanced</div>";
		}
 else if ($salary2 >= $getsh1_4 && $salary2 <= $getsh1_5)
		{
		$stat_text = "<div class='label label-warning' style='font-size:12px;'>Within Proficient</div>";
		}
		else 
		$stat_text = "<div class='label label-danger' style='font-size:12px;'>Above the Range</div>";
		}
		// section head 2
else if ($rank == $rank7){
if ($salary2 < $getsh2_1){
		$stat_text = "<div class='label label-default' style='font-size:12px;'>Below the Range</div>";
		}
 else if ($salary2 >= $getsh2_1 && $salary2 <= $getsh2_2)
		{
		$stat_text = '<div class="label label-primary" style="font-size:12px;">Within Developmental</div>';
		}
 else if ($salary2 >= $getsh2_2 && $salary2 <= $getsh2_3)
		{
		$stat_text = "<div class='label label-info' style='font-size:12px;'>Within Intermidiate</div>";
		}
 else if ($salary2 >= $getsh2_3 && $salary2 <= $getsh2_4)
		{
		$stat_text = "<div class='label label-success' style='font-size:12px;'>Within Advanced</div>";
		}
 else if ($salary2 >= $getsh2_4 && $salary2 <= $getsh2_5)
		{
		$stat_text = "<div class='label label-warning' style='font-size:12px;'>Within Proficient</div>";
		}
		else 
		$stat_text = "<div class='label label-danger' style='font-size:12px;'>Above the Range</div>";
		}
		// department head 1
else if ($rank == $rank8){
if ($salary2 < $getdh1_1){
		$stat_text = "<div class='label label-default' style='font-size:12px;'>Below the Range</div>";
		}
 else if ($salary2 >= $getdh1_1 && $salary2 <= $getdh1_2)
		{
		$stat_text = '<div class="label label-primary" style="font-size:12px;">Within Developmental</div>';
		}
 else if ($salary2 >= $getdh1_2 && $salary2 <= $getdh1_3)
		{
		$stat_text = "<div class='label label-info' style='font-size:12px;'>Within Intermidiate</div>";
		}
 else if ($salary2 >= $getdh1_3 && $salary2 <= $getdh1_4)
		{
		$stat_text = "<div class='label label-success' style='font-size:12px;'>Within Advanced</div>";
		}
 else if ($salary2 >= $getdh1_4 && $salary2 <= $getdh1_5)
		{
		$stat_text = "<div class='label label-warning' style='font-size:12px;'>Within Proficient</div>";
		}
		else 
		$stat_text = "<div class='label label-danger' style='font-size:12px;'>Above the Range</div>";
		}
		// department head 2
else if ($rank == $rank9){
if ($salary2 < $getdh2_1){
		$stat_text = "<div class='label label-default' style='font-size:12px;'>Below the Range</div>";
		}
 else if ($salary2 >= $getdh2_1 && $salary2 <= $getdh2_2)
		{
		$stat_text = '<div class="label label-primary" style="font-size:12px;">Within Developmental</div>';
		}
 else if ($salary2 >= $getdh2_2 && $salary2 <= $getdh2_3)
		{
		$stat_text = "<div class='label label-info' style='font-size:12px;'>Within Intermidiate</div>";
		}
 else if ($salary2 >= $getdh2_3 && $salary2 <= $getdh2_4)
		{
		$stat_text = "<div class='label label-success' style='font-size:12px;'>Within Advanced</div>";
		}
 else if ($salary2 >= $getdh2_4 && $salary2 <= $getdh2_5)
		{
		$stat_text = "<div class='label label-warning' style='font-size:12px;'>Within Proficient</div>";
		}
		else 
		$stat_text = "<div class='label label-danger' style='font-size:12px;'>Above the Range</div>";
		}
		
				// Group Head I
else if ($rank == $rank10){
if ($salary2 < $getgh1_1){
		$stat_text = "<div class='label label-default' style='font-size:12px;'>Below the Range</div>";
		}
 else if ($salary2 >= $getgh1_1 && $salary2 <= $getgh1_2)
		{
		$stat_text = '<div class="label label-primary" style="font-size:12px;">Within Developmental</div>';
		}
 else if ($salary2 >= $getgh1_2 && $salary2 <= $getgh1_3)
		{
		$stat_text = "<div class='label label-info' style='font-size:12px;'>Within Intermidiate</div>";
		}
 else if ($salary2 >= $getgh1_3 && $salary2 <= $getgh1_4)
		{
		$stat_text = "<div class='label label-success' style='font-size:12px;'>Within Advanced</div>";
		}
 else if ($salary2 >= $getgh1_4 && $salary2 <= $getgh1_5)
		{
		$stat_text = "<div class='label label-warning' style='font-size:12px;'>Within Proficient</div>";
		}
		else 
		$stat_text = "<div class='label label-danger' style='font-size:12px;'>Above the Range</div>";
		}

				// Group Head II
else if ($rank == $rank11){
if ($salary2 < $getgh2_1){
		$stat_text = "<div class='label label-default' style='font-size:12px;'>Below the Range</div>";
		}
 else if ($salary2 >= $getgh2_1 && $salary2 <= $getgh2_2)
		{
		$stat_text = '<div class="label label-primary" style="font-size:12px;">Within Developmental</div>';
		}
 else if ($salary2 >= $getgh2_2 && $salary2 <= $getgh2_3)
		{
		$stat_text = "<div class='label label-info' style='font-size:12px;'>Within Intermidiate</div>";
		}
 else if ($salary2 >= $getgh2_3 && $salary2 <= $getgh2_4)
		{
		$stat_text = "<div class='label label-success' style='font-size:12px;'>Within Advanced</div>";
		}
 else if ($salary2 >= $getgh2_4 && $salary2 <= $getgh2_5)
		{
		$stat_text = "<div class='label label-warning' style='font-size:12px;'>Within Proficient</div>";
		}
		else 
		$stat_text = "<div class='label label-danger' style='font-size:12px;'>Above the Range</div>";
		}
		
		// Executive I
else if ($rank == $rank12){
if ($salary2 < $getexe_1){
		$stat_text = "<div class='label label-default' style='font-size:12px;'>Below the Range</div>";
		}
 else if ($salary2 >= $getexe_1 && $salary2 <= $getexe_2)
		{
		$stat_text = '<div class="label label-primary" style="font-size:12px;">Within Developmental</div>';
		}
 else if ($salary2 >= $getexe_2 && $salary2 <= $getexe_3)
		{
		$stat_text = "<div class='label label-info' style='font-size:12px;'>Within Intermidiate</div>";
		}
 else if ($salary2 >= $getexe_3 && $salary2 <= $getexe_4)
		{
		$stat_text = "<div class='label label-success' style='font-size:12px;'>Within Advanced</div>";
		}
 else if ($salary2 >= $getexe_4 && $salary2 <= $getexe_5)
		{
		$stat_text = "<div class='label label-warning' style='font-size:12px;'>Within Proficient</div>";
		}
		else 
		$stat_text = "<div class='label label-danger' style='font-size:12px;'>Above the Range</div>";
		}
				// Executive II
else if ($rank == $rank13){
if ($salary2 < $getexe2_1){
		$stat_text = "<div class='label label-default' style='font-size:12px;'>Below the Range</div>";
		}
 else if ($salary2 >= $getexe2_1 && $salary2 <= $getexe2_2)
		{
		$stat_text = '<div class="label label-primary" style="font-size:12px;">Within Developmental</div>';
		}
 else if ($salary2 >= $getexe2_2 && $salary2 <= $getexe2_3)
		{
		$stat_text = "<div class='label label-info' style='font-size:12px;'>Within Intermidiate</div>";
		}
 else if ($salary2 >= $getexe2_3 && $salary2 <= $getexe2_4)
		{
		$stat_text = "<div class='label label-success' style='font-size:12px;'>Within Advanced</div>";
		}
 else if ($salary2 >= $getexe2_4 && $salary2 <= $getexe2_5)
		{
		$stat_text = "<div class='label label-warning' style='font-size:12px;'>Within Proficient</div>";
		}
		else 
		$stat_text = "<div class='label label-danger' style='font-size:12px;'>Above the Range</div>";
		}

				// Executive III
else if ($rank == $rank14){
if ($salary2 < $getexe3_1){
		$stat_text = "<div class='label label-default' style='font-size:12px;'>Below the Range</div>";
		}
 else if ($salary2 >= $getexe3_1 && $salary2 <= $getexe3_2)
		{
		$stat_text = '<div class="label label-primary" style="font-size:12px;">Within Developmental</div>';
		}
 else if ($salary2 >= $getexe3_2 && $salary2 <= $getexe3_3)
		{
		$stat_text = "<div class='label label-info' style='font-size:12px;'>Within Intermidiate</div>";
		}
 else if ($salary2 >= $getexe3_3 && $salary2 <= $getexe3_4)
		{
		$stat_text = "<div class='label label-success' style='font-size:12px;'>Within Advanced</div>";
		}
 else if ($salary2 >= $getexe3_4 && $salary2 <= $getexe3_5)
		{
		$stat_text = "<div class='label label-warning' style='font-size:12px;'>Within Proficient</div>";
		}
		else 
		$stat_text = "<div class='label label-danger' style='font-size:12px;'>Above the Range</div>";
		}
		
//recommendation salary
$rec_stat_text = "";
$rec_salary_float = $row["rec_salary"];
$rec_salary = "";
$rec_text = "";
if ($row["rec_salary"] != "")
{
echo '<style type="text/css">#apply { display: inline;}</style>';
$rec_text = "Recommended Salary : ";
$rec_salary = $row["rec_salary"];
$exsal = str_replace(",","",$rec_salary);	
$recsalary = (float)$exsal;
if ($rank == $rank1){
if ($salary2 < $getrf1_1){
		$rec_stat_text = "<div class='label label-default' style='font-size:12px;'>Below the Range</div>";
		}
 else if ($salary2 >= $getrf1_1 && $salary2 <= $getrf1_2)
		{
		$rec_stat_text = '<div class="label label-primary" style="font-size:12px;">Within Developmental</div>';
		}
 else if ($salary2 >= $getrf1_2 && $salary2 <= $getrf1_3)
		{
		$rec_stat_text = "<div class='label label-info' style='font-size:12px;'>Within Intermidiate</div>";
		}
 else if ($salary2 >= $getrf1_3 && $salary2 <= $getrf1_4)
		{
		$rec_stat_text = "<div class='label label-success' style='font-size:12px;'>Within Advanced</div>";
		}
 else if ($salary2 >= $getrf1_4 && $salary2 <= $getrf1_5)
		{
		$rec_stat_text = "<div class='label label-warning' style='font-size:12px;'>Within Proficient</div>";
		}	
		else 
		$rec_stat_text = "<div class='label label-danger' style='font-size:12px;'>Above the Range</div>";
		}

// rank and file 2
else if ($rank == $rank2){
if ($salary2 < $getrf2_1){
		$rec_stat_text = "<div class='label label-default' style='font-size:12px;'>Below the Range</div>";
		}
 else if ($salary2 >= $getrf2_1 && $salary2 <= $getrf2_2)
		{
		$rec_stat_text = '<div class="label label-primary" style="font-size:12px;">Within Developmental</div>';
		}
 else if ($salary2 >= $getrf2_2 && $salary2 <= $getrf2_3)
		{
		$rec_stat_text = "<div class='label label-info' style='font-size:12px;'>Within Intermidiate</div>";
		}
 else if ($salary2 >= $getrf2_3 && $salary2 <= $getrf2_4)
		{
		$rec_stat_text = "<div class='label label-success' style='font-size:12px;'>Within Advanced</div>";
		}
 else if ($salary2 >= $getrf2_4 && $salary2 <= $getrf2_5)
		{
		$rec_stat_text = "<div class='label label-warning' style='font-size:12px;'>Within Proficient</div>";
		}
		else 
		$rec_stat_text = "<div class='label label-danger' style='font-size:12px;'>Above the Range</div>";
		}
// staff 1
else if ($rank == $rank3){
if ($salary2 < $gets1_1){
		$rec_stat_text = "<div class='label label-default' style='font-size:12px;'>Below the Range</div>";
		}
 else if ($salary2 >= $gets1_1 && $salary2 <= $gets1_2)
		{
		$rec_stat_text = '<div class="label label-primary" style="font-size:12px;">Within Developmental</div>';
		}
 else if ($salary2 >= $gets1_2 && $salary2 <= $gets1_3)
		{
		$rec_stat_text = "<div class='label label-info' style='font-size:12px;'>Within Intermidiate</div>";
		}
 else if ($salary2 >= $gets1_3 && $salary2 <= $gets1_4)
		{
		$rec_stat_text = "<div class='label label-success' style='font-size:12px;'>Within Advanced</div>";
		}
 else if ($salary2 >= $gets1_4 && $salary2 <= $gets1_5)
		{
		$rec_stat_text = "<div class='label label-warning' style='font-size:12px;'>Within Proficient</div>";
		}
		else 
		$rec_stat_text = "<div class='label label-danger' style='font-size:12px;'>Above the Range</div>";
		}
		
		// staff 2
else if ($rank == $rank4){
if ($salary2 < $gets2_1){
		$rec_stat_text = "<div class='label label-default' style='font-size:12px;'>Below the Range</div>";
		}
 else if ($salary2 >= $gets2_1 && $salary2 <= $gets2_2)
		{
		$rec_stat_text = '<div class="label label-primary" style="font-size:12px;">Within Developmental</div>';
		}
 else if ($salary2 >= $gets2_2 && $salary2 <= $gets2_3)
		{
		$rec_stat_text = "<div class='label label-info' style='font-size:12px;'>Within Intermidiate</div>";
		}
 else if ($salary2 >= $gets2_3 && $salary2 <= $gets2_4)
		{
		$rec_stat_text = "<div class='label label-success' style='font-size:12px;'>Within Advanced</div>";
		}
 else if ($salary2 >= $gets2_4 && $salary2 <= $gets2_5)
		{
		$rec_stat_text = "<div class='label label-warning' style='font-size:12px;'>Within Proficient</div>";
		}
		else 
		$rec_stat_text = "<div class='label label-danger' style='font-size:12px;'>Above the Range</div>";
		}
		// professional
else if ($rank == $rank5){
if ($salary2 < $getpro_1){
		$rec_stat_text = "<div class='label label-default' style='font-size:12px;'>Below the Range</div>";
		}
 else if ($salary2 >= $getpro_1 && $salary2 <= $getpro_2)
		{
		$rec_stat_text = '<div class="label label-primary" style="font-size:12px;">Within Developmental</div>';
		}
 else if ($salary2 >= $getpro_2 && $salary2 <= $getpro_3)
		{
		$rec_stat_text = "<div class='label label-info' style='font-size:12px;'>Within Intermidiate</div>";
		}
 else if ($salary2 >= $getpro_3 && $salary2 <= $getpro_4)
		{
		$rec_stat_text = "<div class='label label-success' style='font-size:12px;'>Within Advanced</div>";
		}
 else if ($salary2 >= $getpro_4 && $salary2 <= $getpro_5)
		{
		$rec_stat_text = "<div class='label label-warning' style='font-size:12px;'>Within Proficient</div>";
		}		
		else 
		$rec_stat_text = "<div class='label label-danger' style='font-size:12px;'>Above the Range</div>";
		}
		// section head 1
else if ($rank == $rank6){
if ($salary2 < $getsh1_1){
		$rec_stat_text = "<div class='label label-default' style='font-size:12px;'>Below the Range</div>";
		}
 else if ($salary2 >= $getsh1_1 && $salary2 <= $getsh1_2)
		{
		$rec_stat_text = '<div class="label label-primary" style="font-size:12px;">Within Developmental</div>';
		}
 else if ($salary2 >= $getsh1_2 && $salary2 <= $getsh1_3)
		{
		$rec_stat_text = "<div class='label label-info' style='font-size:12px;'>Within Intermidiate</div>";
		}
 else if ($salary2 >= $getsh1_3 && $salary2 <= $getsh1_4)
		{
		$rec_stat_text = "<div class='label label-success' style='font-size:12px;'>Within Advanced</div>";
		}
 else if ($salary2 >= $getsh1_4 && $salary2 <= $getsh1_5)
		{
		$rec_stat_text = "<div class='label label-warning' style='font-size:12px;'>Within Proficient</div>";
		}
		else 
		$rec_stat_text = "<div class='label label-danger' style='font-size:12px;'>Above the Range</div>";
		}
		// section head 2
else if ($rank == $rank7){
if ($salary2 < $getsh2_1){
		$rec_stat_text = "<div class='label label-default' style='font-size:12px;'>Below the Range</div>";
		}
 else if ($salary2 >= $getsh2_1 && $salary2 <= $getsh2_2)
		{
		$rec_stat_text = '<div class="label label-primary" style="font-size:12px;">Within Developmental</div>';
		}
 else if ($salary2 >= $getsh2_2 && $salary2 <= $getsh2_3)
		{
		$rec_stat_text = "<div class='label label-info' style='font-size:12px;'>Within Intermidiate</div>";
		}
 else if ($salary2 >= $getsh2_3 && $salary2 <= $getsh2_4)
		{
		$rec_stat_text = "<div class='label label-success' style='font-size:12px;'>Within Advanced</div>";
		}
 else if ($salary2 >= $getsh2_4 && $salary2 <= $getsh2_5)
		{
		$rec_stat_text = "<div class='label label-warning' style='font-size:12px;'>Within Proficient</div>";
		}
		else 
		$rec_stat_text = "<div class='label label-danger' style='font-size:12px;'>Above the Range</div>";
		}
		// department head 1
else if ($rank == $rank8){
if ($salary2 < $getdh1_1){
		$rec_stat_text = "<div class='label label-default' style='font-size:12px;'>Below the Range</div>";
		}
 else if ($salary2 >= $getdh1_1 && $salary2 <= $getdh1_2)
		{
		$rec_stat_text = '<div class="label label-primary" style="font-size:12px;">Within Developmental</div>';
		}
 else if ($salary2 >= $getdh1_2 && $salary2 <= $getdh1_3)
		{
		$rec_stat_text = "<div class='label label-info' style='font-size:12px;'>Within Intermidiate</div>";
		}
 else if ($salary2 >= $getdh1_3 && $salary2 <= $getdh1_4)
		{
		$rec_stat_text = "<div class='label label-success' style='font-size:12px;'>Within Advanced</div>";
		}
 else if ($salary2 >= $getdh1_4 && $salary2 <= $getdh1_5)
		{
		$rec_stat_text = "<div class='label label-warning' style='font-size:12px;'>Within Proficient</div>";
		}
		else 
		$rec_stat_text = "<div class='label label-danger' style='font-size:12px;'>Above the Range</div>";
		}
		// department head 2
else if ($rank == $rank9){
if ($salary2 < $getdh2_1){
		$rec_stat_text = "<div class='label label-default' style='font-size:12px;'>Below the Range</div>";
		}
 else if ($salary2 >= $getdh2_1 && $salary2 <= $getdh2_2)
		{
		$rec_stat_text = '<div class="label label-primary" style="font-size:12px;">Within Developmental</div>';
		}
 else if ($salary2 >= $getdh2_2 && $salary2 <= $getdh2_3)
		{
		$rec_stat_text = "<div class='label label-info' style='font-size:12px;'>Within Intermidiate</div>";
		}
 else if ($salary2 >= $getdh2_3 && $salary2 <= $getdh2_4)
		{
		$rec_stat_text = "<div class='label label-success' style='font-size:12px;'>Within Advanced</div>";
		}
 else if ($salary2 >= $getdh2_4 && $salary2 <= $getdh2_5)
		{
		$rec_stat_text = "<div class='label label-warning' style='font-size:12px;'>Within Proficient</div>";
		}
		else 
		$rec_stat_text = "<div class='label label-danger' style='font-size:12px;'>Above the Range</div>";
		}
		
				// Group Head I
else if ($rank == $rank10){
if ($salary2 < $getgh1_1){
		$rec_stat_text = "<div class='label label-default' style='font-size:12px;'>Below the Range</div>";
		}
 else if ($salary2 >= $getgh1_1 && $salary2 <= $getgh1_2)
		{
		$rec_stat_text = '<div class="label label-primary" style="font-size:12px;">Within Developmental</div>';
		}
 else if ($salary2 >= $getgh1_2 && $salary2 <= $getgh1_3)
		{
		$rec_stat_text = "<div class='label label-info' style='font-size:12px;'>Within Intermidiate</div>";
		}
 else if ($salary2 >= $getgh1_3 && $salary2 <= $getgh1_4)
		{
		$rec_stat_text = "<div class='label label-success' style='font-size:12px;'>Within Advanced</div>";
		}
 else if ($salary2 >= $getgh1_4 && $salary2 <= $getgh1_5)
		{
		$rec_stat_text = "<div class='label label-warning' style='font-size:12px;'>Within Proficient</div>";
		}
		else 
		$rec_stat_text = "<div class='label label-danger' style='font-size:12px;'>Above the Range</div>";
		}

				// Group Head II
else if ($rank == $rank11){
if ($salary2 < $getgh2_1){
		$rec_stat_text = "<div class='label label-default' style='font-size:12px;'>Below the Range</div>";
		}
 else if ($salary2 >= $getgh2_1 && $salary2 <= $getgh2_2)
		{
		$rec_stat_text = '<div class="label label-primary" style="font-size:12px;">Within Developmental</div>';
		}
 else if ($salary2 >= $getgh2_2 && $salary2 <= $getgh2_3)
		{
		$rec_stat_text = "<div class='label label-info' style='font-size:12px;'>Within Intermidiate</div>";
		}
 else if ($salary2 >= $getgh2_3 && $salary2 <= $getgh2_4)
		{
		$rec_stat_text = "<div class='label label-success' style='font-size:12px;'>Within Advanced</div>";
		}
 else if ($salary2 >= $getgh2_4 && $salary2 <= $getgh2_5)
		{
		$rec_stat_text = "<div class='label label-warning' style='font-size:12px;'>Within Proficient</div>";
		}
		else 
		$rec_stat_text = "<div class='label label-danger' style='font-size:12px;'>Above the Range</div>";
		}
		
		// Executive I
else if ($rank == $rank12){
if ($salary2 < $getexe_1){
		$rec_stat_text = "<div class='label label-default' style='font-size:12px;'>Below the Range</div>";
		}
 else if ($salary2 >= $getexe_1 && $salary2 <= $getexe_2)
		{
		$rec_stat_text = '<div class="label label-primary" style="font-size:12px;">Within Developmental</div>';
		}
 else if ($salary2 >= $getexe_2 && $salary2 <= $getexe_3)
		{
		$rec_stat_text = "<div class='label label-info' style='font-size:12px;'>Within Intermidiate</div>";
		}
 else if ($salary2 >= $getexe_3 && $salary2 <= $getexe_4)
		{
		$rec_stat_text = "<div class='label label-success' style='font-size:12px;'>Within Advanced</div>";
		}
 else if ($salary2 >= $getexe_4 && $salary2 <= $getexe_5)
		{
		$rec_stat_text = "<div class='label label-warning' style='font-size:12px;'>Within Proficient</div>";
		}
		else 
		$rec_stat_text = "<div class='label label-danger' style='font-size:12px;'>Above the Range</div>";
		}
				// Executive II
else if ($rank == $rank13){
if ($salary2 < $getexe2_1){
		$rec_stat_text = "<div class='label label-default' style='font-size:12px;'>Below the Range</div>";
		}
 else if ($salary2 >= $getexe2_1 && $salary2 <= $getexe2_2)
		{
		$rec_stat_text = '<div class="label label-primary" style="font-size:12px;">Within Developmental</div>';
		}
 else if ($salary2 >= $getexe2_2 && $salary2 <= $getexe2_3)
		{
		$rec_stat_text = "<div class='label label-info' style='font-size:12px;'>Within Intermidiate</div>";
		}
 else if ($salary2 >= $getexe2_3 && $salary2 <= $getexe2_4)
		{
		$rec_stat_text = "<div class='label label-success' style='font-size:12px;'>Within Advanced</div>";
		}
 else if ($salary2 >= $getexe2_4 && $salary2 <= $getexe2_5)
		{
		$rec_stat_text = "<div class='label label-warning' style='font-size:12px;'>Within Proficient</div>";
		}
		else 
		$rec_stat_text = "<div class='label label-danger' style='font-size:12px;'>Above the Range</div>";
		}

				// Executive III
else if ($rank == $rank14){
if ($salary2 < $getexe3_1){
		$rec_stat_text = "<div class='label label-default' style='font-size:12px;'>Below the Range</div>";
		}
 else if ($salary2 >= $getexe3_1 && $salary2 <= $getexe3_2)
		{
		$rec_stat_text = '<div class="label label-primary" style="font-size:12px;">Within Developmental</div>';
		}
 else if ($salary2 >= $getexe3_2 && $salary2 <= $getexe3_3)
		{
		$rec_stat_text = "<div class='label label-info' style='font-size:12px;'>Within Intermidiate</div>";
		}
 else if ($salary2 >= $getexe3_3 && $salary2 <= $getexe3_4)
		{
		$rec_stat_text = "<div class='label label-success' style='font-size:12px;'>Within Advanced</div>";
		}
 else if ($salary2 >= $getexe3_4 && $salary2 <= $getexe3_5)
		{
		$rec_stat_text = "<div class='label label-warning' style='font-size:12px;'>Within Proficient</div>";
		}
		else 
		$rec_stat_text = "<div class='label label-danger' style='font-size:12px;'>Above the Range</div>";
		}
		}

// APPLY RECOMMENDED SALARY
?>
    <div id="dis">
    <!-- here message will be displayed -->
	</div>
<div class="row">
<div class="col-sm-8" style="font-size:18px; color:#0066CC; padding-bottom:20px;"> Update Employee Job Data</div>

 <?php
if ($rec_stat_text == "<div class='label label-danger' style='font-size:12px;'>Above the Range</div>") 
 {
echo '  <div class="col-sm-4">	';
 echo "<span class='blink_me' style='color:red; font-size:20px;'><span class='glyphicon glyphicon-alert'> </span> Call Admin!</span>";
 echo '</div>'; }?>
</div>

	 <form method='post' id='emp-UpdateForm' name='emp-UpdateForm' action="#">
	 <div class="row">
	 <input type='hidden' name='id' value='<?php echo $row['emp_job_id']; ?>' />
	 <input type='hidden' name='recsal' value='<?php echo $rec_salary ?>' />
 <div class="col-sm-4">	 
<b style="font-size:12px; color:grey">Name : </b><?php echo $row2['emp_name'];?></div>
 <div class="col-sm-8">	
<b style="font-size:12px; color:grey"> <?php echo $per_text; ?> </b><?php echo $percat; ?><br /><br></div>
</div>
	 <div class="row">
 <div class="col-sm-4">	 
<b style="font-size:12px; color:grey"> <?php echo $pre_text; ?> </b><?php echo $pre_salary; ?></div>
 <div class="col-sm-4">	
<b style="font-size:12px; color:grey"> <?php echo $rec_text; ?> </b><?php echo $rec_salary; ?></div>
 <div class="col-sm-4">	
 <?php echo $rec_stat_text; ?> <br /><br /></div>
</div>

<div id="square">
<div class="row">



         <!----    <input type='text' name='gender' id="gen" class='form-control' placeholder='' required> ----->
 <div class="col-sm-4">
			 <b>TIN #  </b>
			  <div style="margin-bottom: 10px;" class="input-group">
			  <span class="input-group-addon"><i class="glyphicon glyphicon-folder-open"></i></span>
             <input type='text' name='tin' id="tin" class='form-control bfh-phone' value="<?php echo $row['tin'];?>" placeholder='' maxlength="15" data-format="ddd-ddd-ddd-ddd">
         </div>
		 </div>
		  <div class="col-sm-4">
			 <b>SSS #  </b>
			  <div style="margin-bottom: 10px;" class="input-group">
			  <span class="input-group-addon"><i class="glyphicon glyphicon-folder-open"></i></span>
             <input type='text' name='sss' id="sss" class='form-control bfh-phone' value="<?php echo $row['sss'];?>" data-format="dd-ddddddd-d" placeholder='' maxlength="12" onkeypress='return event.charCode >= 48 && event.charCode <= 57'>
         </div>
		 </div>
		 </div>
		 <div class="row">
  <div class="col-sm-4">
  			 <b>*Job Rank  </b>
			 <div style="margin-bottom: 10px;" class="input-group">
			  <span class="input-group-addon"><i class="glyphicon glyphicon-equalizer"></i></span>
<?php
$name_sql=mysql_query("select rank from job_classification", $connection);
echo "<select name='rank' id='rank' value='' class='form-control'>"; // list box select command
echo "<option value ='".$row3['rank']."' placeholder='Select company name'>".$row3['rank']."</option>";
while ($row5 = mysql_fetch_row($name_sql)) {
			if($row3['rank'] != $row5[0]){
			echo "<option value ='".$row5[0]."'>".$row5[0]."</option>";
}
}?>		
</select>
</div>
</div>		 

	 <div class="col-sm-4">
			 <b>*Section / Department  </b>
			  <div style="margin-bottom: 10px;" class="input-group">
			  <span class="input-group-addon"><i class="glyphicon glyphicon-briefcase"></i></span>
<?php			$dept_sql=mysql_query("select dept from emp_job_data where emp_id=$id", $connection);
				$deptrow = mysql_fetch_assoc($dept_sql);
				$dept = $deptrow['dept'];?>
             <input type='text' name='dept' id="dept" value="<?php echo $deptrow['dept']; ?>" class='form-control'placeholder='' maxlength="20" required>
         </div>
		 </div>
		  <div class="col-sm-4">
			 <b>*Position  </b>
			  <div style="margin-bottom: 10px;" class="input-group">
			  <span class="input-group-addon"><i class="glyphicon glyphicon-signal"></i></span>
             <input type='text' name='position' id="position" value="<?php echo $row['title'];?>" class='form-control' placeholder='' required>
         </div>
		 </div>
		 </div>
		 		  <div class="row">
		   <div class="col-sm-3">
			 <b>*Category  </b>
			  <div style="margin-bottom: 10px;" class="input-group">
			  <span class="input-group-addon"><i class="glyphicon glyphicon-th"></i></span>
			  
			  <?php 
			  if($row['category'] == "Trainee"){ ?>
             <select name='category' id="category" class='form-control' placeholder='' required>			 
			 <option value="<?php echo $row['category'];?>"><?php echo $row['category'];?></option>
			 <option value="Contractual">Contractual</option>
			 <option value="Provisionary">Probationary</option>
			 <option value="Regular">Regular</option>
			 <option value="Project">Project</option>
			 </select>
			 <?php }
			 
			 else if($row['category'] == "Contractual"){ ?>
             <select name='category' id="category" class='form-control' placeholder='' required>			 
			 <option value="<?php echo $row['category'];?>"><?php echo $row['category'];?></option>
			 <option value="Contractual">Trainee</option>
			 <option value="Provisionary">Probationary</option>
			 <option value="Regular">Regular</option>
			 <option value="Project">Project</option>
			 </select>
			 <?php }
			 else if($row['category'] == "Probationary"){ ?>
             <select name='category' id="category" class='form-control' placeholder='' required>			 
			 <option value="<?php echo $row['category'];?>"><?php echo $row['category'];?></option>
			 			 <option value="Provisionary">Trainee</option>
			 			 <option value="Contractual">Contractual</option>
			 <option value="Regular">Regular</option>
			 <option value="Project">Project</option>
			 </select>
			 <?php }
			 else if($row['category'] == "Regular"){ ?>
             <select name='category' id="category" class='form-control' placeholder='' required>			 
			 <option value="<?php echo $row['category'];?>"><?php echo $row['category'];?></option>
			 <option value="Regular">Trainee</option>
			 <option value="Contractual">Contractual</option>
			 <option value="Provisionary">Probationary</option>
			 <option value="Project">Project</option>
			 </select>
			 <?php }
			  else if($row['category'] == "Project"){ ?>
             <select name='category' id="category" class='form-control' placeholder='' required>			 
			 <option value="<?php echo $row['category'];?>"><?php echo $row['category'];?></option>
			 <option value="Project">Trainee</option>
			 <option value="Contractual">Contractual</option>
			 <option value="Provisionary">Probationary</option>
			 <option value="Regular">Regular</option>
			 </select>
			 <?php }?>
         </div>
		 </div>
	
		  <div class="col-sm-3">
             <b>*Date Hired</b>
			  <div style="margin-bottom: 10px;" class="input-group">
			  <span class="input-group-addon"><i class="glyphicon glyphicon-calendar"></i></span>
             <input type='text' tabindex="2" name='bday' id="bday" value="<?php echo $row['hired'];?>" class='form-control' placeholder='Click Here' readonly="true" data-behavior="datepicker" required>  
         </div>
		 </div>
		
		 <div class="col-sm-3">
			 <b>*Current Salary  </b>
			  <div style="margin-bottom: 10px;" class="input-group">
			  <span class="input-group-addon"><b>P</b></span>
             <input type='text' name='salary' id="salary" class='form-control' placeholder='' value="<?php echo $row['current'];?>" runat="server"  onkeyup = "javascript:this.value=Comma(this.value);" maxlength="10" onkeypress='return event.charCode >= 46 && event.charCode <= 57 && event.charCode != 47' required> 
         </div>
		 		 <?php echo $stat_text; ?>         
		 </div>
		 		 <div class="col-sm-3">
			 <b>Allowance  </b>
			  <div style="margin-bottom: 10px;" class="input-group">
			  <span class="input-group-addon"><b>P</b></span>
             <input type='text' name='alw' id="alw" class='form-control' placeholder='' value="<?php echo $row['alw'];?>" runat="server"  onkeyup = "javascript:this.value=Comma(this.value);" maxlength="10" onkeypress='return event.charCode >= 46 && event.charCode <= 57 && event.charCode != 47'> 
         </div>
		 </div>

</div>
		 		 
		 
     </form>    
            <button type="btn-save" class="btn btn-success" name="btn-save" id="btn-save" data-toggle="tooltip" data-placement="right" title="Save Record">
    		<span class="glyphicon glyphicon-floppy-save"></span>
			</button>  
			
		</div>

 <script>  
 
(function() {
		var count1 = parseInt(1, 10);        
        var count2 = parseInt(1, 10);
        var count3 = parseInt(1, 10);
		var count4 = parseInt(1, 10);        
        var count5 = parseInt(1, 10);
        var count6 = parseInt(1, 10);
		var count7 = parseInt(1, 10);        
        var count8 = parseInt(1, 10);
		var count9 = parseInt(1, 10);
        var counttotal = parseInt(0, 10);

$("#alerts").click(function(){
    alert(counttotal+" number of total");
});

counttotal = count1 + count2 + count3 + count4 + count5 + count6 + count7 + count8 + count9;

if (counttotal <= 9){       
            $('#btn-save').attr('disabled', 'disabled');
        } else {
            $('#btn-save').removeAttr('disabled');		
}

<!---- ON READY ------> 
<!---- For Name ------>
		
<!----- For TIN ----->
		$(document).ready(function() {       		 
            if ($('#tin').val().length < 15 && $('#tin').val().length > 0) {
                count2 = 1;
$("#errgen").text("*This is a required field");
$("#tin").css("border","red solid 1px");
$('#btn-save').attr('disabled', 'disabled');
            }
else {
count2=0;
$("#errgen").text("");
$("#tin").css("border","green solid 1px");
}
if (count2 == 1 || count3 == 1 || count4 == 1 || count5 == 1 || count6 == 1 || count7 == 1 || count8 == 1 || count9 == 1 ){       
            $('#btn-save').attr('disabled', 'disabled');
        } else {
            $('#btn-save').removeAttr('disabled');}

})

<!----- For SSS ----->
		$(document).ready(function() {       		 
            if ($('#sss').val().length < 11 && $('#sss').val().length > 0) {
                count3 = 1;
$("#errage").text("*This is a required field");
$("#sss").css("border","red solid 1px");
$('#btn-save').attr('disabled', 'disabled');
            }
else {
count3=0;
$("#errage").text("");
$("#sss").css("border","green solid 1px");
}
if (count2 == 1 || count3 == 1 || count4 == 1 || count5 == 1 || count6 == 1 || count7 == 1 || count8 == 1 || count9 == 1 ){       
            $('#btn-save').attr('disabled', 'disabled');
        } else {
            $('#btn-save').removeAttr('disabled');}

})

<!----- For Birthday ----->
if ($.fn.datepicker) {
    $('.datepicker').datepicker();}
		$(document).ready(function() {       		 
            if ($('#bday').val() == '') {
                count4 = 1;
$("#errbday").text("*This is a required field");
$("#bday").css("border","red solid 1px");
$('#btn-save').attr('disabled', 'disabled');
            }
else {
count4=0;
	
$("#errbday").text("");
$("#bday").css("border","green solid 1px");
}
if (count2 == 1 || count3 == 1 || count4 == 1 || count5 == 1 || count6 == 1 || count7 == 1 || count8 == 1 || count9 == 1 ){       
            $('#btn-save').attr('disabled', 'disabled');
        } else {
            $('#btn-save').removeAttr('disabled');}

})

<!----- For Contact Number ----->
		$(document).ready(function() {       		 
            if ($('#rank').val() == '') {
                count5 = 1;
$("#errnum").text("*This is a required field");
$("#rank").css("border","red solid 1px");
$('#btn-save').attr('disabled', 'disabled');
            }
else {
count5=0;
$("#errnum").text("");
$("#rank").css("border","green solid 1px");
}
if (count2 == 1 || count3 == 1 || count4 == 1 || count5 == 1 || count6 == 1 || count7 == 1 || count8 == 1 || count9 == 1 ){       
            $('#btn-save').attr('disabled', 'disabled');
        } else {
            $('#btn-save').removeAttr('disabled');}

})
		$(document).ready(function() {       		 
            if ($('#dept').val() == '') {
                count9 = 1;
$("#errnum").text("*This is a required field");
$("#dept").css("border","red solid 1px");
$('#btn-save').attr('disabled', 'disabled');
            }
else {
count9=0;
$("#errnum").text("");
$("#dept").css("border","green solid 1px");
}

if (count1 == 1 || count2 == 1 || count3 == 1 || count4 == 1 || count5 == 1 || count6 == 1 || count7 == 1 || count8 == 1 || count9 == 1){       
            $('#btn-save').attr('disabled', 'disabled');
        } else {
            $('#btn-save').removeAttr('disabled');}

})

						
		$(document).ready(function() {       		 
            if ($('#position').val() == '') {
                count6 = 1;
$("#errnum").text("*This is a required field");
$("#position").css("border","red solid 1px");
$('#btn-save').attr('disabled', 'disabled');
            }
else {
count6=0;
$("#errnum").text("");
$("#position").css("border","green solid 1px");
}

if (count2 == 1 || count3 == 1 || count4 == 1 || count5 == 1 || count6 == 1 || count7 == 1 || count8 == 1 || count9 == 1 ){       
            $('#btn-save').attr('disabled', 'disabled');
        } else {
            $('#btn-save').removeAttr('disabled');}

})

<!----- For Address ----->
		$(document).ready(function() {       		 
            if ($('#category').val() == '') {
                count7 = 1;
$("#erradd").text("*This is a required field");
$("#category").css("border","red solid 1px");
$('#btn-save').attr('disabled', 'disabled');
            }
else {
count7=0;
$("#erradd").text("");
$("#category").css("border","green solid 1px");
}
if (count2 == 1 || count3 == 1 || count4 == 1 || count5 == 1 || count6 == 1 || count7 == 1 || count8 == 1 || count9 == 1 ){       
            $('#btn-save').attr('disabled', 'disabled');
        } else {
            $('#btn-save').removeAttr('disabled');}

})

<!----- For Status ----->
		$(document).ready(function() {       		 
            if ($('#salary').val() == '') {
                count8 = 1;
$("#errstat").text("*This is a required field");
$("#salary").css("border","red solid 1px");
$('#btn-save').attr('disabled', 'disabled');
            }
else {
count8=0;
$("#errstat").text("");
$("#salary").css("border","green solid 1px");
}
if (count2 == 1 || count3 == 1 || count4 == 1 || count5 == 1 || count6 == 1 || count7 == 1 || count8 == 1 || count9 == 1 ){       
            $('#btn-save').attr('disabled', 'disabled');
        } else {
            $('#btn-save').removeAttr('disabled');}

})

<!---- For Name ------>
    
<!----- For TIN ----->
    $('#tin').keyup(function() {       		 
            if ($('#tin').val().length < 15 && $('#tin').val().length > 0) {
                count2 = 1;
$("#errgen").text("*This is a required field");
$("#tin").css("border","red solid 1px");
$('#btn-save').attr('disabled', 'disabled');
            }
else {
count2=0;
$("#errgen").text("");
$("#tin").css("border","green solid 1px");
}
if (count2 == 1 || count3 == 1 || count4 == 1 || count5 == 1 || count6 == 1 || count7 == 1 || count8 == 1 || count9 == 1 ){       
            $('#btn-save').attr('disabled', 'disabled');
        } else {
            $('#btn-save').removeAttr('disabled');}

})

<!----- For SSS ----->
    $('#sss').keyup(function() {       		 
            if ($('#sss').val().length < 12 && $('#sss').val().length > 0) {
                count3 = 1;
$("#errage").text("*This is a required field");
$("#sss").css("border","red solid 1px");
$('#btn-save').attr('disabled', 'disabled');
            }
else {
count3=0;
$("#errage").text("");
$("#sss").css("border","green solid 1px");
}
if (count2 == 1 || count3 == 1 || count4 == 1 || count5 == 1 || count6 == 1 || count7 == 1 || count8 == 1 || count9 == 1 ){       
            $('#btn-save').attr('disabled', 'disabled');
        } else {
            $('#btn-save').removeAttr('disabled');}

})

<!----- For Birthday ----->
if ($.fn.datepicker) {
    $('.datepicker').datepicker();}
    $('#bday').change(function() {     
            if ($('#bday').val() == '') {
                count4 = 1;
$("#errbday").text("*This is a required field");
$("#bday").css("border","red solid 1px");
$('#btn-save').attr('disabled', 'disabled');
            }
else {
count4=0;
	
$("#errbday").text("");
$("#bday").css("border","green solid 1px");
}
if (count2 == 1 || count3 == 1 || count4 == 1 || count5 == 1 || count6 == 1 || count7 == 1 || count8 == 1 || count9 == 1 ){       
            $('#btn-save').attr('disabled', 'disabled');
        } else {
            $('#btn-save').removeAttr('disabled');}

})

<!----- For Contact Number ----->
    $('#rank').change(function() {       		 
            if ($('#rank').val() == '') {
                count5 = 1;
$("#errnum").text("*This is a required field");
$("#rank").css("border","red solid 1px");
$('#btn-save').attr('disabled', 'disabled');
            }
else {
count5=0;
$("#errnum").text("");
$("#rank").css("border","green solid 1px");
}
if (count2 == 1 || count3 == 1 || count4 == 1 || count5 == 1 || count6 == 1 || count7 == 1 || count8 == 1 || count9 == 1 ){       
            $('#btn-save').attr('disabled', 'disabled');
        } else {
            $('#btn-save').removeAttr('disabled');}

})

    $('#dept').keyup(function() {       		 
            if ($('#dept').val() == '') {
                count9 = 1;
$("#errnum").text("*This is a required field");
$("#dept").css("border","red solid 1px");
$('#btn-save').attr('disabled', 'disabled');
            }
else {
count9=0;
$("#errnum").text("");
$("#dept").css("border","green solid 1px");
}

if (count2 == 1 || count3 == 1 || count4 == 1 || count5 == 1 || count6 == 1 || count7 == 1 || count8 == 1 || count9 == 1){       
            $('#btn-save').attr('disabled', 'disabled');
        } else {
            $('#btn-save').removeAttr('disabled');}

})

						
    $('#position').keyup(function() {       		 
            if ($('#position').val() == '') {
                count6 = 1;
$("#errnum").text("*This is a required field");
$("#position").css("border","red solid 1px");
$('#btn-save').attr('disabled', 'disabled');
            }
else {
count6=0;
$("#errnum").text("");
$("#position").css("border","green solid 1px");
}

if (count2 == 1 || count3 == 1 || count4 == 1 || count5 == 1 || count6 == 1 || count7 == 1 || count8 == 1 || count9 == 1 ){       
            $('#btn-save').attr('disabled', 'disabled');
        } else {
            $('#btn-save').removeAttr('disabled');}

})

<!----- For Address ----->
    $('#category').change(function() {       		 
            if ($('#category').val() == '') {
                count7 = 1;
$("#erradd").text("*This is a required field");
$("#category").css("border","red solid 1px");
$('#btn-save').attr('disabled', 'disabled');
            }
else {
count7=0;
$("#erradd").text("");
$("#category").css("border","green solid 1px");
}
if (count2 == 1 || count3 == 1 || count4 == 1 || count5 == 1 || count6 == 1 || count7 == 1 || count8 == 1 || count9 == 1 ){       
            $('#btn-save').attr('disabled', 'disabled');
        } else {
            $('#btn-save').removeAttr('disabled');}

})

<!----- For Status ----->
    $('#salary').keyup(function() {       		 
            if ($('#salary').val() == '') {
                count8 = 1;
$("#errstat").text("*This is a required field");
$("#salary").css("border","red solid 1px");
$('#btn-save').attr('disabled', 'disabled');
            }
else {
count8=0;
$("#errstat").text("");
$("#salary").css("border","green solid 1px");
}
if (count2 == 1 || count3 == 1 || count4 == 1 || count5 == 1 || count6 == 1 || count7 == 1 || count8 == 1 || count9 == 1 ){       
            $('#btn-save').attr('disabled', 'disabled');
        } else {
            $('#btn-save').removeAttr('disabled');}

})
/*
	$('#length').keyup(function() {
        var text_length = parseInt($('#length').val().length, 10);
if ($('#length').val() == '' || text_length <= 29){
count3 = 1;
$("#errmess").text("*This is a required field with a minimum of 30 characters");
$("#length").css("border","red solid 1px");
$('# btn-save').attr('disabled', 'disabled');
}
else {
count3=0;
$("#errmess").text("");
$("#length").css("border","red solid 0px");
}	 
if (count1 == 1 || count2 == 1 || count3 == 1 || count4 == 1 || count5 == 1 || count6 == 1 || count7 == 1 || count8 == 1 || count9 == 1 ){       
            $('# btn-save').attr('disabled', 'disabled');
        } else {
            $('# btn-save').removeAttr('disabled');}

})
*/
})()


</script>
    