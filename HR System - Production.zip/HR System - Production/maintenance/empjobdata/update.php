<?php
require_once '../../assets/dbconfig.php';
require_once '../../assets/connection.php';

	
	if($_POST)
	{	$id = $_POST['id'];	
		$tin = $_POST['tin'];
		$sss = $_POST['sss'];
		$rank= $_POST['rank'];
		$dept = $_POST['dept'];
		$position = $_POST['position'];
		$category = $_POST['category'];
		$hired= $_POST['bday'];
		$salary = $_POST['salary'];
		$alw = $_POST['alw'];
		
$name_sql2=mysql_query("select job_id from job_classification where rank='$rank'", $connection);
$row2 = mysql_fetch_assoc($name_sql2);
$rank_id =$row2['job_id'];
$name_sql3=mysql_query("select emp_id from emp_job_data where emp_job_id='$id'", $connection);
$row3 = mysql_fetch_assoc($name_sql3);
$getid =$row3['emp_id'];
$name_sql=mysql_query("select emp_name from emp_personal_data where emp_id='$getid'", $connection);
$row = mysql_fetch_assoc($name_sql);
$fullname =$row['emp_name'];

$old_rankid_sql=mysql_query("select job_id from emp_job_data where emp_id='$getid'", $connection);
$old_rankid_row = mysql_fetch_assoc($old_rankid_sql);
$old_rankid =$old_rankid_row['job_id'];

$old_rank_sql=mysql_query("select rank from job_classification where job_id='$old_rankid'", $connection);
$old_rank_row = mysql_fetch_assoc($old_rank_sql);
$old_rank =$old_rank_row['rank'];

$old_dept_sql=mysql_query("select dept from emp_job_data where emp_id='$getid'", $connection);
$old_dept_row = mysql_fetch_assoc($old_dept_sql);
$old_dept =$old_dept_row['dept'];

$old_pos_sql=mysql_query("select title from emp_job_data where emp_id='$getid'", $connection);
$old_pos_row = mysql_fetch_assoc($old_pos_sql);
$old_position =$old_pos_row['title'];

$old_cat_sql=mysql_query("select category from emp_job_data where emp_id='$getid'", $connection);
$old_cat_row = mysql_fetch_assoc($old_cat_sql);
$old_status =$old_cat_row['category'];

$old_sal_sql=mysql_query("select current from emp_job_data where emp_id='$getid'", $connection);
$old_sal_row = mysql_fetch_assoc($old_sal_sql);
$old_salary =$old_sal_row['current'];

$rec_sal_sql=mysql_query("select rec_salary from emp_job_data where emp_id='$getid'", $connection);
$rec_sal_row = mysql_fetch_assoc($rec_sal_sql);
$rec_salary = $rec_sal_row['rec_salary'];

$pre_sal_sql=mysql_query("select pre_salary from emp_job_data where emp_id='$getid'", $connection);
$pre_sal_row = mysql_fetch_assoc($pre_sal_sql);
$pre_salary=$pre_sal_row['pre_salary'];

$alw_sal_sql=mysql_query("select alw from emp_job_data where emp_id='$getid'", $connection);
$alw_sal_row = mysql_fetch_assoc($alw_sal_sql);
$old_alw=$alw_sal_row['alw'];

$date_sal_pre = 0;
if($salary != $old_salary){
$pre_salary = $old_salary;
$date_sal_pre = 1;
}
else{
$date_sal_pre = 0;}

if($salary != $rec_salary){
$rec_salary=$rec_sal_row['rec_salary'];

}
else{
$rec_salary = "";
}

$changes = 0;
if ($rank != $old_rank || $dept != $old_dept || $position != $old_position || $category != $old_status || $salary != $old_salary || $alw != $old_alw){
			    $changes = 1;
} else {
    $changes = 0;
}
		
		
			$stmt = $db_con->prepare("UPDATE emp_job_data SET tin=:tin, sss=:sss, job_id=:jid ,dept=:dep, title=:tle, category=:cat, hired=:hed, current=:cur, pre_salary=:pre, rec_salary=:rec, alw=:alw  WHERE emp_job_id=:id");
			$stmt->bindParam(":id", $id);
			$stmt->bindParam(":tin", $tin);
			$stmt->bindParam(":sss", $sss);
			$stmt->bindParam(":jid", $rank_id);
			$stmt->bindParam(":dep", $dept);
			$stmt->bindParam(":tle", $position);
			$stmt->bindParam(":cat", $category);
			$stmt->bindParam(":hed", $hired);
			$stmt->bindParam(":pre", $pre_salary);
			$stmt->bindParam(":rec", $rec_salary);
			$stmt->bindParam(":cur", $salary);
			$stmt->bindParam(":alw", $alw);

		
		if($stmt->execute())
		{					if ($changes == 1){
			$ern = mysql_query("INSERT INTO ern_data (emp_id, old_rank, new_rank, old_dept, new_dept, old_pos, new_pos, old_status, new_status, old_salary, new_salary,old_alw, new_alw, status) VALUES ('$getid', '$old_rank', '$rank', '$old_dept', '$dept', '$old_position', '$position', '$old_status', '$category', '$old_salary', '$salary', '$old_alw', '$alw', 'undone')", $connection);
		}
		$adj_date = date("Y-m-d");
		if ($date_sal_pre == 1){
			$analysis = mysql_query("UPDATE emp_job_data SET adj_salary_pre='$adj_date' WHERE emp_id LIKE '$getid'", $connection);
		}
			echo "Updating...";
			$trail = mysql_query("INSERT INTO trail (type, per_action, description, emp_id) VALUES ('Employee Job Data', 'UPDATED', 'Data of $fullname', '$user_check')", $connection);		}
		else{
			echo "Query Problem";
		}
	}

?>