	    <link href="../../bootstrap/css/bootstrap-datepicker.css" rel="stylesheet" type="text/css"/>
		<script src="../../bootstrap/js/bootstrap-datepicker.min.js"></script>
		<script src="../../assets/bootstrap-formhelpers-phone.js"></script>
		
<script>
/*window.onbeforeunload = function (evt) {
   if(window.nounloadcheck == true) return; // ignore
  var message = 'Changes you saved may not be saved.';
  if (typeof evt == 'undefined') {
  evt = window.event;
  }
  if (evt) {
  evt.returnValue = message;
  }
  return message;
  }
*/

 $(document).ready(function(){
$('input[name="bday"]').datepicker({
		format: "mm/dd/yyyy",
		startView: 'month'    
		})
        });
		
		$(document).ready(function(){
    $('[data-toggle="tooltip"]').tooltip();   
});

		</script>

<style type="text/css">
#dis{
	display: none;
	margin-left: 70px;
	position: fixed;
	top: 50px;
	width: 68%;
	padding:20px;
	z-index:99999;
}
  .loader {
	position: fixed;
	left: 0px;
	top: 0px;
	width: 100%;
	height: 100%;
	z-index: 9999;
	background: url('../../img/loading.gif') 50% 50% no-repeat rgb(249,249,249);
	opacity: .5;
}

#square {
background-color: #ECECFF;
-webkit-box-shadow: 0px 0px 2px rgba(50, 50, 50, 0.31);
    -moz-box-shadow:    0px 0px 5px rgba(50, 50, 50, 0.31);
    box-shadow:         0px 0px 10px rgba(50, 50, 50, 0.31);
padding:20px;
}
.add {
border-radius: 100%;
padding-top:15px;
padding-bottom: 17px;
padding-left: 15px;
padding-right: 17px;
font-size:24px;		
}
.add:focus{
outline: 0px;
}
.btn {
border-radius: 100%;
padding-top:25px;
padding-bottom: 25px;
padding-left: 25px;
padding-right: 25px;
font-size:36px;
			    -webkit-box-shadow: 0px 0px 10px rgba(50, 50, 50, 20);
    -moz-box-shadow:    0px 0px 10px rgba(50, 50, 50, 20);
    box-shadow:         0px 0px 10px rgba(50, 50, 50, 20);
}
.btn:focus{
outline: 0px;
}
  @media only screen and (max-width: 768px) 
{ 
#dis{
	top: 75px;
	margin-left: 0;
	width:70%
}

</style>
    <div id="dis">
    <!-- here message will be displayed -->
	</div>
	<script>
	function Comma(Num) { //function to add commas to textboxes
        Num += '';
        Num = Num.replace(',', ''); Num = Num.replace(',', ''); Num = Num.replace(',', '');
        Num = Num.replace(',', ''); Num = Num.replace(',', ''); Num = Num.replace(',', '');
        x = Num.split('.');
        x1 = x[0];
        x2 = x.length > 1 ? '.' + x[1] : '';
        var rgx = /(\d+)(\d{3})/;
        while (rgx.test(x1))
            x1 = x1.replace(rgx, '$1' + ',' + '$2');
        return x1 + x2;
    }
	

	
</script>

<div class="title"> Employee Job Data Form </div>
	 <form method='post' id='emp-SaveForm' action="#">
 
<div id="square">
<div class="row">

                  <div class="col-sm-6">
              <b>*Full Name</b>
			  			  <div style="margin-bottom: 10px;" class="input-group">
			  <span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span>

<?php
require_once '../../assets/connection.php';

$name2_sql=mysql_query("SELECT emp_personal_data.emp_name FROM emp_personal_data WHERE emp_id NOT IN (SELECT emp_id FROM emp_job_data) AND emp_status != 'inactive'", $connection);

echo "<select name='names' id='names' value='' class='form-control'>"; // list box select command
echo "<option value ='' placeholder='Select company name'> </option>";
while ($row2 = mysql_fetch_row($name2_sql)) {
			echo "<option value ='".$row2[0]."'>".$row2[0]."</option>";

}
?>
</select>
</div>
</div>

         <!----    <input type='text' name='gender' id="gen" class='form-control' placeholder='' required> ----->
 <div class="col-sm-3">
			 <b>TIN #  </b>
			  <div style="margin-bottom: 10px;" class="input-group">
			  <span class="input-group-addon"><i class="glyphicon glyphicon-folder-open"></i></span>
             <input type='text' name='tin' id="tin" class='form-control bfh-phone' placeholder='' maxlength="15" data-format="ddd-ddd-ddd-ddd">
         </div>
		 </div>
		  <div class="col-sm-3">
			 <b>SSS #  </b>
			  <div style="margin-bottom: 10px;" class="input-group">
			  <span class="input-group-addon"><i class="glyphicon glyphicon-folder-open"></i></span>
             <input type='text' name='sss' id="sss" class='form-control bfh-phone' data-format="dd-ddddddd-d" placeholder='' maxlength="12" onkeypress='return event.charCode >= 48 && event.charCode <= 57'>
         </div>
		 </div>
		 
</div>
<div class="row">
  <div class="col-sm-4">
  			 <b>*Job Rank  </b>
			  <div style="margin-bottom: 10px;" class="input-group">
			  <span class="input-group-addon"><i class="glyphicon glyphicon-equalizer"></i></span>
<?php

$name_sql=mysql_query("select rank from job_classification", $connection);
echo "<select name='rank' id='rank' value='' class='form-control'>"; // list box select command
echo "<option value ='' placeholder='Select company name'> </option>";
while ($row = mysql_fetch_row($name_sql)) {
			echo "<option value ='".$row[0]."'>".$row[0]."</option>";

}?>		
</select>
</div>
</div>
	 <div class="col-sm-4">
			 <b>*Section / Department  </b>
			  <div style="margin-bottom: 10px;" class="input-group">
			  <span class="input-group-addon"><i class="glyphicon glyphicon-briefcase"></i></span>
             <input type='text' name='dept' id="dept" class='form-control'placeholder='' maxlength="20" required>
         </div>
		 </div>
		 
		  <div class="col-sm-4">
			 <b>*Position  </b>
			  <div style="margin-bottom: 10px;" class="input-group">
			  <span class="input-group-addon"><i class="glyphicon glyphicon-signal"></i></span>
             <input type='text' name='position' id="position" class='form-control' placeholder='' required>
         </div>
		 </div>
		 </div>
			  <div class="row">
			    <div class="col-sm-3">
			 <b>*Category  </b>
			  <div style="margin-bottom: 10px;" class="input-group">
			  <span class="input-group-addon"><i class="glyphicon glyphicon-th"></i></span>
             <select name='category' id="category" class='form-control' placeholder='' required>
			 <option value=""></option>
			 <option value="Trainee">Trainee</option>
			 <option value="Contractual">Contractual</option>
			 <option value="Probationary">Probationary</option>
			 <option value="Regular">Regular</option>
			 <option value="Project">Project</option>
			 </select>
         </div>
		 </div>
		  <div class="col-sm-3">
             <b>*Date Hired</b>
			  <div style="margin-bottom: 10px;" class="input-group">
			  <span class="input-group-addon"><i class="glyphicon glyphicon-calendar"></i></span>
             <input type='text' tabindex="2" name='bday' id="bday" class='form-control' placeholder='Click Here' readonly="true" data-behavior="datepicker" required>  
         </div>
		 </div>
		
		 <div class="col-sm-3">
			 <b>*Current Salary  </b>
			  <div style="margin-bottom: 10px;" class="input-group">
			  <span class="input-group-addon"><b>P</b></span>
             <input type='text' name='salary' id="salary" class='form-control' placeholder='' runat="server" maxlength="10" onkeypress='return event.charCode >= 46 && event.charCode <= 57 && event.charCode != 47'  onkeyup = "javascript:this.value=Comma(this.value);" required>
         </div>
		 </div>
		 
		 <div class="col-sm-3">
			 <b>Allowance  </b>
			  <div style="margin-bottom: 10px;" class="input-group">
			  <span class="input-group-addon"><b>P</b></span>
             <input type='text' name='alw' id="alw" class='form-control' placeholder='' runat="server" maxlength="10" onkeypress='return event.charCode >= 46 && event.charCode <= 57 && event.charCode != 47'  onkeyup = "javascript:this.value=Comma(this.value);">
         </div>
		 </div>
		 
</div>
         
		 
     </form>    
            <button type="btn-save" class="btn btn-success" name="btn-save" id="btn-save" data-toggle="tooltip" data-placement="right" title="Save Record">
    		<span class="glyphicon glyphicon-floppy-save"></span>
			</button>  
			
		</div>


 <script>  
(function() {
		var count1 = parseInt(1, 10);        
        var count2 = parseInt(1, 10);
        var count3 = parseInt(1, 10);
		var count4 = parseInt(1, 10);        
        var count5 = parseInt(1, 10);
        var count6 = parseInt(1, 10);
		var count7 = parseInt(1, 10);        
        var count8 = parseInt(1, 10);
		var count9 = parseInt(1, 10);
        var counttotal = parseInt(0, 10);

$("#alerts").click(function(){
    alert(counttotal+" number of total");
});

counttotal = count1 + count2 + count3 + count4 + count5 + count6 + count7 + count8 + count9;

if (counttotal <= 9){       
            $('#btn-save').attr('disabled', 'disabled');
        } else {
            $('#btn-save').removeAttr('disabled');		
}

 
 <!----- For TIN ----->
    $(document).ready(function() {       		 
            if ($('#tin').val().length < 15 && $('#tin').val().length > 0) {
                count2 = 1;
$("#errgen").text("*This is a required field");
$("#tin").css("border","red solid 1px");
$('#btn-save').attr('disabled', 'disabled');
            }
else {
count2=0;
$("#errgen").text("");
}
if (count1 == 1 || count2 == 1 || count3 == 1 || count4 == 1 || count5 == 1 || count6 == 1 || count7 == 1 || count8 == 1 || count9 == 1 ){       
            $('#btn-save').attr('disabled', 'disabled');
        } else {
            $('#btn-save').removeAttr('disabled');}

})

<!----- For SSS ----->
    $(document).ready(function() {       		 
            if ($('#sss').val().length < 15 && $('#sss').val().length > 0) {
                count3 = 1;
$("#errage").text("*This is a required field");
$("#sss").css("border","red solid 1px");
$('#btn-save').attr('disabled', 'disabled');
            }
else {
count3=0;
$("#errage").text("");
}
if (count1 == 1 || count2 == 1 || count3 == 1 || count4 == 1 || count5 == 1 || count6 == 1 || count7 == 1 || count8 == 1 || count9 == 1 ){       
            $('#btn-save').attr('disabled', 'disabled');
        } else {
            $('#btn-save').removeAttr('disabled');}

})

<!---- For Name ------>
    $('#names').change(function() {       		 
            if ($('#names').val() == '') {
                count1 = 1;
$("#errname").text("*This is a required field");
$("#names").css("border","red solid 1px");
$('#btn-save').attr('disabled', 'disabled');
            }
else {
count1=0;
$("#errname").text("");
$("#names").css("border","green solid 1px");
}
if (count1 == 1 || count2 == 1 || count3 == 1 || count4 == 1 || count5 == 1 || count6 == 1 || count7 == 1 || count8 == 1 || count9 == 1 ){       
            $('#btn-save').attr('disabled', 'disabled');
        } else {
            $('#btn-save').removeAttr('disabled');}

})
<!----- For TIN ----->
    $('#tin').keyup(function() {       		 
            if ($('#tin').val().length < 15 && $('#tin').val().length > 0) {
                count2 = 1;
$("#errgen").text("*This is a required field");
$("#tin").css("border","red solid 1px");
$('#btn-save').attr('disabled', 'disabled');
            }
else {
count2=0;
$("#errgen").text("");
$("#tin").css("border","green solid 1px");
}
if (count1 == 1 || count2 == 1 || count3 == 1 || count4 == 1 || count5 == 1 || count6 == 1 || count7 == 1 || count8 == 1 || count9 == 1 ){       
            $('#btn-save').attr('disabled', 'disabled');
        } else {
            $('#btn-save').removeAttr('disabled');}

})

<!----- For SSS ----->
    $('#sss').keyup(function() {       		 
            if ($('#sss').val().length < 12 && $('#sss').val().length > 0) {
                count3 = 1;
$("#errage").text("*This is a required field");
$("#sss").css("border","red solid 1px");
$('#btn-save').attr('disabled', 'disabled');
            }
else {
count3=0;
$("#errage").text("");
$("#sss").css("border","green solid 1px");
}
if (count1 == 1 || count2 == 1 || count3 == 1 || count4 == 1 || count5 == 1 || count6 == 1 || count7 == 1 || count8 == 1 || count9 == 1 ){       
            $('#btn-save').attr('disabled', 'disabled');
        } else {
            $('#btn-save').removeAttr('disabled');}

})

<!----- For Birthday ----->
if ($.fn.datepicker) {
    $('.datepicker').datepicker();}
    $('#bday').change(function() {     
            if ($('#bday').val() == '') {
                count4 = 1;
$("#errbday").text("*This is a required field");
$("#bday").css("border","red solid 1px");
$('#btn-save').attr('disabled', 'disabled');
            }
else {
count4=0;
	
$("#errbday").text("");
$("#bday").css("border","green solid 1px");
}
if (count1 == 1 || count2 == 1 || count3 == 1 || count4 == 1 || count5 == 1 || count6 == 1 || count7 == 1 || count8 == 1 || count9 == 1 ){       
            $('#btn-save').attr('disabled', 'disabled');
        } else {
            $('#btn-save').removeAttr('disabled');}

})

<!----- For Rank ----->
    $('#rank').change(function() {       		 
            if ($('#rank').val() == '') {
                count5 = 1;
$("#errnum").text("*This is a required field");
$("#rank").css("border","red solid 1px");
$('#btn-save').attr('disabled', 'disabled');
            }
else {
count5=0;
$("#errnum").text("");
$("#rank").css("border","green solid 1px");
}
if (count1 == 1 || count2 == 1 || count3 == 1 || count4 == 1 || count5 == 1 || count6 == 1 || count7 == 1 || count8 == 1 || count9 == 1 ){       
            $('#btn-save').attr('disabled', 'disabled');
        } else {
            $('#btn-save').removeAttr('disabled');}

})
    $('#dept').keyup(function() {       		 
            if ($('#dept').val() == '') {
                count9 = 1;
$("#errnum").text("*This is a required field");
$("#dept").css("border","red solid 1px");
$('#btn-save').attr('disabled', 'disabled');
            }
else {
count9=0;
$("#errnum").text("");
$("#dept").css("border","green solid 1px");
}

if (count1 == 1 || count2 == 1 || count3 == 1 || count4 == 1 || count5 == 1 || count6 == 1 || count7 == 1 || count8 == 1 || count9 == 1 ){       
            $('#btn-save').attr('disabled', 'disabled');
        } else {
            $('#btn-save').removeAttr('disabled');}

})

						
    $('#position').keyup(function() {       		 
            if ($('#position').val() == '') {
                count6 = 1;
$("#errnum").text("*This is a required field");
$("#position").css("border","red solid 1px");
$('#btn-save').attr('disabled', 'disabled');
            }
else {
count6=0;
$("#errnum").text("");
$("#position").css("border","green solid 1px");
}

if (count1 == 1 || count2 == 1 || count3 == 1 || count4 == 1 || count5 == 1 || count6 == 1 || count7 == 1 || count8 == 1 || count9 == 1 ){       
            $('#btn-save').attr('disabled', 'disabled');
        } else {
            $('#btn-save').removeAttr('disabled');}

})

<!----- For Address ----->
    $('#category').change(function() {       		 
            if ($('#category').val() == '') {
                count7 = 1;
$("#erradd").text("*This is a required field");
$("#category").css("border","red solid 1px");
$('#btn-save').attr('disabled', 'disabled');
            }
else {
count7=0;
$("#erradd").text("");
$("#category").css("border","green solid 1px");
}
if (count1 == 1 || count2 == 1 || count3 == 1 || count4 == 1 || count5 == 1 || count6 == 1 || count7 == 1 || count8 == 1 || count9 == 1 ){       
            $('#btn-save').attr('disabled', 'disabled');
        } else {
            $('#btn-save').removeAttr('disabled');}

})

<!----- For Status ----->
    $('#salary').keyup(function() {       		 
            if ($('#salary').val() == '') {
                count8 = 1;
$("#errstat").text("*This is a required field");
$("#salary").css("border","red solid 1px");
$('#btn-save').attr('disabled', 'disabled');
            }
else {
count8=0;
$("#errstat").text("");
$("#salary").css("border","green solid 1px");
}
if (count1 == 1 || count2 == 1 || count3 == 1 || count4 == 1 || count5 == 1 || count6 == 1 || count7 == 1 || count8 == 1 || count9 == 1 ){       
            $('#btn-save').attr('disabled', 'disabled');
        } else {
            $('#btn-save').removeAttr('disabled');}

})
/*
	$('#length').keyup(function() {
        var text_length = parseInt($('#length').val().length, 10);
if ($('#length').val() == '' || text_length <= 29){
count3 = 1;
$("#errmess").text("*This is a required field with a minimum of 30 characters");
$("#length").css("border","red solid 1px");
$('# btn-save').attr('disabled', 'disabled');
}
else {
count3=0;
$("#errmess").text("");
$("#length").css("border","red solid 0px");
}	 
if (count1 == 1 || count2 == 1 || count3 == 1 || count4 == 1 || count5 == 1 || count6 == 1 || count7 == 1 || count8 == 1 || count9 == 1 ){       
            $('# btn-save').attr('disabled', 'disabled');
        } else {
            $('# btn-save').removeAttr('disabled');}

})
*/
})()


</script>
    