<?php
require_once '../../assets/dbconfig.php';
require_once '../../assets/connection.php';

	
	if($_POST)
	{	$id = $_POST['id'];	
		//
$name_sql3=mysql_query("select emp_id from emp_job_data where emp_job_id='$id'", $connection);
$row3 = mysql_fetch_assoc($name_sql3);
$getid =$row3['emp_id'];
$name_sql=mysql_query("select emp_name from emp_personal_data where emp_id='$getid'", $connection);
$row = mysql_fetch_assoc($name_sql);
$getname =$row['emp_name'];
//
		$recsal = $_POST['recsal'];
		$salary = $_POST['salary'];
		$recno = "";
		
			$stmt = $db_con->prepare("UPDATE emp_job_data SET pre_salary=:cur, current=:rec, rec_salary=:no  WHERE emp_job_id=:id");
			$stmt->bindParam(":id", $id);
			$stmt->bindParam(":cur", $salary);
			$stmt->bindParam(":rec", $recsal);
			$stmt->bindParam(":no", $recno);

		
		if($stmt->execute())
		{
			echo "Recommended Salary Applied";
			$trail = mysql_query("INSERT INTO trail (type, per_action, description, emp_id) VALUES ('Employee Job Data', 'SALARY APPLIED', 'Php $recsal New Salary for $getname', '$user_check')", $connection);
		}
		else{
			echo "Query Problem";
		}
	}

?>