<?php
require_once '../../assets/dbconfig.php';
require_once '../../assets/connection.php';

	if($_POST)
	{	
		$names = $_POST['names'];
		$tin = $_POST['tin'];
		$sss = $_POST['sss'];
		$rank= $_POST['rank'];
		$dept = $_POST['dept'];
		$position = $_POST['position'];
		$category = $_POST['category'];
		$hired= $_POST['bday'];
		$salary = $_POST['salary'];
		$alw = $_POST['alw'];
		

$name_sql=mysql_query("select emp_id from emp_personal_data where emp_name='$names'", $connection);
$row = mysql_fetch_assoc($name_sql);
$id_name =$row['emp_id'];

$pass_sql=mysql_query("select emp_pass from emp_personal_data where emp_id='$id_name'", $connection);
$rowpass = mysql_fetch_assoc($pass_sql);
$pass =$row['emp_pass'];

$name_sql2=mysql_query("select job_id from job_classification where rank='$rank'", $connection);
$row2 = mysql_fetch_assoc($name_sql2);
$rank_id =$row2['job_id'];
		
		try{
			
			$stmt = $db_con->prepare("INSERT INTO emp_job_data(emp_id, tin, sss, job_id ,dept, title, category, hired, current, alw) VALUES(:id, :tin, :sss, :jid, :dep, :tle, :cat, :hed, :cur, :alw)");
			$stmt->bindParam(":id", $id_name);
			$stmt->bindParam(":tin", $tin);
			$stmt->bindParam(":sss", $sss);
			$stmt->bindParam(":jid", $rank_id);			
			$stmt->bindParam(":dep", $dept);
			$stmt->bindParam(":tle", $position);
			$stmt->bindParam(":cat", $category);
			$stmt->bindParam(":hed", $hired);
			$stmt->bindParam(":cur", $salary);
			$stmt->bindParam(":alw", $alw);
			
			if($stmt->execute())
			{		
if($rank_id > 4){
$to = "admin@confluentlearning.com";
$subject = "Account for Confluent HR Solutions";
$content= "This is your account in 'CONFLUENT HR SOLUTIONS'.\n\n\n
EMPLOYEE NUMBER: $id_name \n
PASSWORD: $pass \n\n\n";
$content.="*To access the system (CONFLUENT HR SOLUTIONS), you may contact the system's administrator through the following details: 09071072050\n\n\n";
$content.="\n\n*** This is an automatically generated email ***";

$headers = "From: Confluent HR Solutions <admin@confluentlearning.com>";
mail($to,$subject,$content,$headers);
}
			
			echo "Saving...";
			$ern = mysql_query("INSERT INTO ern_data (emp_id, new_rank, new_dept, new_pos, new_status, new_salary, new_alw, status) VALUES ('$id_name', '$rank', '$dept', '$position',  '$category', '$salary', '$alw', 'undone')", $connection);
			$trail = mysql_query("INSERT INTO trail (type, per_action, description, emp_id) VALUES ('Employee Job Data', 'ADDED', '$names', '$user_check')", $connection);
			}
			else{
				echo "Query Problem";
			}	
		}
		catch(PDOException $e){
			echo $e->getMessage();
		}
	}

?>