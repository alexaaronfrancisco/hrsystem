		<script src="../../assets/bootstrap-formhelpers-phone.js"></script>
<?php
require_once '../../assets/dbconfig.php';

if($_GET['edit_id'])
{
	$id = $_GET['edit_id'];	
	$stmt=$db_con->prepare("SELECT * FROM emp_personal_data WHERE emp_id=:id");
	$stmt->execute(array(':id'=>$id));	
	$row=$stmt->fetch(PDO::FETCH_ASSOC);
}

?>
	    <link href="../../bootstrap/css/bootstrap-datepicker.css" rel="stylesheet" type="text/css"/>
		<script src="../../bootstrap/js/bootstrap-datepicker.min.js"></script>
<script>


 $(document).ready(function(){
$('input[name="bday"]').datepicker({
		format: "mm/dd/yyyy",
		startView: 'decade'     
		})
        });
		
		$(document).ready(function(){
    $('[data-toggle="tooltip"]').tooltip();   
});
		</script>

<style type="text/css">
#dis{
	display: none;
	margin-left: 70px;
	position: fixed;
	top: 50px;
	width: 68%;
	padding:20px;
	z-index:99999;
}
  .loader {
	position: fixed;
	left: 0px;
	top: 0px;
	width: 100%;
	height: 100%;
	z-index: 9999;
	background: url('../../img/loading.gif') 50% 50% no-repeat rgb(249,249,249);
	opacity: .5;
}

#square {
background-color: #ECECFF;
-webkit-box-shadow: 0px 0px 2px rgba(50, 50, 50, 0.31);
    -moz-box-shadow:    0px 0px 5px rgba(50, 50, 50, 0.31);
    box-shadow:         0px 0px 10px rgba(50, 50, 50, 0.31);
padding:20px;
}
.add {
border-radius: 100%;
padding-top:15px;
padding-bottom: 17px;
padding-left: 15px;
padding-right: 17px;
font-size:24px;		
}
.add:focus{
outline: 0px;
}
.btn {
border-radius: 100%;
padding-top:25px;
padding-bottom: 25px;
padding-left: 25px;
padding-right: 25px;
font-size:36px;
			    -webkit-box-shadow: 0px 0px 10px rgba(50, 50, 50, 20);
    -moz-box-shadow:    0px 0px 10px rgba(50, 50, 50, 20);
    box-shadow:         0px 0px 10px rgba(50, 50, 50, 20);
}
.btn:focus{
outline: 0px;
}
  @media only screen and (max-width: 768px) 
{ 
#dis{
	top: 75px;
	margin-left: 0;
	width:70%
}

</style>
    <div id="dis">
    <!-- here message will be displayed -->
	</div>

<div class="title"> Update Employee Personal Data</div>
	 <form method='post' id='emp-UpdateForm' action="#">
 
<div id="square">
<div class="row">
<input type='hidden' name='id' value='<?php echo $row['emp_id']; ?>' />
                  <div class="col-sm-4">
              <b>*First Name</b>
 <div style="margin-bottom: 10px;" class="input-group">
			  <span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span>
			<input type='text' name='fname' id="name" value="<?php echo $row['fname']; ?>"  placeholder='' class="form-control" required /> 
         </div>
 </div>
                  <div class="col-sm-3">
              <b>Middle Name</b>
 <div style="margin-bottom: 10px;" class="input-group">
			  <span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span>
			<input type='text' name='mname' id="mname" value="<?php echo $row['mname']; ?>"  placeholder='' class="form-control"/> 
         </div>
 </div>

                  <div class="col-sm-3">
              <b>Last Name</b>
 <div style="margin-bottom: 10px;" class="input-group">
			  <span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span>
			<input type='text' name='lname' id="lname" value="<?php echo $row['lname']; ?>"  placeholder='' class="form-control" required /> 
         </div>
 </div>

                  <div class="col-sm-2">
              <b>Suffix Name</b>
 <div style="margin-bottom: 10px;" class="input-group">
			  <span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span>
			<input type='text' name='sname' id="sname" value="<?php echo $row['sname']; ?>"  placeholder='' class="form-control"/> 
         </div>
 </div>
 </div>
<div class="row">
         <div class="col-sm-2">
             <b>*Gender </b> 
			  <div style="margin-bottom: 10px;" class="input-group">
			  <span class="input-group-addon"><i class="glyphicon glyphicon-transfer"></i></span>
			  <select name='gender' id="gen" class='form-control' value="<?php echo $row['emp_gender']; ?>" placeholder='' required>
<?php 
if  ($row['emp_gender'] == 'Male')
{?>
  <option  value="<?php echo $row['emp_gender']; ?>"><?php echo $row['emp_gender']; ?></option>
<!---  <option value="Male">Male</option>--->
  <option value="Female">Female</option><?php }
  else {?> 
  <option  value="<?php echo $row['emp_gender']; ?>"><?php echo $row['emp_gender']; ?></option>
<!---  <option value="Male">Male</option>--->
  <option value="Male">Male</option><?php } ?>
</select>
         <!----    <input type='text' name='gender' id="gen" class='form-control' placeholder='' required> ----->
         </div>
		 </div>
 <div class="col-sm-2">
			 <b>*Age  </b>
			  <div style="margin-bottom: 10px;" class="input-group">
			  <span class="input-group-addon"><i class="glyphicon glyphicon-leaf"></i></span>
             <input type='text' name='age' id="age" class='form-control' value="<?php echo $row['emp_age']; ?>" placeholder='' maxlength="2" onkeypress='return event.charCode >= 48 && event.charCode <= 57' required>
         </div>
		 </div>
		 

		  <div class="col-sm-4">
             <b> *Birthday </b>
			  <div style="margin-bottom: 10px;" class="input-group">
			  <span class="input-group-addon"><i class="glyphicon glyphicon-calendar"></i></span>
             <input type='text' tabindex="2" name='bday' id="bday" class='form-control' value="<?php echo $row['emp_bday']; ?>" placeholder='Click Here' readonly="true" data-behavior="datepicker" required>  
         </div>
		 </div>
</div>		
      <div class="row">        
         
		  <div class="col-sm-4">
	           <b>  *Mobile Number </b>
			    <div style="margin-bottom: 10px;" class="input-group">
			  <span class="input-group-addon"><i class="glyphicon glyphicon-phone"></i></span>
             <input type='text' name='conum' id="num" class='form-control bfh-phone' data-format="dddd-ddd-dddd" maxlength="13" placeholder='' value="<?php echo $row['emp_contact']; ?>" onkeypress='return event.charCode >= 48 && event.charCode <= 57' required>
         </div>
		 </div>
		   <div class="col-sm-4">
	           <b>  Telephone Number </b>
			    <div style="margin-bottom: 10px;" class="input-group">
			  <span class="input-group-addon"><i class="glyphicon glyphicon-earphone"></i></span>
             <input type='text' name='conum2' id="num2" class='form-control bfh-phone' data-format="ddd-dd-dd" placeholder='' maxlength="9" value="<?php echo $row['emp_contact2']; ?>" onkeypress='return event.charCode >= 48 && event.charCode <= 57'>
         </div>
		 </div>
		  <div class="col-sm-4">
             <b> *Email Address </b>
			  <div style="margin-bottom: 10px;" class="input-group">
			  <span class="input-group-addon"><i class="glyphicon glyphicon-envelope"></i></span>
             <input type='email' name='email' id="mail" class='form-control' placeholder='succeed@confluentlearning.com' value="<?php echo $row['emp_email']; ?>" pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,3}$" required>
         </div>
		 </div>
		 </div>
		 <div class="row">
		  <div class="col-sm-10">
             <b>*Home Address </b>
			  <div style="margin-bottom: 20px;" class="input-group">
			  <span class="input-group-addon"><i class="glyphicon glyphicon-map-marker"></i></span>
             <input type='text' name='address' id="add" class='form-control' placeholder='' value="<?php echo $row['emp_address']; ?>" required>
         </div>
		 </div>
		 </div>
		 <div class="row">
		  <div class="col-sm-10">
             <b>Mailing/City Address </b>
			  <div style="margin-bottom: 20px;" class="input-group">
			  <span class="input-group-addon"><i class="glyphicon glyphicon-map-marker"></i></span>
             <input type='text' name='address2' id="add2" class='form-control' value="<?php echo $row['emp_address2']; ?>" placeholder=''>
         </div>
		 </div>

		  <div class="col-sm-2">
         	<b>*Status </b>
			 <div style="margin-bottom: 20px;" class="input-group">
			  <span class="input-group-addon"><i class="glyphicon glyphicon-cog"></i></span>
			  <select name='status' id="stat" class='form-control' placeholder='' value="<?php echo $row['emp_status']; ?>" required>
			  
<?php 
if  ($row['emp_status'] == 'admin')
{?>
  <option  value="<?php echo $row['emp_status']; ?>"><?php echo $row['emp_status']; ?></option>
  <option value="active">active</option>
  <option value="inactive">inactive</option><?php }
  else if  ($row['emp_status'] == 'active') {?> 
  <option  value="<?php echo $row['emp_status']; ?>"><?php echo $row['emp_status']; ?></option>
  <option value="admin">admin</option>
    <option value="inactive">inactive</option><?php } 
  else { ?>
  <option  value="<?php echo $row['emp_status']; ?>"><?php echo $row['emp_status']; ?></option>
  <option value="admin">admin</option>
    <option value="active">active</option><?php } ?>

</select>
         <!---    <input type='text' name='status' id="stat" class='form-control' placeholder='' required> ---->
         </div></div>
		     </div>
     </form>    
            <button type="btn-save" class="btn btn-success" name="btn-save" id="btn-save" data-toggle="tooltip" data-placement="right" title="Save Record">
    		<span class="glyphicon glyphicon-floppy-save"></span>
			</button>  
			
		</div>

 <script>
 
(function() {
		var count1 = parseInt(1, 10);        
        var count2 = parseInt(1, 10);
        var count3 = parseInt(1, 10);
		var count4 = parseInt(1, 10);        
        var count5 = parseInt(1, 10);
        var count6 = parseInt(1, 10);
		var count7 = parseInt(1, 10);        
        var count8 = parseInt(1, 10);
		        var count9 = parseInt(1, 10);
        var counttotal = parseInt(0, 10);

$("#alerts").click(function(){
    alert(counttotal+" number of total");
});

counttotal = count1 + count2 + count3 + count4 + count5 + count6 + count7 + count8 + count9;

<!----- FOR READY FUNCTION ---->
$(document).ready(function() {       		 
            if ($('#name').val() == '') {
                count1 = 1;
$("#errname").text("*This is a required field");
$("#name").css("border","red solid 1px");
$('#btn-save').attr('disabled', 'disabled');
            }
else {
count1=0;
$("#errname").text("");
$("#name").css("border","green solid 1px");
}
if (count1 == 1 || count2 == 1 || count3 == 1 || count4 == 1 || count5 == 1 || count6 == 1 || count7 == 1 || count8 == 1 || count9 == 1 ){       
            $('#btn-save').attr('disabled', 'disabled');
        } else {
            $('#btn-save').removeAttr('disabled');}

})

<!----last name->
$(document).ready(function() {  
            if ($('#lname').val() == '') {
                count9 = 1;
$("#errname").text("*This is a required field");
$("#lname").css("border","red solid 1px");
$('#btn-save').attr('disabled', 'disabled');
            }
else {
count9=0;
$("#errname").text("");
$("#lname").css("border","green solid 1px");
}
if (count1 == 1 || count2 == 1 || count3 == 1 || count4 == 1 || count5 == 1 || count6 == 1 || count7 == 1 || count8 == 1 || count9 == 1){       
            $('#btn-save').attr('disabled', 'disabled');
        } else {
            $('#btn-save').removeAttr('disabled');}

})

<!----- For Gender ----->
$(document).ready(function() {       		 
            if (($('#gen').val() == '') || ($('#gen').val() == 'none')) {
                count2 = 1;
$("#errgen").text("*This is a required field");
$("#gen").css("border","red solid 1px");
$('#btn-save').attr('disabled', 'disabled');
            }
else {
count2=0;
$("#errgen").text("");
$("#gen").css("border","green solid 1px");
}
if (count1 == 1 || count2 == 1 || count3 == 1 || count4 == 1 || count5 == 1 || count6 == 1 || count7 == 1 || count8 == 1 || count9 == 1 ){       
            $('#btn-save').attr('disabled', 'disabled');
        } else {
            $('#btn-save').removeAttr('disabled');}

})

<!----- For Age ----->
$(document).ready(function() {       		 
            if ($('#age').val() == '' || $('#age').val().length == 1) {
                count3 = 1;
$("#errage").text("*This is a required field");
$("#age").css("border","red solid 1px");
$('#btn-save').attr('disabled', 'disabled');
            }
else {
count3=0;
$("#errage").text("");
$("#age").css("border","green solid 1px");
}
if (count1 == 1 || count2 == 1 || count3 == 1 || count4 == 1 || count5 == 1 || count6 == 1 || count7 == 1 || count8 == 1 || count9 == 1 ){       
            $('#btn-save').attr('disabled', 'disabled');
        } else {
            $('#btn-save').removeAttr('disabled');}

})

<!----- For Birthday ----->
if ($.fn.datepicker) {
    $('.datepicker').datepicker();}
$(document).ready(function() {       		 
            if ($('#bday').val() == '') {
                count4 = 1;
$("#errbday").text("*This is a required field");
$("#bday").css("border","red solid 1px");
$('#btn-save').attr('disabled', 'disabled');
            }
else {
count4=0;
	
$("#errbday").text("");
$("#bday").css("border","green solid 1px");
}
if (count1 == 1 || count2 == 1 || count3 == 1 || count4 == 1 || count5 == 1 || count6 == 1 || count7 == 1 || count8 == 1 || count9 == 1 ){       
            $('#btn-save').attr('disabled', 'disabled');
        } else {
            $('#btn-save').removeAttr('disabled');}

})

<!----- For Contact Number ----->
$(document).ready(function() {       		 
            if ($('#num').val() == '' || $('#num').val().length < 13) {
                count5 = 1;
$("#errnum").text("*This is a required field");
$("#num").css("border","red solid 1px");
$('#btn-save').attr('disabled', 'disabled');
            }
else {
count5=0;
$("#errnum").text("");
$("#num").css("border","green solid 1px");
}
if (count1 == 1 || count2 == 1 || count3 == 1 || count4 == 1 || count5 == 1 || count6 == 1 || count7 == 1 || count8 == 1 || count9 == 1 ){       
            $('#btn-save').attr('disabled', 'disabled');
        } else {
            $('#btn-save').removeAttr('disabled');}

})
						
$(document).ready(function() {
 	var x = $('#mail').val();
    var atpos = x.indexOf("@");
    var dotpos = x.lastIndexOf(".");
    if (atpos<1 || dotpos<atpos+2 || dotpos+2>=x.length) {
		count6 = 1;
$("#errmail").text("*Invalid Email Address");
$("#mail").css("border","red solid 1px");
$('#btn-save').attr('disabled', 'disabled');
}
else {
count6=0;
$("#erremail").text("");
$("#mail").css("border","green solid 1px");
}
if (count1 == 1 || count2 == 1 || count3 == 1 || count4 == 1 || count5 == 1 || count6 == 1 || count7 == 1 || count8 == 1 || count9 == 1 ){       
            $('#btn-save').attr('disabled', 'disabled');
        } else {
            $('#btn-save').removeAttr('disabled');}

})

<!----- For Address ----->
$(document).ready(function() {       		 
            if ($('#add').val() == '') {
                count7 = 1;
$("#erradd").text("*This is a required field");
$("#add").css("border","red solid 1px");
$('#btn-save').attr('disabled', 'disabled');
            }
else {
count7=0;
$("#erradd").text("");
$("#add").css("border","green solid 1px");
}
if (count1 == 1 || count2 == 1 || count3 == 1 || count4 == 1 || count5 == 1 || count6 == 1 || count7 == 1 || count8 == 1 || count9 == 1 ){       
            $('#btn-save').attr('disabled', 'disabled');
        } else {
            $('#btn-save').removeAttr('disabled');}

})

<!----- For Status ----->
$(document).ready(function() {       		 
            if (($('#stat').val() == '') || ($('#stat').val() == 'none')) {
                count8 = 1;
$("#errstat").text("*This is a required field");
$("#stat").css("border","red solid 1px");
$('#btn-save').attr('disabled', 'disabled');
            }
else {
count8=0;
$("#errstat").text("");
$("#stat").css("border","green solid 1px");
}
if (count1 == 1 || count2 == 1 || count3 == 1 || count4 == 1 || count5 == 1 || count6 == 1 || count7 == 1 || count8 == 1 || count9 == 1 ){       
            $('#btn-save').attr('disabled', 'disabled');
        } else {
            $('#btn-save').removeAttr('disabled');}

})


<!---- For Name ------>

    $('#name').keyup(function() {       		 
            if ($('#name').val() == '') {
                count1 = 1;
$("#errname").text("*This is a required field");
$("#name").css("border","red solid 1px");
$('#btn-save').attr('disabled', 'disabled');
            }
else {
count1=0;
$("#errname").text("");
$("#name").css("border","green solid 1px");
}
if (count1 == 1 || count2 == 1 || count3 == 1 || count4 == 1 || count5 == 1 || count6 == 1 || count7 == 1 || count8 == 1 || count9 == 1 ){       
            $('#btn-save').attr('disabled', 'disabled');
        } else {
            $('#btn-save').removeAttr('disabled');}

})
  $('#lname').keyup(function() {       		 
            if ($('#lname').val() == '') {
                count9 = 1;
$("#errname").text("*This is a required field");
$("#lname").css("border","red solid 1px");
$('#btn-save').attr('disabled', 'disabled');
            }
else {
count9=0;
$("#errname").text("");
$("#lname").css("border","green solid 1px");
}
if (count1 == 1 || count2 == 1 || count3 == 1 || count4 == 1 || count5 == 1 || count6 == 1 || count7 == 1 || count8 == 1 || count9 == 1){       
            $('#btn-save').attr('disabled', 'disabled');
        } else {
            $('#btn-save').removeAttr('disabled');}

})

<!----- For Gender ----->
    $('#gen').change(function() {       		 
            if (($('#gen').val() == '') || ($('#gen').val() == 'none')) {
                count2 = 1;
$("#errgen").text("*This is a required field");
$("#gen").css("border","red solid 1px");
$('#btn-save').attr('disabled', 'disabled');
            }
else {
count2=0;
$("#errgen").text("");
$("#gen").css("border","green solid 1px");
}
if (count1 == 1 || count2 == 1 || count3 == 1 || count4 == 1 || count5 == 1 || count6 == 1 || count7 == 1 || count8 == 1 || count9 == 1 ){       
            $('#btn-save').attr('disabled', 'disabled');
        } else {
            $('#btn-save').removeAttr('disabled');}

})

<!----- For Age ----->
    $('#age').keyup(function() {       		 
            if ($('#age').val() == '' || $('#age').val().length == 1) {
                count3 = 1;
$("#errage").text("*This is a required field");
$("#age").css("border","red solid 1px");
$('#btn-save').attr('disabled', 'disabled');
            }
else {
count3=0;
$("#errage").text("");
$("#age").css("border","green solid 1px");
}
if (count1 == 1 || count2 == 1 || count3 == 1 || count4 == 1 || count5 == 1 || count6 == 1 || count7 == 1 || count8 == 1 || count9 == 1 ){       
            $('#btn-save').attr('disabled', 'disabled');
        } else {
            $('#btn-save').removeAttr('disabled');}

})

<!----- For Birthday ----->
if ($.fn.datepicker) {
    $('.datepicker').datepicker();}
    $('#bday').change(function() {       		 
            if ($('#bday').val() == '') {
                count4 = 1;
$("#errbday").text("*This is a required field");
$("#bday").css("border","red solid 1px");
$('#btn-save').attr('disabled', 'disabled');
            }
else {
count4=0;
	
$("#errbday").text("");
$("#bday").css("border","green solid 1px");
}
if (count1 == 1 || count2 == 1 || count3 == 1 || count4 == 1 || count5 == 1 || count6 == 1 || count7 == 1 || count8 == 1 || count9 == 1 ){       
            $('#btn-save').attr('disabled', 'disabled');
        } else {
            $('#btn-save').removeAttr('disabled');}

})

<!----- For Contact Number ----->
    $('#num').keyup(function() {       		 
            if ($('#num').val() == '' || $('#num').val().length < 13) {
                count5 = 1;
$("#errnum").text("*This is a required field");
$("#num").css("border","red solid 1px");
$('#btn-save').attr('disabled', 'disabled');
            }
else {
count5=0;
$("#errnum").text("");
$("#num").css("border","green solid 1px");
}
if (count1 == 1 || count2 == 1 || count3 == 1 || count4 == 1 || count5 == 1 || count6 == 1 || count7 == 1 || count8 == 1 || count9 == 1 ){       
            $('#btn-save').attr('disabled', 'disabled');
        } else {
            $('#btn-save').removeAttr('disabled');}

})
						
		$('#mail').keyup(function() {
 	var x = $('#mail').val();
    var atpos = x.indexOf("@");
    var dotpos = x.lastIndexOf(".");
    if (atpos<1 || dotpos<atpos+2 || dotpos+2>=x.length) {
		count6 = 1;
$("#errmail").text("*Invalid Email Address");
$("#mail").css("border","red solid 1px");
$('#btn-save').attr('disabled', 'disabled');
}
else {
count6=0;
$("#erremail").text("");
$("#mail").css("border","green solid 1px");
}
if (count1 == 1 || count2 == 1 || count3 == 1 || count4 == 1 || count5 == 1 || count6 == 1 || count7 == 1 || count8 == 1 || count9 == 1 ){       
            $('#btn-save').attr('disabled', 'disabled');
        } else {
            $('#btn-save').removeAttr('disabled');}

})

<!----- For Address ----->
    $('#add').keyup(function() {       		 
            if ($('#add').val() == '') {
                count7 = 1;
$("#erradd").text("*This is a required field");
$("#add").css("border","red solid 1px");
$('#btn-save').attr('disabled', 'disabled');
            }
else {
count7=0;
$("#erradd").text("");
$("#add").css("border","green solid 1px");
}
if (count1 == 1 || count2 == 1 || count3 == 1 || count4 == 1 || count5 == 1 || count6 == 1 || count7 == 1 || count8 == 1 || count9 == 1 ){       
            $('#btn-save').attr('disabled', 'disabled');
        } else {
            $('#btn-save').removeAttr('disabled');}

})

<!----- For Status ----->
    $('#stat').change(function() {       		 
            if (($('#stat').val() == '') || ($('#stat').val() == 'none')) {
                count8 = 1;
$("#errstat").text("*This is a required field");
$("#stat").css("border","red solid 1px");
$('#btn-save').attr('disabled', 'disabled');
            }
else {
count8=0;
$("#errstat").text("");
$("#stat").css("border","green solid 1px");
}
if (count1 == 1 || count2 == 1 || count3 == 1 || count4 == 1 || count5 == 1 || count6 == 1 || count7 == 1 || count8 == 1 || count9 == 1 ){       
            $('#btn-save').attr('disabled', 'disabled');
        } else {
            $('#btn-save').removeAttr('disabled');}

})
/*
	$('#length').keyup(function() {
        var text_length = parseInt($('#length').val().length, 10);
if ($('#length').val() == '' || text_length <= 29){
count3 = 1;
$("#errmess").text("*This is a required field with a minimum of 30 characters");
$("#length").css("border","red solid 1px");
$('# btn-save').attr('disabled', 'disabled');
}
else {
count3=0;
$("#errmess").text("");
$("#length").css("border","red solid 0px");
}	 
if (count1 == 1 || count2 == 1 || count3 == 1 || count4 == 1 || count5 == 1 || count6 == 1 || count7 == 1 || count8 == 1 || count9 == 1 ){       
            $('# btn-save').attr('disabled', 'disabled');
        } else {
            $('# btn-save').removeAttr('disabled');}

})
*/
})()


</script>
    