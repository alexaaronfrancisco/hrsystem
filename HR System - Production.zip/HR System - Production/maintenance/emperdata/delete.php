<?php
require_once '../../assets/dbconfig.php';
require_once '../../assets/connection.php';

if($_POST['del_id'])
{	
	$id = $_POST['del_id'];	
	//
$name_sql=mysql_query("select emp_name from emp_personal_data where emp_id='$id'", $connection);
$row = mysql_fetch_assoc($name_sql);
$getname =$row['emp_name'];
//
	$trail = mysql_query("INSERT INTO trail (type, per_action, description, emp_id) VALUES ('Employee Personal Data', 'DELETED', '$getname', '$user_check')", $connection);
	$stmt=$db_con->prepare("UPDATE emp_personal_data SET emp_status = 'inactive' WHERE emp_id=:id");
	$stmt->execute(array(':id'=>$id) );
	

}
?>