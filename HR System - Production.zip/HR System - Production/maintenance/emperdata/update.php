<?php
require_once '../../assets/dbconfig.php';
require_once '../../assets/connection.php';
	
	if($_POST)
	{	$id = $_POST['id'];	
		$fname = $_POST['fname'];
		$lname = $_POST['lname'];
		$mname = $_POST['mname'];
		$sname = $_POST['sname'];
		$gender = $_POST['gender'];
		$bday = $_POST['bday'];
		$age= $_POST['age'];
		$conum = $_POST['conum'];
		$conum2 = $_POST['conum2'];
		$email = $_POST['email'];
		$address= $_POST['address'];
		$address2= $_POST['address2'];
		$status = $_POST['status'];

		$fullname = $lname.", ".$fname." ".$mname." ".$sname;
		
		$stmt = $db_con->prepare("UPDATE emp_personal_data SET emp_name=:full, fname=:fn, mname=:mn, lname=:ln, sname=:sn, emp_gender=:gen, emp_bday=:bd, emp_age=:age, emp_contact=:con, emp_contact2=:con2, emp_email=:em, emp_address=:add, emp_address2=:add2, emp_status=:stat WHERE emp_id=:id");
			$stmt->bindParam(":full", $fullname);
			$stmt->bindParam(":fn", $fname);
			$stmt->bindParam(":mn", $mname);
			$stmt->bindParam(":ln", $lname);
			$stmt->bindParam(":sn", $sname);
			$stmt->bindParam(":gen", $gender);
			$stmt->bindParam(":bd", $bday);
			$stmt->bindParam(":age", $age);
			$stmt->bindParam(":con", $conum);
			$stmt->bindParam(":con2", $conum2);
			$stmt->bindParam(":em", $email);
			$stmt->bindParam(":add", $address);
			$stmt->bindParam(":add2", $address2);
			$stmt->bindParam(":stat", $status);
			$stmt->bindParam(":id", $id);
		
		if($stmt->execute())
		{
			$trail = mysql_query("INSERT INTO trail (type, per_action, description, emp_id) VALUES ('Employee Personal Data', 'UPDATED', 'Data of $fullname', '$user_check')", $connection);
			echo "Updating...";
			
		}
		else{
			echo "Query Problem";
		}
	}

?>