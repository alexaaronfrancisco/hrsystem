<?php
require_once '../../assets/dbconfig.php';
require_once '../../assets/connection.php';

	if($_POST)
	{	$name = $_POST['typeahead'];
$name_sql=mysql_query("select emp_job_data.emp_id from emp_job_data LEFT JOIN emp_personal_data ON emp_job_data.emp_id=emp_personal_data.emp_ID where emp_personal_data.emp_name='$name' AND emp_personal_data.emp_status NOT LIKE 'inactive'", $connection);
$row = mysql_fetch_assoc($name_sql);
$id_name =$row['emp_id'];

			
			$query = mysql_query("select emp_id from emp_job_data where emp_id='$id_name'", $connection);
			$rows = mysql_num_rows($query);


if ($rows == 0) {
			echo "Employee name does not exist!";
}				
			else{
				echo "Loading... $id_name";
			}	
	}

?>