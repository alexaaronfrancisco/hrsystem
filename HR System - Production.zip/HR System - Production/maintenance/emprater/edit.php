<?php
require_once '../../assets/dbconfig.php';
require_once '../../assets/connection.php';

if($_GET['edit_id'])
{
	$id = $_GET['edit_id'];	
	$stmt=$db_con->prepare("SELECT * FROM emp_personal_data WHERE emp_id=:id");
	$stmt->execute(array(':id'=>$id));	
	$row=$stmt->fetch(PDO::FETCH_ASSOC);			
	$namewpg =$row['emp_name'];
	$fname =$row['fname'];

	$getrate_sql=mysql_query("select rate from emp_job_data where emp_id='$id'", $connection); 
	$rowgetrate = mysql_fetch_assoc($getrate_sql);
	$rate_entry = $rowgetrate['rate'];				
	$arrayrate = explode(',', $rate_entry);
}


			
?>

<script>
		$(document).ready(function(){
    $('[data-toggle="tooltip"]').tooltip();  
			

});
		</script>

<style type="text/css">
#dis{
	display: none;
	margin-left: 70px;
	position: fixed;
	top: 50px;
	width: 68%;
	padding:20px;
	z-index:99999;
}
  .loader {
	position: fixed;
	left: 0px;
	top: 0px;
	width: 100%;
	height: 100%;
	z-index: 9999;
	background: url('../../img/loading.gif') 50% 50% no-repeat rgb(249,249,249);
	opacity: .5;
}

#square {
background-color: #ECECFF;
-webkit-box-shadow: 0px 0px 2px rgba(50, 50, 50, 0.31);
    -moz-box-shadow:    0px 0px 5px rgba(50, 50, 50, 0.31);
    box-shadow:         0px 0px 10px rgba(50, 50, 50, 0.31);
padding:20px;
}
.check{
width:15px;
height:15px;
}


#btn-add {
position:relative;
border-radius: 100%;
top:10px;
padding-top:25px;
padding-bottom: 25px;
padding-left: 25px;
padding-right: 25px;
font-size:36px;
	-webkit-box-shadow: 0px 0px 10px rgba(50, 50, 50, 20);
    -moz-box-shadow:    0px 0px 10px rgba(50, 50, 50, 20);
    box-shadow:         0px 0px 10px rgba(50, 50, 50, 20);
}
#btn-add:focus{
outline: 0px;
}

  @media only screen and (max-width: 768px) 
{ 
#dis{
	top: 75px;
	margin-left: 0;
	width:70%
}

</style>
    <div id="dis">
    <!-- here message will be displayed -->
	</div>
	
		<!-- Modal for save salary -->

  <div class="modal fade" id="modaladd" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h3 class="modal-title text-primary"><span class="glyphicon glyphicon-user"> </span> Update Employee</h3>
        </div>
        <div class="modal-body">
		<br />
          <p>You have selected the following employee:</p>
		  <div id="selectedemp"></div>
        </div>
        <div class="modal-footer">
		  <button type="button" id="no" value="no" data-dismiss="modal" class="btn btn-default" > Cancel </button>
		  <button type="button" id="yes" value="yes" class="btn btn-primary" autofocus> Update </button>
		
        </div>
      </div>
      
    </div>
  </div>
	

<div class="title"> Choose employee can rate by <c class="label label-primary"><?php echo $namewpg; ?></c> </div>
<div id="square">
<div class='btn btn-default' id='uncheck'>Uncheck All</div>
<?php 
$jobid_sql=mysql_query("select job_id from emp_job_data where emp_id='$id'", $connection); 
$rowjobid = mysql_fetch_assoc($jobid_sql);
$jobid_entry = $rowjobid['job_id'];
$count_emp = 0;
if ($jobid_entry >= 5 && $jobid_entry <= 7){
$empidcount_sql=mysql_query("select emp_id from emp_job_data where job_id BETWEEN 1 AND 4 ORDER BY dept ASC", $connection);
$count_emp = mysql_num_rows($empidcount_sql);
}
else if ($jobid_entry >= 8 && $jobid_entry <= 11){
$empidcount_sql=mysql_query("select emp_id from emp_job_data where job_id BETWEEN 1 AND 7 ORDER BY dept ASC", $connection);
$count_emp = mysql_num_rows($empidcount_sql);
}
else if ($jobid_entry >= 12 && $jobid_entry <= 15){
$empidcount_sql=mysql_query("select emp_id from emp_job_data where job_id BETWEEN 1 AND 11 ORDER BY dept ASC", $connection);
$count_emp = mysql_num_rows($empidcount_sql);
}
 while($rownames=mysql_fetch_assoc($empidcount_sql))
    {
      $arrayid2[] = $rownames['emp_id'];
    }	
	$arrayid = array_values(array_diff($arrayid2, $arrayrate));
	$countarray = $count_emp - count($arrayrate);
	
$a=0;

echo "<h4 class='text text-primary'>Current employee can rate by $fname</h4><div class='row'>";
while ($a != count($arrayrate)){
$empname3 = mysql_query("select emp_name from emp_personal_data where emp_id='".$arrayrate[$a]."'", $connection);
$fetchname3 = mysql_fetch_assoc($empname3);
$getname3 = $fetchname3['emp_name'];
?>
<div class="col-sm-6">
<input type="checkbox" class="check" name="checkboxlist" lang="1st" id="<?php echo $x; ?>"  checked="checked" value="<?php echo $getname3;?>" alt="<?php echo $arrayrate[$a]; ?>" /> <?php echo $getname3;?><br />
</div>
<?php
$a++;
}

?>
</div>
	<form id='rate' method="post">
	<br />
	<div class="row">
<?php 
$x=0;
$y=0;
$z=0;
$storedept="";
while ($x != $countarray){

$empdept = mysql_query("select dept from emp_job_data where emp_id='".$arrayid[$x]."'", $connection);
$fetchdept = mysql_fetch_assoc($empdept);
$getdept = $fetchdept['dept']; 
$empname = mysql_query("select emp_name from emp_personal_data where emp_id='".$arrayid[$x]."'", $connection);
$fetchname = mysql_fetch_assoc($empname);
$getname = $fetchname['emp_name'];
if($storedept != $getdept){
$storedept = $getdept;?>
<div class="col-sm-6">
<?php 
echo "<h4 class='text text-primary'>".$storedept."</h4>";
}
?>
<input type="checkbox" class="check" name="checkboxlist" lang="2nd" id="<?php echo $x; ?>"  value="<?php echo $getname;?>" alt="<?php echo $arrayid[$x]; ?>" /> <?php echo $getname;?><br />
<?php


$y++;
if($y != $countarray){
$empdept2 = mysql_query("select dept from emp_job_data where emp_id='".$arrayid[$y]."'", $connection);
$fetchdept2 = mysql_fetch_assoc($empdept2);
$getdept2 = $fetchdept2['dept']; 
if($storedept != $getdept2){?>
</div>
<?php
}
}
else{?>
</div>
<?php
}
$x++;
}
?> 
		     			 
</form>    
</div>
            <button type="btn-add" class="btn btn-success" name="btn-add" id="btn-add" data-toggle="tooltip" data-placement="right" title="Save Record">
    		<span class="glyphicon glyphicon-floppy-save"></span>
			</button>  
			</div>
		</div>
		
 <script>
 var arrsum = 100;
var count = parseInt(1, 10);      
var count2 = parseInt(1, 10);    
//ready


$(document).ready(function(){
var y = <?php echo count($arrayrate);?>;
var x = 0;
if(x == 0 && y == 0){
$("#btn-add").attr("disabled","disabled");
}
else{
$("#btn-add").removeAttr("disabled","disabled");
}

$("#uncheck").click(function(){
y = 0;
x = 0;
$("input[name='checkboxlist']").removeProp('checked');
if(x == 0 && y == 0){
$("#btn-add").attr("disabled","disabled");
}
else{
$("#btn-add").removeAttr("disabled","disabled");
}
});

$("input[lang='1st'").click(function(){
if($(this).prop("checked") == true){
y++;
}
else if($(this).prop("checked") == false){
y--;
}
if(x == 0 && y == 0){
$("#btn-add").attr("disabled","disabled");
}
else{
$("#btn-add").removeAttr("disabled","disabled");
}
});	

$("input[lang='2nd'").click(function(){
if($(this).prop("checked") == true){
x++;
}
else if($(this).prop("checked") == false){
x--;
}
if(x == 0 && y == 0){
$("#btn-add").attr("disabled","disabled");
}
else{
$("#btn-add").removeAttr("disabled","disabled");
}
});

	$("#btn-add").click(function(){
            var checkValues = $('input[name=checkboxlist]:checked').map(function()
            {
                return $(this).val();
            }).get();	
		
			$("#selectedemp").html(checkValues.join("<br>"));
			$("#modaladd").modal('show');
  });
  });
  
  
		$("#yes").click(function() {
					$("#modaladd").modal('hide');
		var raterid = "<?php echo $id; ?>";
		 var checkid = $('input[name=checkboxlist]:checked').map(function()
            {
                return $(this).attr('alt');
            }).get();	
			var checkidpass = checkid.toString();
	  	$("#yes").attr("disabled","disabled");
	   		$.ajax({
            type: "POST",
            url: "updateedit.php", //process to add
            data: { empid:raterid, emprateid:checkidpass },					
            success: function(data){
			 $(".loader").fadeIn();
			 $("#dis").html('<div class="alert alert-success"><span class="glyphicon glyphicon-ok">&nbsp;</span>'+data+'</div>');
			 $("#dis").fadeIn('slow');
				     setTimeout(function(){
        $("#dis").fadeOut();
    }, 3000); 									
					  setTimeout(
  function() 
  {
$(".loader").fadeOut();
  }, 2000);
					  
					 setTimeout(
  function() 
  {
			window.location.href="index.php";
  }, 3000);
  }
		     });	
		 });   


</script>
    