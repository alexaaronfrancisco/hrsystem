<?php
require_once '../../assets/dbconfig.php';
require_once '../../assets/connection.php';


	if($_POST)
{		$id = $_POST['empid'];
		$emprateid = $_POST['emprateid'];			
		//Name
		$stmt=$db_con->prepare("SELECT * FROM emp_personal_data WHERE emp_id=:id");
	$stmt->execute(array(':id'=>$id));	
	$row=$stmt->fetch(PDO::FETCH_ASSOC);			
	$namewpg =$row['emp_name'];

			
			$stmt = $db_con->prepare("UPDATE emp_job_data SET rate=:rate WHERE emp_id=:id");
			$stmt->bindParam(":id", $id);
			$stmt->bindParam(":rate", $emprateid);
			
			if($stmt->execute())
			{
			$trail = mysql_query("INSERT INTO trail (type, per_action, description, emp_id) VALUES ('Employee Rater', 'ADDED', '$namewpg can now rate employee', '$user_check')", $connection);
			echo "Creating...";
			
			}
			else{
				echo "Query Problem";
			}	
		}

?>