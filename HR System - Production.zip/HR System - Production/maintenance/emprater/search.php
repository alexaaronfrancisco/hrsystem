<?php
    $key=$_GET['key'];
    $array = array();
    include('../../assets/connection.php');
    $query=mysql_query("select emp_personal_data.emp_name from emp_job_data LEFT JOIN emp_personal_data ON emp_job_data.emp_id=emp_personal_data.emp_ID where emp_name LIKE '%{$key}%' AND emp_status != 'inactive' AND emp_job_data.job_id > 4 AND emp_job_data.rate LIKE ''");
    while($row=mysql_fetch_assoc($query))
    {
      $array[] = $row['emp_name'];
    }
    echo json_encode($array);
?>
