<?php
require_once '../../assets/dbconfig.php';
require_once '../../assets/connection.php';

	if($_POST)
	{	$name = $_POST['typeahead'];
$name_sql=mysql_query("select emp_id from emp_personal_data where emp_name='$name' AND emp_status NOT LIKE 'inactive'", $connection);
$row = mysql_fetch_assoc($name_sql);
$id_name =$row['emp_id'];

			
			$query = mysql_query("select emp_id from emp_job_data where emp_id='$id_name' AND job_id BETWEEN 1 AND 4", $connection);
			$rows = mysql_num_rows($query);
if ($rows == 0) {
			echo "Employee name does not exist!";
}
			else{
				echo "Loading...";
			}	
	}

?>