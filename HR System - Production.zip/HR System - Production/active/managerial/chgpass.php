<?php
include('../../session.php');
$name_sql=mysql_query("select fname from emp_personal_data where emp_id='$user_check'", $connection);
$row2 = mysql_fetch_assoc($name_sql);
$getthename =$row2['fname'];

?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<title>Change Password</title>
<!--<link href="bootstrap/css/bootstrap.min.css" rel="stylesheet" media="screen">-->
<!--<link href="bootstrap/css/bootstrap-theme.min.css" rel="stylesheet" media="screen"> -->
  <link rel="shortcut icon" href="../../img/logo.ico" type="image/x-icon">
<link href="../../assets/datatables.min.css" rel="stylesheet" type="text/css">
    <link href="../../bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css"/>
	    <link href="../../bootstrap/css/sidebar.css" rel="stylesheet" type="text/css"/>
<script src="../../bootstrap/js/bootstrap.js"></script>
<script src="../../bootstrap/js/jquery-1.12.0.js"></script>
<script src="../../bootstrap/js/bootstrap.min.js"></script>
<script type="text/javascript">

$(document).ready(function(){
    $('[data-toggle="tooltip"]').tooltip();   
});

$(window).load(function() {
	$(".loader").fadeOut("slow");
})

$(".alert alert-success").fadeOut("slow");

</script>
<style>
@import url('https://fonts.googleapis.com/css?family=Tauri');
body{font-family: 'Tauri', sans-serif;}
.title{font-size:18px;
padding-bottom: 20px;
color: #0066CC;
width:100%;}

.footer {
z-index:2;
width:100%;
position:fixed;
display: block;
  right: 0;
  bottom: 0;
  left: 0;
  font-size:12px;
  padding: 1rem;
  background-color: #efefef;
  text-align: right;}
  
  .loader {
	position: fixed;
	left: 0px;
	top: 0px;
	width: 100%;
	height: 100%;
	z-index: 9999;
	background: url('img/loading.gif') 50% 50% no-repeat rgb(249,249,249);
	opacity: .5;
}

  .icon {
  float:left;
  display:block;
  padding-top: 10px;
  }
.sidebar-brand{
background-color:#FFFFFF;
}
.sidebar-brand img {
width: 225px;
height:57px;

}
#square {
background-color: #ECECFF;
-webkit-box-shadow: 0px 0px 2px rgba(50, 50, 50, 0.31);
    -moz-box-shadow:    0px 0px 5px rgba(50, 50, 50, 0.31);
    box-shadow:         0px 0px 10px rgba(50, 50, 50, 0.31);
padding:20px;
}

.btn {
border-radius: 1%;
padding-top:5px;
padding-bottom: 5px;
padding-left: 50px;
padding-right: 50px;
font-size:14px;
			    -webkit-box-shadow: 0px 0px 10px rgba(50, 50, 50, 20);
    -moz-box-shadow:    0px 0px 10px rgba(50, 50, 50, 20);
    box-shadow:         0px 0px 10px rgba(50, 50, 50, 20);
}
.btn:focus{
visibility:hidden;
outline: 0px;
}
.drop {
font-size:12px;
background-color:#111;
display:none;
 text-indent: 30px;
    line-height: 30px;
}

.drop2 {
font-size:12px;
background-color:#111;
display:none;
 text-indent: 30px;
    line-height: 30px;
}

.drop3 {
font-size:12px;
background-color:#111;
display:none;
 text-indent: 30px;
    line-height: 30px;
}

.drop4 {
font-size:12px;
background-color:#111;
display:none;
 text-indent: 30px;
    line-height: 30px;
}

.drop5 {
font-size:12px;
background-color:#111;
display:none;
 text-indent: 30px;
    line-height: 30px;
}


  @media only screen and (max-width: 768px) 
{ 
.footer {
margin-top: 50px;
width:100%;
position: relative;
font-size: 10px;
background-color: #fff;
}

.sidebar-brand img {
width: 190px;
height:45px;

}
}

</style>


</head>

<body>
<!------------------------------------------->
<div class="loader"></div>
      

        <!-- Sidebar -->
		<div class="stat" style="position:static;">
		<div class="sticktop" style="top:0; display:block; position: fixed; z-index:1000; right:0; left:0;">
		<div class="sidebar-brand">
                    <a href="#">
                       <img src="../../img/logo.jpg"> 
                    </a>
                </div>
				<div class="drops">
		<div class="dropdowntogs">
                               <a href="#"><span class="glyphicon glyphicon-user"> </span> &nbsp <b>Welcome,</b> <?php echo $getthename; ?></a></div>
				<div class="dropmenu">
			<!---	<a href="#"><span class="glyphicon glyphicon-wrench"> </span> Edit Profile</a><div></div>---->
				<a href="chgpass.php"><span class="glyphicon glyphicon-lock"> </span> Change Password</a>
				<hr></hr>
				<a href="../../logout.php"><span class="glyphicon glyphicon-log-out"> </span> Log-out</a>
				</div>
				</div>							

		<div class="toggles"><a href="" id="menu-toggle"><span class="glyphicon glyphicon-menu-hamburger" style="visibility:hidden;"></span></a></div>       
                </div>
				</div>
        <!-- /#sidebar-wrapper -->

        <!-- Page Content -->
<!--table--->		


		
<br  /><br  /><br  />
        <div id="page-content-wrapper">
            <div class="container-fluid">
			
							 <?php

require_once '../../assets/dbconfig.php';

if (isset($_POST['submit'])) {
if (empty($_POST['conpass']) || empty($_POST['newpass'])) {
$error = '<div class="alert alert-danger"><strong>Error!</strong> Username or Password is invalid!</div>';
}
else
{
		$newpass = $_POST['newpass'];
		$conpass = $_POST['conpass'];		
		
		$stmt = $db_con->prepare("UPDATE emp_personal_data SET emp_pass=:npass WHERE emp_id=:empid");			
			$stmt->bindParam(":npass", $newpass);
			$stmt->bindParam(":empid", $user_check);
		
		if($stmt->execute())
		{
			$trail = mysql_query("INSERT INTO trail (type, per_action, description, emp_id) VALUES ('Session', 'UPDATED', 'Changed password', '$user_check')", $connection);
			echo "<div class='alert alert-success'>&nbsp;<span class='glyphicon glyphicon-ok'>  </span>  &nbsp;Password Successfully Changed! Please wait... </div>";
			echo "<script> <div class='loader'></div> </script>";
			echo '<META HTTP-EQUIV="Refresh" Content="2; URL= ../../index.php" >';
		}
		else{
			echo "Query Problem";
		}
	}
}


?>
			
<div class="title"> Change Password </div>
	 <form method='post' id='emp-SaveForm' action="#">
 
<div id="square">
<div class="row">

                   <div class="col-sm-4">
              <b>New Password</b>
 <div style="margin-bottom: 10px;" class="input-group">
			  <span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span>
			<input type='password' name='newpass' id="newpass"  placeholder='Any numbers or letters' class="form-control" required /> 
         </div>
 </div>
 <div class="col-sm-4">
              <b>Confirm New Password</b>
 <div style="margin-bottom: 10px;" class="input-group">
			  <span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span>
			<input type='password' name='conpass' id="conpass"  placeholder='' class="form-control" required /> 
         </div>
 </div> <div class="col-sm-4"></div><br />
            <input type="submit" class="btn btn-success" name="submit" id="btn-save" value="Change" data-toggle="tooltip" data-placement="right" title="Change Password">
			
			</form> 
		</div>

			
			</div>
			<br />
			<a href="../managerial/"><span class="glyphicon glyphicon-arrow-left"></span> Back to OPMS form</a>

					       </br></br>
        <!-- /#page-content-wrapper -->
<div class="footer">
&nbsp;&nbsp;<b>Copyright </b> <span class="glyphicon glyphicon-copyright-mark"></span> <b><?php echo date(' Y')?></b> All Right Reserved. | Converge HR System powered by Confluent Learning | <b>Version</b> 2.0&nbsp;&nbsp;    </div>
</div>
    </div>
    <!-- /#wrapper -->
     <!-- Menu Toggle Script -->

<script>
$.fn.regexMask = function(mask) {
    $(this).keypress(function (event) {
        if (!event.charCode) return true;
        var part1 = this.value.substring(0, this.selectionStart);
        var part2 = this.value.substring(this.selectionEnd, this.value.length);
        if (!mask.test(part1 + String.fromCharCode(event.charCode) + part2))
            return false;
    });
};

$(document).ready(function() {
    var mask = new RegExp('^[A-Za-z0-9 ]*$')
     $("input").regexMask(mask) 
});



(function() {       
        var count2 = parseInt(1, 10);
        var count3 = parseInt(1, 10);
        var counttotal = parseInt(0, 10);

$("#alerts").click(function(){
    alert(counttotal+" number of total");
});

counttotal = count2 + count3;

if (counttotal <= 2){       
            $('#btn-save').attr('disabled', 'disabled');
        } else {
            $('#btn-save').removeAttr('disabled');		
}
<!----- For New PASS ----->
      $('#newpass').keyup(function() {       		 
            if ($('#newpass').val() == '') {
                count2 = 1;
$("#errname").text("*This is a required field");
$("#newpass").css("border","red solid 1px");
$('#btn-save').attr('disabled', 'disabled');
            }
else {
count2=0;
$("#errname").text("");
$("#newpass").css("border","green solid 1px");
}
if (count2 == 1 || count3 == 1){       
            $('#btn-save').attr('disabled', 'disabled');
        } else {
            $('#btn-save').removeAttr('disabled');}

})

<!------ FOR Confirm PASS --->
    $('#conpass').keyup(function() {       		 
            if ($('#conpass').val() == '' || $('#conpass').val() != $('#newpass').val()) {
                count3 = 1;
$("#errname").text("*This is a required field");
$("#conpass").css("border","red solid 1px");
$('#btn-save').attr('disabled', 'disabled');
            }
else {
count3=0;
$("#errname").text("");
$("#conpass").css("border","green solid 1px");
}
if (count2 == 1 || count3 == 1){       
            $('#btn-save').attr('disabled', 'disabled');
        } else {
            $('#btn-save').removeAttr('disabled');}

})
})()

	$(".dropdowntogs").click(function(e) {
        e.preventDefault();
        $(".dropmenu").toggle();
    });
	$(document).click(function(e) {
  if ( $(e.target).closest('.dropdowntogs').length === 0 ) {
    // hide menu here
	$(".dropmenu").hide();
  }
}); 

</script>
    