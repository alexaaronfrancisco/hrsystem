<?php
include('../../session.php');
    $key=$_GET['key'];
    $array = array();
	
	$getrate_sql=mysql_query("select rate from emp_job_data where emp_id='$user_check'", $connection); 
	$rowgetrate = mysql_fetch_assoc($getrate_sql);
	$rate_entry = $rowgetrate['rate'];				
	$arrayrate = explode(',', $rate_entry);
	$count_emp = count($arrayrate);
	$a = 0;
	$array[] = "";
	 while($a != $count_emp){
    $query=mysql_query("select emp_name from emp_personal_data WHERE emp_id LIKE '".$arrayrate[$a]."'");
    $row = mysql_fetch_assoc($query);
    $name = $row['emp_name'];
	array_push($array, "$name");
	$a++;
    }
	array_shift($array);
    echo json_encode($array);
?>
