<?php
require_once '../../assets/dbconfig.php';
require_once '../../assets/connection.php';
if($_POST){
$empid = $_POST['emp_id'];
$raterid = $_POST['rater_id'];
$tabulwpg = $_POST['wpg_cal'];
$tabulwpa = $_POST['wpa_cal'];
$wpgscoreget = $_POST['totalwpg'];
$wpascoreget = $_POST['totalwpa'];
$filetxt = $_POST['getfile'];
$file = str_replace("blank","\r\n", $filetxt);
$file_sql=mysql_query("select file from getper_ans where emp_id='$empid' order by per_id DESC", $connection);
$rowfile = mysql_fetch_assoc($file_sql);
$countrow = count($rowfile);
$file_entry =$rowfile['file'];
if (!file_exists('../../getperansfile/'.$empid)) {
    mkdir('../../getperansfile/'.$empid, 0777, true);
}
if ($countrow == 0){
$getcount ="0";}
else{
$getcount= str_replace("_answer.txt","", $file_entry);}
$count = (int)$getcount;
$count++;
if($count != 0){
$chgfile = $count."_answer.txt";
$myfile = fopen("../../getperansfile/".$empid."/".$chgfile, "w") or die("Unable to open file!");
fwrite($myfile, $file);
fclose($myfile);
		}
//result
		$stafflevel = mysql_query("select * from emp_job_data where emp_id='$empid' AND job_id BETWEEN 1 AND 4", $connection);
		$staffrow = mysql_num_rows($stafflevel);
		$visorlevel = mysql_query("select * from emp_job_data where emp_id='$empid' AND job_id BETWEEN 5 AND 7", $connection);
		$visorrow = mysql_num_rows($visorlevel);
		$manalevel = mysql_query("select * from emp_job_data where emp_id='$empid' AND job_id BETWEEN 8 AND 11", $connection);
		$manarow = mysql_num_rows($manalevel);
		$wpgperget = "";
		$wpaperget = "";
		
		if ($staffrow == 1){
		//WPG
		$wpgper = mysql_query("select percent from org_percent where org_percent_id = 1", $connection);
		$wpgrow = mysql_fetch_assoc($wpgper);
		$wpgperget =$wpgrow['percent'];
		//WPA
		$wpaper = mysql_query("select percent from org_percent where org_percent_id = 2", $connection);
		$wparow = mysql_fetch_assoc($wpaper);
		$wpaperget =$wparow['percent'];
		}
		else if ($visorrow == 1){
		//WPG
		$wpgper = mysql_query("select percent from org_percent where org_percent_id = 3", $connection);
		$wpgrow = mysql_fetch_assoc($wpgper);
		$wpgperget =$wpgrow['percent'];
		//WPA
		$wpaper = mysql_query("select percent from org_percent where org_percent_id = 4", $connection);
		$wparow = mysql_fetch_assoc($wpaper);
		$wpaperget =$wparow['percent'];
		}
		else if ($manarow == 1){
		//WPG
		$wpgper = mysql_query("select percent from org_percent where org_percent_id = 5", $connection);
		$wpgrow = mysql_fetch_assoc($wpgper);
		$wpgperget =$wpgrow['percent'];
		//WPA
		$wpaper = mysql_query("select percent from org_percent where org_percent_id = 6", $connection);
		$wparow = mysql_fetch_assoc($wpaper);
		$wpaperget =$wparow['percent'];
		}
		
		$sqlname = mysql_query("select emp_name from emp_personal_data where emp_id = $empid", $connection);
		$namerow = mysql_fetch_assoc($sqlname);
		$fullname =$namerow['emp_name'];
		
		$computewpg = ($wpgscoreget*$wpgperget)/100;
		$computewpa = ($wpascoreget*$wpaperget)/100;
		$mergewpgscore = round($wpgscoreget, 2)." | ".round($computewpg, 2);
		$mergewpascore = round($wpascoreget, 2)." | ".round($computewpa, 2);
		$numresult2 = $computewpg + $computewpa;
		$numresult = round((float)$numresult2, 2);
		$wordresult = "";
		//substandard
			$countnor = 0;
			$incper = 0;
			$substart = 1.01;
			$marstart = 1.27;
			$norstart = 2.02;
			$nor2start = 2.51;
			$prostart = 3.02;
			$pro2start = 3.61;
			$exestart = 3.77;
			
		if ($numresult >= 1.00 && $numresult <= 1.25){
			$incper = -6.83;
			while ($numresult >= $substart){
			$substart+=.01;
			$incper+=.05;
			} 
			$wordresult = "Substandard";}
			//Marginal
		else if ($numresult >= 1.26 && $numresult <= 2.00){
			$incper = -5.53;
			while ($numresult >= $marstart){
			$substart+=.01;
			$incper+=.05;
			}
			$wordresult = "Marginal";}
			//Normative

		else if ($numresult >= 2.01 && $numresult <= 2.49){
			$incper = -1.78;
			while ($numresult >= $norstart){
			$norstart+=.01;
			$incper+=.05;
			}
			$wordresult = "Normative";}
		else if ($numresult >= 2.5 && $numresult <= 3.00){
				$incper = .67;
			while ($numresult >= $nor2start){
				if($countnor == 0){
			$nor2start+=.01;
			$incper+=.08;
			$countnor+=1;
			}
				else {
			$nor2start+=.01;
			$incper+=.07;
			$countnor-=1;
			}
			}
			$wordresult = "Normative";}	
			//proficient
			
		else if ($numresult >= 3.01 && $numresult <= 3.59){
			$incper = 4.50;	
			while ($numresult >= $prostart){
				if($countnor == 0){
			$prostart+=.01;
			$incper+=.08;
			$countnor+=1;
			}
				else {
			$prostart+=.01;
			$incper+=.07;
			$countnor-=1;
			}
			} 
			$wordresult = "Proficient";}
		else if ($numresult >= 3.60 && $numresult <= 3.75){
			$incper = 8.05;
			while ($numresult >= $pro2start){
			$pro2start+=.01;
			$incper+=.05;
			}
			$wordresult = "Proficient";}
			//exemplary
		else if ($numresult >= 3.76 && $numresult <= 4.00){
			$incper = 8.85;
			while ($numresult >= $exestart){
			$exestart+=.01;
			$incper+=.05;
			}
			$wordresult = "Exemplary";}
			
			
		$getsal = mysql_query("select current from emp_job_data where emp_id= '$empid'", $connection);
		$getsalrow = mysql_fetch_assoc($getsal);
		$sal = $getsalrow['current'];
		$exsal = str_replace(",","",$sal);		
				$consal = (float)$exsal;		

		$salinc = ($consal*$incper)/100;
		$addinc = $consal + $salinc;
		$recsal = number_format((float)$addinc, 2, '.', ',');;
			
			//WPG Score
		//	$stmt = $db_con->prepare("UPDATE getper_ans SET WPG_score=:sco WHERE per_id=:id");
		//	$stmt->bindParam(":sco", $wpgscore);
		//	$stmt->bindParam(":id", $per_id);
			
			//Employee Job Data
			
			$stmt2 = $db_con->prepare("UPDATE emp_job_data SET per_category=:per , rec_salary=:rec WHERE emp_id=:id");
			$stmt2->bindParam(":per", $wordresult);
			$stmt2->bindParam(":rec", $recsal);
			$stmt2->bindParam(":id", $empid);
			if($stmt2->execute())
			{		
			}
			else{
				echo "Query Problem";
			}		
		
		
		try{
			
			$stmt = $db_con->prepare("INSERT INTO getper_ans(emp_id, WPG_cal, WPA_cal, WPG_score, WPA_score, total, result, file, raterid) VALUES(:id, :wpgcal, :wpacal, :wpgscore, :wpascore, :total, :res, :file, :rate)");
			$stmt->bindParam(":id", $empid);
			$stmt->bindParam(":wpgcal", $tabulwpg);
			$stmt->bindParam(":wpacal", $tabulwpa);
			$stmt->bindParam(":wpgscore", $mergewpgscore);
			$stmt->bindParam(":wpascore", $mergewpascore);
			$stmt->bindParam(":total", $numresult);
			$stmt->bindParam(":res", $wordresult);
			$stmt->bindParam(":file", $chgfile);
			$stmt->bindParam(":rate", $raterid);
						
			if($stmt->execute())
			{		
			$getname = mysql_query("select emp_name from emp_personal_data where emp_id= '$empid'", $connection);
			$getnamerow = mysql_fetch_assoc($getname);
			$name = $getnamerow['emp_name'];
			$trail = mysql_query("INSERT INTO trail (type, per_action, description, emp_id) VALUES ('OPMS Form', 'RATED', '$name', '$user_check')", $connection);
			echo "Creating printable page...";
			}
			else{
				echo "Query Problem";
			}	
		}
		catch(PDOException $e){
			echo $e->getMessage();
		}
		}
?>