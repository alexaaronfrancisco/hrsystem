<?php
include('../../session.php');
$id_sql=mysql_query("select emp_id from emp_personal_data where emp_id='$user_check'", $connection);
$rowid = mysql_fetch_assoc($id_sql);
$login_id =$rowid['emp_id'];
$name_sql=mysql_query("select emp_name, fname from emp_personal_data where emp_id='$user_check'", $connection);
$row2 = mysql_fetch_assoc($name_sql);
$login_name =$row2['emp_name'];
$getthename =$row2['fname'];

$tit_sql=mysql_query("select title from emp_job_data INNER JOIN emp_personal_data ON emp_personal_data.emp_id=emp_job_data.emp_id where emp_personal_data.emp_id='$user_check'", $connection);
$rowtit = mysql_fetch_assoc($tit_sql);
$login_title = $rowtit['title'];
$date = date('F d, Y');
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<title>Work Performance Appraisal</title>
<!--<link href="bootstrap/css/bootstrap.min.css" rel="stylesheet" media="screen">-->
<!--<link href="bootstrap/css/bootstrap-theme.min.css" rel="stylesheet" media="screen"> -->
  <link rel="shortcut icon" href="../../img/logo.ico" type="image/x-icon">
<link href="../../assets/datatables.min.css" rel="stylesheet" type="text/css">
    <link href="../../bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css"/>
	    <link href="../../bootstrap/css/sidebar.css" rel="stylesheet" type="text/css"/>
<script src="../../bootstrap/js/bootstrap.js"></script>
<script src="../../bootstrap/js/jquery-1.12.0.js"></script>
<script src="../../bootstrap/js/bootstrap.min.js"></script>
	    <link href="bootstrap-datepicker.css" rel="stylesheet" type="text/css"/>
		<script src="bootstrap-datepicker.min.js"></script>
<script type="text/javascript">

 $(document).ready(function(){
var startDate = new Date();
var fechaFin = new Date();
var FromEndDate = new Date();
var ToEndDate = new Date();


$('.from').datepicker({
    autoclose: true,
	minViewMode: 1,
	startDate: 'January 2016',
    format: 'MM yyyy'
}).on('changeDate', function(selected){
        startDate = new Date(selected.date.valueOf());
        startDate.setDate(startDate.getDate(new Date(selected.date.valueOf())));
        $('.to').datepicker('setStartDate', startDate);
    }); 
	
	$('.to').datepicker({
    autoclose: true,
    minViewMode: 1,
    format: 'MM yyyy'
}).on('changeDate', function(selected){
        FromEndDate = new Date(selected.date.valueOf());
        FromEndDate.setDate(FromEndDate.getDate(new Date(selected.date.valueOf())));
        $('.from').datepicker('setEndDate', FromEndDate);
    });
});


var count1 = 0;
var count2 = 0;
var count3 = 0;
var count4 = 0;

$(document).ready(function(){
    $('[data-toggle="tooltip"]').tooltip({ trigger: "hover" });
	  		window.scrollTo(0,0);			
			//keyup
$('#start').attr('disabled', 'disabled');
$('#names').keyup(function(){
if ($('#names').val() == '') {
count1 = 0;
$("#names").css("border","red solid 1px");
$('#start').attr('disabled', 'disabled');
            }
else {
$("#checked").hide();
$("#names").css("border","grey solid 1px");
count1 = 1;
 if (count1 == 0 || count2 == 0 || count3 == 0 || count4 == 0){
  $('#start').attr('disabled', 'disabled');}
  else{
  $('#start').removeAttr('disabled', 'disabled');
  }
 }
 });     
 
 $('#purpose').keyup(function(){
 count2 = 0;
if ($('#purpose').val() == '') {
$("#purpose").css("border","red solid 1px");
$('#start').attr('disabled', 'disabled');
            }
else {
$("#purpose").css("border","grey solid 1px");
  count2 = 1;
   if (count1 == 0 || count2 == 0 || count3 == 0 || count4 == 0){
  $('#start').attr('disabled', 'disabled');}
  else{
  $('#start').removeAttr('disabled', 'disabled');
  }
 }
 }); 
 
  $('#fmonth').change(function(){
 count3 = 0;
if ($('#fmonth').val() == '') {
$("#fmonth").css("border","red solid 1px");
$('#start').attr('disabled', 'disabled');
            }
else {
  count3 = 1;
   if (count1 == 0 || count2 == 0 || count3 == 0 || count4 == 0){
  $('#start').attr('disabled', 'disabled');}
  else{
  $('#start').removeAttr('disabled', 'disabled');
  }
 }
 }); 
 
  $('#tmonth').change(function(){
 count4 = 0;
if ($('#tmonth').val() == '') {
$("#tmonth").css("border","red solid 1px");
$('#start').attr('disabled', 'disabled');
            }
else {
  count4 = 1;
   if (count1 == 0 || count2 == 0 || count3 == 0 || count4 == 0){
  $('#start').attr('disabled', 'disabled');}
  else{
  $('#start').removeAttr('disabled', 'disabled');
  }
 }
 }); 

$("#wpgdone").click(function(){
window.scrollTo(0,0);
$(".loader").fadeIn();
$("input[type='radio']").attr('disabled', 'disabled');
$("input[name='cho0']").removeAttr('disabled', 'disabled');
$("#wpg").fadeOut();
setTimeout(
  function() 
  {
$("#square0").fadeIn();
  }, 1000);
setTimeout(
  function() 
  {
$(".loader").fadeOut();
  }, 2000);

});
 
/*
  $("#start").click(function(e){
  var name = $('#names').val();
 $.ajax(
    {
    url: "check.php",
    type: "POST",
    data: { typeahead : name },
    success: function(result) {
	$(".loader").fadeIn();
	if (result == "Loading..."){
	$("#checked").html("<span class='text text-success'><span class='glyphicon glyphicon-ok'></span>&nbsp;&nbsp;"+result+"</span");
	$("#names").css("border","green solid 1px");
	setTimeout(function(){
	$(".tago").fadeOut();
			$(".bs-example").fadeOut();
			$("#checked").fadeOut();			
    }, 2000); 
					  setTimeout(
  function() 
  {
$(".loader").fadeOut();
  }, 2000);
				$("#wpg").fadeIn();
				$("#info").fadeIn();
}
else{
	$("#checked").html("<span class='text text-danger'><span class='glyphicon glyphicon-remove'></span>&nbsp;&nbsp;"+result+"</span>");
	$("#names").css("border","red solid 1px");
	}
	setTimeout(
  function() 
  {
	$(".loader").fadeOut();
  }, 2000);
  
    }
});
   });


*/

});


$(window).load(function() {
	$(".loader").fadeOut("slow");
})


//keyup



</script>
<style>
@import url('https://fonts.googleapis.com/css?family=Tauri');
body{font-family: 'Tauri', sans-serif;}
.title{font-size:18px;
padding-bottom: 20px;
color: #0066CC;
width:100%;}

@page{
size:Letter;
}
@media print {
#page-content-wrapper{
top:0;
}
#print {
display:none;
} 
 
.sidebar-nav, #footer{
display:none;}

#wrapper.toggled, #sidebar-wrapper{
padding-left:0px;
}
 
  body * {
    visibility: hidden;
  }
  #fullprint, #fullprint * {
    visibility: visible;
  }
  #fullprint {
  	width:100%;
    position: absolute;
    left: 0;
    top: 0;
	page-break-after:auto	
  }
/*
 #fullprint {
 width:100%;
 padding-right:60px;
 border-left:1px solid #fff;
 border-right:1px solid #fff;
 position: absolute;
 min-height:100%;
 z-index:-1;
*/
  
  #quesprint{
  width:100%;
  position: static;
}
}
#result{
	display: none;
	margin-left: 70px;
	position: fixed;
	top: 50px;
	width: 68%;
	padding:20px;
	z-index:99999;
}


.footer {
z-index:2;
width:100%;
position:fixed;
display: block;
  right: 0;
  bottom: 0;
  left: 0;
  font-size:12px;
  padding: 1rem;
  background-color: #efefef;
  text-align: right;}
  
  .loader {
	position: fixed;
	left: 0px;
	top: 0px;
	width: 100%;
	height: 100%;
	z-index: 9999;
	background: url('../../img/loading.gif') 50% 50% no-repeat rgb(249,249,249);
	opacity: .5;
}

  .icon {
  float:left;
  display:block;
  padding-top: 10px;
  }
  
  .back {
  display:none;
  border:none;
  }
  .add {
  border:none;
border-radius: 100%;
padding-top:15px;
padding-bottom: 17px;
padding-left: 17px;
padding-right: 15px;
font-size:24px;

}
.add:focus{
outline: 0px;
}
.sidebar-brand{
background-color:#FFFFFF;
}
.sidebar-brand img {
width: 225px;
height:57px;

}
#salary {
padding-left:10px;
padding-right:10px;
}

#optradio{
width:15px;
height:15px;
}

.square {
background-color: #FFFFFF;
margin-top:20px;
-webkit-box-shadow: 0px 0px 2px rgba(50, 50, 50, 0.31);
    -moz-box-shadow:    0px 0px 5px rgba(50, 50, 50, 0.31);
    box-shadow:         0px 0px 10px rgba(50, 50, 50, 0.31);
padding:20px;

 }
#jobtitle {
padding-left:10px;
padding-right:10px;
padding-top:10px;
padding-bottom:10px;
font-size:16px;
 }
 
.radiobtn{
width:30px;
height:20px;
bottom:1px;
}


#forhr hr {
    display: block;
    height: 1px;
    border: 0;
    border-top: 1px solid #000;
    margin: 2em 0;
    padding: 0; 
}

table .table {
style='border:#000 1px solid;
}


.drop {
font-size:12px;
background-color:#111;
display:none;
 text-indent: 30px;
    line-height: 30px;
}

.drop2 {
font-size:12px;
background-color:#111;
display:none;
 text-indent: 30px;
    line-height: 30px;
}

.drop3 {
font-size:12px;
background-color:#111;
display:none;
 text-indent: 30px;
    line-height: 30px;
}

.drop4 {
font-size:12px;
background-color:#111;
display:none;
 text-indent: 30px;
    line-height: 30px;
}

.drop5 {
font-size:12px;
background-color:#111;
display:none;
 text-indent: 30px;
    line-height: 30px;
}

#start:focus{
outline: 0px;
}

  @media only screen and (max-width: 768px) 
{ 
.footer {
margin-top: 50px;
width:100%;
position: relative;
font-size: 10px;

background-color: #fff;
}

.sidebar-brand img {
width: 190px;
height:45px;

}
#result{
	top: 75px;
	margin-left: 0;
	width:70%
}

#footer{
display:none;
visibility:hidden;
}

}

</style>


</head>

<body>
<!------------------------------------------->
<div class="loader"></div>
<br /><br />

<!-- Modal -->

  <div class="modal fade" id="modalreset" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h3 class="modal-title text-primary"><span class="glyphicon glyphicon-refresh"> </span> Reset</h3>
        </div>
        <div class="modal-body">
		<br />
          <p>Do you want reset all data and start a new form?</p>
        </div>
        <div class="modal-footer">
		  <button type="button" id="no" value="no" data-dismiss="modal" class="btn btn-default" > No </button>
		  <button type="button" id="yes" value="yes" class="btn btn-primary" autofocus > Yes </button>
		
        </div>
      </div>
      
    </div>
  </div>

  <!-- Sidebar -->
		<div class="stat" style="position:static;">
		<div class="sticktop" style="top:0; display:block; position: fixed; z-index:1000; right:0; left:0;">
		<div id="hideprint">
		<div class="sidebar-brand">
                    <a href="#">
                       <img src="../../img/logo.jpg"> 
                    </a>
                </div>
				<div class="drops">
		<div class="dropdowntogs">
                <a href="#"><span class="glyphicon glyphicon-user"> </span> &nbsp;<b>Welcome,</b> <?php echo $getthename ?></a></div>
				<div class="dropmenu">
<!---				<a href="#"><span class="glyphicon glyphicon-wrench"> </span> Edit Profile</a><div></div>--->
				<a href="chgpass.php"><span class="glyphicon glyphicon-lock"> </span> Change Password</a>
				<hr></hr>
				<a href="../../logout.php"><span class="glyphicon glyphicon-log-out"> </span> Log-out</a>
				</div>
				</div>							
				
		<div class="toggles"><a href="#menu-toggle" id="menu-toggle"><span class="glyphicon glyphicon-menu-hamburger" style="opacity:0px;"></span></a></div>       
                </div>
				</div>
				</div>
				
        <!-- /#sidebar-wrapper -->
        <!-- Page Content -->
<!--table--->				
        <div id="page-content-wrapper">
            <div class="container-fluid">
<div id="tit"><center><h3>ORGANIZATIONAL PERFORMANCE MANAGEMENT SYSTEM</h3><h5>
WPG / WPA PERFORMANCE RATING SHEET <br />
FOR RANK-AND-FILE / STAFF POSITIONS</h5></center>
<hr />
</div>
<?php 
$checked = "";
$names = "";
$rankid_entry = 0;
if (isset($_POST['wpg'])) {
$names = $_POST['typeahead'];
$period = $_POST['fmonth']." - ".$_POST['tmonth'];
$purpose = $_POST['purpose'];
$problem = false;
$name_sql=mysql_query("select emp_id from emp_personal_data where emp_name='$names' AND emp_status NOT LIKE 'inactive'", $connection);
$rowname = mysql_fetch_assoc($name_sql);
$idpos = $rowname['emp_id'];
$pos_sql=mysql_query("select title from emp_job_data where emp_id='$idpos'", $connection);
$rowpos = mysql_fetch_assoc($pos_sql);
$pos = $rowpos['title'];
$rankid_sql=mysql_query("select job_id from emp_job_data where emp_id='$idpos'", $connection);
$rowrank = mysql_fetch_assoc($rankid_sql);
$rankid_entry = $rowrank['job_id'];

 	
	if ($rowname == 0)
		{ 
		$problem = true;
		echo '<style type="text/css">#names { border: 1px solid red;}</style>';
		$checked = "<span class='text text-danger' id='checked'><span class='glyphicon glyphicon-remove'></span>&nbsp;&nbsp;Employee name does not exist!</span>";
		}
	if (empty($_POST['fmonth'])){
		$problem = true;
		echo '<style type="text/css">#fmonth { border: 1px solid red;}</style>';
	}
		if (empty($_POST['tmonth'])){
		$problem = true;
		echo '<style type="text/css">#tmonth { border: 1px solid red;}</style>';
	}
    // collect value of input field
	if (!$problem) {
			echo '<style type="text/css">#wpg { display:block;}</style>';
			echo '<style type="text/css">.tago { display:none;}</style>';			
			$checked = "<span class='text text-success'><span class='glyphicon glyphicon-ok'></span>&nbsp;&nbsp;Loading...</span>";
$wpg_sql=mysql_query("select emp_id from emp_personal_data where emp_name='$names'", $connection);
$rowwpg = mysql_fetch_assoc($wpg_sql);
$wpg_id =$rowwpg['emp_id'];

//CHECKING NAME
$wpgcheck_sql=mysql_query("select emp_id from wpg_percent where emp_id='$wpg_id'", $connection);
$rowcheck = mysql_num_rows($wpgcheck_sql);

//tanong
$wpgtanong_sql=mysql_query("select goal from wpg_percent where emp_id='$wpg_id'", $connection);
$rowtanong = mysql_fetch_assoc($wpgtanong_sql);
$wpgtanong_entry =$rowtanong['goal'];
$convert_wpgtanong=explode(" + ",$wpgtanong_entry);
$wpgtanongcount = count($convert_wpgtanong);

//choices
$wpgcho_sql=mysql_query("select choices from wpg_percent where emp_id='$wpg_id'", $connection);
$rowchowpg = mysql_fetch_assoc($wpgcho_sql);
$wpgcho_entry =$rowchowpg['choices'];
$convert_wpgcho=explode(" + ",$wpgcho_entry);

//value
$wpgval_sql=mysql_query("select value from wpg_percent where emp_id='$wpg_id'", $connection);
$rowval = mysql_fetch_assoc($wpgval_sql);
$wpgval_entry =$rowval['value'];
$convert_wpgval=explode(", ",$wpgval_entry);

?>
<table id="info" class="table table-bordered"> 
<tr>
<td><b>Employee's Name:</b></td>
<td><b>Position / Title:</b></td>
<td><b>Appraisal Period:</b></td>
</tr>
<tr>
<td><?php echo $names; ?></td>
<td><?php echo $pos; ?></td>
<td><?php echo $period; ?></td>
</tr>
<tr>
<td><b>Purpose of the Appraisal</b></td>
<td style="border-left:2px solid white;"></td>
<td><b>Rater:</b></td>
</tr>
<tr>
<td><?php echo $purpose; ?></td>
<td style="border-left:2px solid white;"></td>
<td><?php echo $login_name; ?></td>
</tr>
</table>
<div id="wpg" class="square">
<h3 align="center" style="width:100%; color:#FFFFFF; background-color:#000000; padding-bottom:10px; padding-top:10px;">PART 1: Work Performance Goals</h3>
This Work Performance Goals (WPG) Rating Sheet is designed to aid the rater/s in appraising the quantitative dimension of the employee’s work performance. Using 4-tiered pre-set performance levels, it aids the rater/s to evaluate and determine objectively the level of employee’s work performance in each of the pre-defined performance goals. Likewise, it aids the employee to find direction and guidance in tapping available resources such as one’s own talent, abilities, knowledge, skills, time, materials provided, and the likes to productive use.
<hr />
<?php
$goalcount = 0;
$wpgchocount = 0;
$g = 0;
if($rowcheck == 1){
		 while ($goalcount < $wpgtanongcount){
$valdown = 4;			
		?>
						 
<label><?php echo $convert_wpgtanong[$g];?>&nbsp;<span title="wpgcho<?php echo $g; ?>" class="glyphicon glyphicon-ok" style="color:#009900; display:none; font-size:16px;"></span></label>
<br /><br />
<table class="table table-bordered">
<?php
while (0 != $valdown){ ?>
<tr><td style="width:5%;"><input type="radio" tabindex="wpg"  lang="<?php echo $convert_wpgcho[$wpgchocount]; ?>" data-toggle="tooltip" data-placement="bottom" id='<?php echo $wpgchocount; ?>' name='wpgcho<?php echo $g; ?>' alt='<?php echo $valdown; ?>' class="radiobtn" placeholder='<?php echo $convert_wpgtanong[$g]; ?>' value='<?php echo $convert_wpgval[$g]; ?>' required /></td>
<td><?php echo $convert_wpgcho[$wpgchocount]; ?></td></tr>
<?php $wpgchocount++; $valdown--; }?>
</table>
<?php
$goalcount++;
$g++;
    }
	
	?>

<button name="wpa" class="btn btn-primary" id="wpgdone" disabled="disabled" data-toggle="tooltip" data-placement="right" title="Proceed to WPA" value="Proceed to WPA">Proceed to WPA</button>

<?php

}
else{
?>
<h5 style="color:#FF0000">Work Performance Goal(WPG) is not been set to employee, to set WPG go to menu bar, under "OPMS" Section click "Manage WPG". If you want to continue without WPG click the button below.</h5><br />
<button name="wpa" class="btn btn-primary" id="wpgdone" data-toggle="tooltip" data-placement="right" title="Proceed to WPA" value="Proceed to WPA">Proceed to WPA</button>
<?php }?> 
</div>
<?php
}
}?>
<div class="tago">

<h4>GENERAL INSTRUCTIONS: </h4>
<ol style=" font-size:14px;">
  <li>Fill-up the form below and click start.</li>
  <li>Choose in the Radio Button the corresponding actual achievement.</li>
  <li>Proceed to rate employee on Part II: Work Performance Attributes(WPA) and print the result.</li>
  <li>Accomplish Part III: Employee’s Feedback and Part IV: Superior’s Development Plan.</li>
  <li>Submit to HRD</li>
</ol> 
<div class="square">
<i class="glyphicon glyphicon-user"></i> <b> Select Employee Name </b>
<?php include('typesearch.html'); ?>
  <div class=".col-md-6">
    <div class="bs-example">
<form id="wpg" action="" name="wpg" method="post" >
<input type="text" name="typeahead" id="names" class="typeahead tt-query"  autocomplete="off" spellcheck="false" placeholder="Enter employee name">
<input type="hidden" name="names"  id="getname">

</div>
</div>
<?php echo $checked; ?>
<div class="row">
<br />
	  		  <div class="col-md-3">
             	<b>Appraisal Period From </b>
			  <div class="input-group">
			  <span class="input-group-addon"><i class="glyphicon glyphicon-calendar"></i></span>
            <input type='text' name='fmonth' id="fmonth" class='from btn btn-default' placeholder='Month and Year' readonly="true" data-behavior="datepicker" required> 
         </div>
		 </div> 
	  		  <div class="col-md-3">
             	<b>Appraisal Period To</b>
			  <div class="input-group">
			  <span class="input-group-addon"><i class="glyphicon glyphicon-calendar"></i></span>
             <input type='text' name='tmonth' id="tmonth" class='to btn btn-default' placeholder='Month and Year' readonly="true" data-behavior="datepicker" required> 
			 
         </div>	 		 
</div>
</div><br />
<div class="row">
	  		  <div class="col-md-7">
             	<b>Purpose of the Appraisal</b>
			  <div class="input-group">
			  <span class="input-group-addon"><i class="glyphicon glyphicon-comment"></i></span>
             <input type='text' name='purpose' id="purpose" class='form-control' placeholder='' required> 
			 </div>
</div>
</div>
<br />
<input type="submit" name="wpg" class="btn btn-primary" id="start" data-toggle="tooltip" data-placement="right" title="Start" value="Start" style="position: relative; border-radius:100%; padding:20px;" />
</form> 

</div>
</div>
   <div id="result">
    <!-- here message will be displayed -->
	</div>
<!--- <form id='jbrate' name="jbrate" action="" method="post">
  <p>Enter Job Title <input type="text" name="jobtitle" id="jobtitle" value="" style="width:30%;" placeholder="Encoder" maxlength="50" required/>  <button class="btn btn-primary" id="start" disabled="disabled"  data-toggle="tooltip" data-placement="right" title="Start" >Start</button> </p>
---->

<?php	

if($rankid_entry <= 4){
$a = 1;
$rankcategory = 'Staff';}
else if ($rankid_entry <= 7){
$a = 4;
$rankcategory = 'Supervisor';}
else{
$a = 8;
$rankcategory = 'Manager';}

$count_sql=mysql_query("select * from wpa_percent where rank_cat='$rankcategory'", $connection);
$row5 = mysql_num_rows($count_sql);
$c = 0;
$b = 0;
//$a = 1;
$z = 0;	
$countnextarray = array();
while ($b < $row5){
$rating_id = $a;
//category
$cat_sql=mysql_query("select category from wpa_percent where wpa_percent_id='$rating_id'", $connection);
$row6 = mysql_fetch_assoc($cat_sql);
$cat_entry =$row6['category'];
//tanong
$tanong_sql=mysql_query("select question from wpa_percent where wpa_percent_id='$rating_id'", $connection);
$row8 = mysql_fetch_assoc($tanong_sql);
$tanong_entry =$row8['question'];
$convert_tanong=explode(" + ",$tanong_entry);
$convert_ques = $convert_tanong;
//description
$subcat_sql=mysql_query("select descrip from wpa_percent where wpa_percent_id='$rating_id'", $connection);
$row7 = mysql_fetch_assoc($subcat_sql);
$subcat =$row7['descrip'];
$subcat_entry=explode(" + ",$subcat);
//question
$choice_sql=mysql_query("select choices from wpa_percent where wpa_percent_id='$rating_id'", $connection);
$rowcho = mysql_fetch_assoc($choice_sql);
$choice =$rowcho['choices'];
$choice_entry=explode(" + ",$choice);
//values
$ques_val=mysql_query("select percent from wpa_percent where wpa_percent_id='$rating_id'", $connection);
$row4 = mysql_fetch_assoc($ques_val);
$val_entry =$row4['percent'];
$convert_val=explode(", ",$val_entry);
$countarr = count($convert_ques);
array_push($countnextarray, $countarr);
$x = 0;
$y = 0;

?>

<div id="square<?php echo $b; ?>" class="square" style="display:none;">
<div id="wpa">
<h3 align="center" style="width:100%; color:#FFFFFF; background-color:#000000; padding-bottom:10px; padding-top:10px;">PART 1: Work Performance Attribute</h3>
This Work Performance Attribute (WPA) Rating Sheet is designed to aid the rater/s in appraising the qualitative dimension of the employee’s work performance. Using descriptive method, it presents a 4-level continuum of concrete, overt, observable, or reality-based behaviors or performance manifestations that can help the rater/s maintain objectivity in ascribing the appropriate attributes to employee’s work performance.</div><br />
<h4 id="questitle<?php echo $b; ?>" style="color:#0000FF;"><?php echo $cat_entry;?></h4>

<hr />
<?php
$chocount = 0;
		 while ($x < $countarr){
			
		?>
		
	
				 
<label><?php echo $convert_ques[$y];?>&nbsp;<span title="cho<?php echo $z; ?>" class="glyphicon glyphicon-ok" style="color:#009900; display:none; font-size:16px;"></span>
<h6 style="color:#333333;"><?php echo $subcat_entry[$y];?></h6></label>
<table class="table table-bordered">
<tr><td style="width:5%"><input type="radio" tabindex="wpa" lang="<?php echo $choice_entry[$chocount]; ?>" data-toggle="tooltip" data-placement="bottom" id='<?php echo $z; ?>' name='cho<?php echo $z; ?>' alt="4" class="radiobtn" placeholder='<?php echo $convert_ques[$y]; ?>' value='<?php echo $convert_val[$y]; ?>' required /></td>
<td> <?php echo $choice_entry[$chocount]; ?></td></tr>

<?php $chocount++; ?>

<tr><td style="width:5%"><input type="radio" tabindex="wpa" lang="<?php echo $choice_entry[$chocount]; ?>" data-toggle="tooltip" data-placement="bottom" id='<?php echo $z; ?>' name='cho<?php echo $z; ?>' alt="3" class="radiobtn" placeholder='<?php echo $convert_ques[$y]; ?>' value='<?php echo $convert_val[$y]; ?>' required /></td>
<td><?php echo $choice_entry[$chocount]; ?></td></tr>

<?php $chocount++; ?>

<tr><td style="width:5%"><input type="radio" tabindex="wpa" lang="<?php echo $choice_entry[$chocount]; ?>" data-toggle="tooltip" data-placement="bottom" id='<?php echo $z; ?>' name='cho<?php echo $z; ?>' alt="2" class="radiobtn" placeholder='<?php echo $convert_ques[$y]; ?>' value='<?php echo $convert_val[$y]; ?>' required /></td>
<td><?php echo $choice_entry[$chocount]; ?></td></tr>

<?php $chocount++; ?>

<tr><td style="width:5%"><input type="radio" tabindex="wpa" lang="<?php echo $choice_entry[$chocount]; ?>"s data-toggle="tooltip" data-placement="bottom" id='<?php echo $z; ?>' name='cho<?php echo $z; ?>' alt="1" class="radiobtn" placeholder='<?php echo $convert_ques[$y]; ?>' value='<?php echo $convert_val[$y]; ?>' required /></td>
<td><?php echo $choice_entry[$chocount]; ?></td></tr>

<?php $chocount++; ?>
</table>
<br />
<?php 

$x++;
$y++;
$z++;
}

if ($b != 0){?>
<!---<button class="btn btn-default" name="baliklaman" data-toggle="tooltip" data-placement="bottom" title="Previous Question" value="#square<?php //echo $b;?>" id="#square<?php //echo $c;?>">Previous</button>--->
<?php 
echo '<script>$("#square'.$b.'").hide();</script>';}
$a++;
$b++;
if ($b == $row5){?>
<button class="btn btn-primary" name="tapos" data-toggle="tooltip" data-placement="bottom" title="Finish"  disabled="disabled" value="#square<?php echo $b;?>" id="#square<?php echo $c;?>">Finish</button><button class="btn btn-default" name="ulit" data-toggle="tooltip" data-placement="right" title="Reset">Reset</button>
</div>
<?php } else { ?>
<button class="btn btn-primary" name="pasalaman" data-toggle="tooltip" data-placement="bottom" title="Next Question"  disabled="disabled" value="#square<?php echo $b;?>" id="#square<?php echo $c;?>">Next</button>
<button class="btn btn-default" name="ulit" data-toggle="tooltip" data-placement="right" title="Reset">Reset</button>
</div>
<?php
$c++;
} 
}
$countradio = 0;?>     

<!--------- PRINT AREA --------------------->
<button class="btn btn-primary" id="print" style="display:none;" data-toggle="tooltip" data-placement="bottom" title="Print Result"><span class="glyphicon glyphicon-print"></span> Print</button>
<div id="fullprint" style="display:none;">
<center><img src="../../img/logo.jpg" id="logo" width="180px" height="48px" />
<h3>ORGANIZATIONAL PERFORMANCE MANAGEMENT SYSTEM</h3><h5>
WPG / WPA PERFORMANCE RATING SHEET <br />
FOR RANK-AND-FILE / STAFF POSITIONS</h5></center>
<table class="table table-striped"> 
<tr>
<td><b>Employee's Name:</b></td>
<td><b>Position / Title:</b></td>
<td><b>Appraisal Period:</b></td>
</tr>
<tr>
<td><?php echo $names; ?></td>
<td><?php echo $pos; ?></td>
<td><?php echo $period; ?></td>
</tr>
<tr>
<td><b>Purpose of the Appraisal</b></td>
<td></td>
<td><b>Rater:</b></td>
</tr>
<tr>
<td><?php echo $purpose; ?></td>
<td></td>
<td><?php echo $login_name; ?></td>
</tr>
</table>

<!--<center><img src="../../img/logo.jpg" id="logo" style="display:none;" width="180px" height="48px" /></center>
<center style="color:#0000FF; font-size:20px; margin-bottom:20px;">ORGANIZATIONAL PERFORMANCE MANAGEMENT SYSTEM<br />Work Performance Attributes for Staff</center>-->
<div id="quesprint"></div>
</div>

<script type="text/javascript">

    $("#menu-toggle").click(function(e) {
        e.preventDefault();
        $("#wrapper").toggleClass("toggled");
    });	    
	    $(".main").click(function(e) {
        e.preventDefault();
        $(".drop").slideToggle();
		$(".drop2").slideUp();
		$(".drop3").slideUp();
		$(".drop4").slideUp();
		$(".drop5").slideUp();
    });
		$(".ijsm").click(function(e) {
        e.preventDefault();
        $(".drop2").slideToggle();
		$(".drop").slideUp();
		$(".drop3").slideUp();
		$(".drop4").slideUp();
		$(".drop5").slideUp();
    });
	    $(".opms").click(function(e) {
        e.preventDefault();
        $(".drop3").slideToggle();
		$(".drop").slideUp();
		$(".drop2").slideUp();
		$(".drop4").slideUp();
		$(".drop5").slideUp();
    });
		$(".rprt").click(function(e) {
        e.preventDefault();
        $(".drop4").slideToggle();
		$(".drop").slideUp();
		$(".drop2").slideUp();
		$(".drop3").slideUp();
		$(".drop5").slideUp();
    });
		$(".util").click(function(e) {
        e.preventDefault();
        $(".drop5").slideToggle();
		$(".drop").slideUp();
		$(".drop2").slideUp();
		$(".drop3").slideUp();
		$(".drop4").slideUp();
    });	   
	$(".dropdowntogs").click(function(e) {
        e.preventDefault();
        $(".dropmenu").toggle();
    });
	$(document).click(function(e) {
  if ( $(e.target).closest('.dropdowntogs').length === 0 ) {
    // hide menu here
	$(".dropmenu").hide();
  }
}); 
</script>
<script>
//---------------------------------
var wpgcount = 0;
var wpgaddtot = 0;
var wpgtanongcount = <?php echo $wpgtanongcount; ?>;
var idpos = "<?php echo $idpos; ?>";
var idname = "<?php echo $names; ?>";
var tabulwpg =  "";
var filewpg =  new Array();
var tanongwpg =  new Array();
var piliwpg =  new Array();
$("input[type='radio']").attr("disabled","disabled");

$("input[tabindex='wpg']").click(function(){
//$("input[name='wpgcho"+wpgcount+"']").attr('disabled', 'disabled');
var val = $(this).attr("alt");
var perc = $(this).attr("value");
var cho = $(this).attr("lang");
var radioname = $(this).attr("name");
$("span[title='wpgcho"+wpgcount+"']").show();
$("input[name='"+radioname+"']").attr('disabled','disabled');
var wpgques = $(this).attr("placeholder");
getcompwpg = (val*perc)/100;
tabulwpg += getcompwpg+", ";
tanongwpg.push(wpgques);
piliwpg.push(cho);
wpgaddtot+=getcompwpg;
wpgcount++;
$("input[name='wpgcho"+wpgcount+"']").removeAttr('disabled', 'disabled');
if (wpgcount == wpgtanongcount){
			$('#wpgdone').removeAttr('disabled', 'disabled');
}
			
});
  

    $("button[name='tapos']").click(function(e){
	$(".loader").fadeIn();
  questitle = $("#questitle"+countnextinc).text();
  titlepass.push(questitle);
var file = "WPG Summary Result blank";
	// $('button[name="tapos"]').click(function() {
//			var tittext1 =  $(".field1").text();
// 			var tittext2 =  $(".field2").text();
// 			var tittext3 =  $(".field3").text();
// 			var text1 =  $("textarea[id='field1']").val();
// 			var text2 =  $("textarea[id='field2']").val();
//			 var text3 =  $("textarea[id='field3']").val();
 	var i;
	for (i = 0; i < tanongwpg.length; i++) {
	 file += tanongwpg[i] + " - "+ piliwpg[i]+"blank";
}	
file += "blankblankWPA Summary Result blank";
			 	var u;
			var b=0;
	for (u = 0; u < fulllast.length; u++) {
	if (fulllast[u].charAt(0) == "1")
	{
	 file += "blank"+titlepass[b] + "blankblank";
	 b++;}
	 file += fulllast[u] + " - "+ getans[u]+"blank";
}
//file += "blankPART 3: EMPLOYEE'S FEEDBACK blankblank";
// input text
//file += tittext1+"blank blank"+text1+"blank blank blank";
//file += tittext2+"blank blank"+text2+"blank blank blank";
//file += tittext3+"blank blank"+text3+"blank blank blank";
if(file != ""){
e.preventDefault();
        $.ajax({
            type: "POST",
            url: "create.php", //process to add
            data: {emp_id:empid, rater_id:raterid, wpg_cal:tabulwpg, wpa_cal:tabulwpa, totalwpg:wpgaddtot,  totalwpa:passtotal , getfile:file} ,					
            success: function(data){
			$(".loader").fadeIn();

			$("#result").css('display','block') 
			$("#result").fadeIn('slow') 
		$("#result").html('<div class="alert alert-success"><span class="glyphicon glyphicon-ok">&nbsp;</span>'+data+'</div>');
				     setTimeout(function(){
					 	 	 $('#tit').fadeOut();
		 	 $('#info').fadeOut();
        $("#result").fadeOut();
		$(".square").fadeOut();
    }, 2000); 
	setTimeout(
  function() 
  {
  $("hr").fadeIn();
  $("#print").fadeIn();
  $("#fullprint").fadeIn();
  }, 2000);
					  setTimeout(
  function() 
  {
$(".loader").fadeOut();
  }, 2000);
  
  				  setTimeout(
  function() 
  {
$("#summaryprint").fadeIn();
  }, 2000);
   
	}		  
        });
				window.scrollTo(0,0);}
		});
		
<!---Radio Button disable next---->
 var countnextinc = 0;
 var countadd = 0;
 var titlepass = new Array();
	var questitle;
 $('button[name="pasalaman"]').click(function() {
countadd = countradio;
questitle = $("#questitle"+countnextinc).text();
countnextinc++;
countconvert = countnextstring.charAt(countnextinc);
countradio = parseInt(countconvert);
countradio+=countadd;
titlepass.push(questitle);
		window.scrollTo(0,0);
var returncount = countradio;
 });
/*  $('button[name="baliklaman"]').click(function() {
  countadd = countradio;
countnextinc-=1;
countconvert = countnextstring.charAt(countnextinc);
countradio = parseInt(countconvert);
countadd-=countradio;
});*/

var countrow = <?php echo $row5; ?>;
var loginname = "<?php echo $login_name; ?>";
var logintitle = "<?php echo $login_title; ?>";
var date = "<?php echo $date; ?>";
var empid = "<?php echo $idpos; ?>";
var raterid = "<?php echo $login_id; ?>";
var countnext = <?php echo implode("",$countnextarray); ?>;
var countnextstring = countnext.toString();
var countconvert = countnextstring.charAt(countnextinc);
var countradio = parseInt(countconvert);
		 $('button[name="pasalaman"]').attr('disabled', 'disabled');
		  $('button[name="tapos"]').attr('disabled', 'disabled');
var resetattr = 0;
var fulllast =  new Array();
var vallast =  new Array();
var fullprint =  new Array();
var totalval =  new Array();
var tabulwpa = "";
var getans =  new Array();
var addtotal;
var passtotal = 0;
var countname = 0;
$("input[name='wpgcho0'").removeAttr('disabled', 'disabled');
$("input[type='radio']").attr('disabled', 'disabled');
if (countname == 0){
$("input[name='wpgcho0'").removeAttr('disabled', 'disabled');
$("input[name='cho"+countname+"']").removeAttr('disabled', 'disabled'); } 

$("input[tabindex='wpa']").click(function(){
var idcount = $(this).attr("id");
var ansques = $(this).attr("placeholder");
var valques = $(this).attr("value");
var numberval = $(this).attr("alt");
var radname = $(this).attr("name");
var get = $(this).attr('lang');
/*if (numberval == 4)
var get = "Exemplary";
else if (numberval == 3)
var get ="Proficient";
else if (numberval == 2)
var get ="Normative";
else if (numberval == 1)
var get ="Sub-standard";*/
countname++;
$("input[name='"+radname+"']").attr('disabled', 'disabled');
$("input[name='cho"+countname+"']").removeAttr('disabled', 'disabled');
$("span[title='"+radname+"']").show();
addtotal = (valques*numberval)/100;
tabulwpa += addtotal+", ";
passtotal+=addtotal;

//if($('input[type="radio"][id="'+idcount+'"').is(':checked')){
//if(jQuery.inArray(ansques, fulllast) === -1){
//if (fulllast[fulllast.length-1] != ansques){}
	fulllast.push(ansques);
	vallast.push(valques);
	getans.push(get);
//if($('#1').is(':checked') && $('#2').is(':checked')){
if ($("input[tabindex='wpa']:checked").length == countradio){
			$('button[name="pasalaman"]').removeAttr('disabled', 'disabled');
			$('button[name="tapos"]').removeAttr('disabled', 'disabled');}
			
});
 $('button[name="pasalaman"]').click(function() {
var last = fulllast[fulllast.length - 1];
var lastnum = vallast[vallast.length - 1];
fullprint.push(last);
totalval.push(lastnum);
});
 $("button[name='tapos']").click(function(){
 	 var name = $('#names').val();
	 $('#logo').fadeIn();
 var last = fulllast[fulllast.length - 1];
 var lastnum = vallast[vallast.length - 1];
   questitle = $("#questitle"+countnextinc).text();
  titlepass.push(questitle);
// var tittext1 =  $(".field1").text();
// var tittext2 =  $(".field2").text();
// var tittext3 =  $(".field3").text();
// var text1 =  $("textarea[id='field1']").val();
 //var text2 =  $("textarea[id='field2']").val();
 //var text3 =  $("textarea[id='field3']").val();
fullprint.push(last);
totalval.push(lastnum);
//});
  //	$("#print").click(function(){ 
var i;
var o;
var a=0;

var text = "<table class='table table-bordered'>";
/*	text += "<b>Name:</b> &nbsp;&nbsp;&nbsp;"+loginname+"&nbsp;&nbsp;&nbsp;<b>Position:</b> &nbsp;&nbsp;&nbsp;"+logintitle+"&nbsp;&nbsp;&nbsp<b>Date:</b>&nbsp;&nbsp;&nbsp;"+date+"<br><br>";
	text += "<b>Purpose of Appraisal:</b> <c style='width:10px; height:10px; border:#000 1px solid; margin-right:5px; margin-left:5px;'>&nbsp;&nbsp;&nbsp;&nbsp;</c> For mid-year review <c style='width:10px; height:10px; border:#000 1px solid; margin-right:5px; margin-left:5px;'>&nbsp;&nbsp;&nbsp;&nbsp;</c> For regulazation <c style='width:10px; height:10px; border:#000 1px solid; margin-right:5px; margin-left:5px;'>&nbsp;&nbsp;&nbsp;&nbsp;</c> For promotion <c style='width:10px; height:10px; border:#000 1px solid; margin-right:5px; margin-left:5px;'>&nbsp;&nbsp;&nbsp;&nbsp;</c> Others <br><br><b>Period Range:</b>&nbsp;&nbsp;____________________ &nbsp;&nbsp;&nbsp;<b>Raters:</b> ___________________________________  <br>&nbsp;<br>";*/
	text += "<br><h5>PART 1: WORK PERFORMANCE GOALS RESULT</h5>";
	for (o = 0; o < tanongwpg.length; o++) {
     text += "<tr><td style='width:30%;'>"+tanongwpg[o] + "</td><td>"+ piliwpg[o]+"</td></tr>";
}
    text += "</table><table class='table table-bordered'>";
	text += "<br><h5>PART 2: WORK PERFORMANCE APPRAISAL RESULT</h5>";
for (i = 0; i < fulllast.length; i++) {
	if (fulllast[i].charAt(0) == "1")
	{text += "<tr><td style='width:30%;'><b>" + titlepass[a] + "</b></td><tr>";
	 a++;}
     text += "<tr><td style='width:30%;'>"+fulllast[i] + "</td><td>"+ getans[i]+"</td></tr>";
}
text += "</table><br><h5>PART 3: EMPLOYEE'S FEEDBACK</h5>";
// input text
text += "I. What I like about my job?<br><c id='forhr'><hr></hr><hr></hr><hr></hr><hr></hr></c><br>";
text += "II.  What difficulties do I have in doing my job?<br><c id='forhr'><hr></hr><hr></hr><hr></hr><hr></hr></c><br>";
text += "III. What improvements do I wish to see in the workplace and what support do I need from my superior?<br><c id='forhr'><hr></hr><hr></hr><hr></hr><hr></hr></c><br><br><br>";

text += "<div align='right'>"+idname+"<br><i><b style='font-size:12px;'>Employee's Name and Signature</b></div></i><br><br><c id='forhr'><hr></hr>";

//supervisor input
text += "<h5>PART 4: SUPERVISOR'S PERFORMANCE IMPROVEMENT / ENHANCEMENT PLAN</h5><br>";
text += "I. What are the strengths that I see in the employee?<br><c id='forhr'><hr></hr><hr></hr><hr></hr><hr></hr></c><br>";
text += "II. What improvements or growth do I wish to see in the employee's skills, attitude, and behavior?<br><c id='forhr'><hr></hr><hr></hr><hr></hr><hr></hr></c><br>";
text += "III. What development program should be given to the employee for his growth / improvement?<br><c id='forhr'><hr></hr><hr></hr><hr></hr><hr></hr></c><br><br><br>";
text += "<div align='right'>"+loginname+"<br><i><b style='font-size:12px;'>Rater's Name and Signature</b><br><br></div></i><br><c id='forhr'><hr></hr>";
text += "<h5>PART 5: REFER TO STAFF SCORECARD</h5>";
text += "<h5>PART 6: RECOMMENDED ACTIONS</h5>";
text += "<table><tr><th><c style='width:10px; height:10px; border:#000 1px solid; margin-right:10px; margin-left:10px;'>&nbsp;&nbsp;&nbsp;&nbsp;</c>For regularization of 		          employee</th>";
text += "<th><c style='width:10px; height:10px; border:#000 1px solid; margin-right:10px; margin-left:10px;'>&nbsp;&nbsp;&nbsp;&nbsp;</c>For job transfer</th>";
text += "<th><c style='width:10px; height:10px; border:#000 1px solid; margin-right:10px; margin-left:10px;'>&nbsp;&nbsp;&nbsp;&nbsp;</c>For merit increase</th></tr><br>";
text += "<tr><th><c style='width:10px; height:10px; border:#000 1px solid; margin-right:10px; margin-left:10px;'>&nbsp;&nbsp;&nbsp;&nbsp;</c>For job reclassification</th>";
text += "<th><c style='width:10px; height:10px; border:#000 1px solid; margin-right:10px; margin-left:10px;'>&nbsp;&nbsp;&nbsp;&nbsp;</c>For promotion</th>";
text += "<th><c style='width:10px; height:10px; border:#000 1px solid; margin-right:10px; margin-left:10px;'>&nbsp;&nbsp;&nbsp;&nbsp;</c>For salary alignment</th></tr></table><br>";
text += "Others: <c id='forhr'><hr></hr><hr></hr><hr></hr></c>";
text += "<table class='table table-bordered'><tbody> <tr><th><b>Recommended by:</b><br><br><br><br></th>";
text += "<th><b>Endorsed by:</b><br><br><br><br></th>";
text += "<th><b>Approved by:</b><br><br><br><br></th></tr></tbody></table>";


$("#quesprint").html(text);
//document.getElementById("quesprint").innerHTML = text;
});

//document.getElementById("totval").innerHTML = passtotal;
//document.getElementById("totval2").innerHTML = sum;

/*	
function getSum(total, num) {
    return total + num;
}
			$("#next"+j).click(function(){
                $("#square"+i).fadeOut('slow');
				$("#square"+j).fadeIn('slow');               
            });


$('#start').click(function() {
var position = $("#jobtitle").val();
$("#position").text("("+position+")");
$("p").fadeOut();
$("hr").fadeOut();
$("#square0").fadeIn();
});

*/
 $('button[name="pasalaman"]').click(function() {
 $(".loader").fadeIn();
            var laman = $(this).attr("value");
            $(laman).fadeIn();
			
					  setTimeout(
  function() 
  {
$(".loader").fadeOut();
  }, 1000);
			var laman2 = $(this).attr("id");
			$(laman2).fadeOut();
			
			$('button[name="pasalaman"]').attr('disabled', 'disabled');
			$('button[name="tapos"]').attr('disabled', 'disabled');
		});
				 $('button[name="ulit"]').click(function() {
					$("#modalreset").modal("show");
				 });
				$('#yes').click(function() {
				 	$("#modalreset").modal("hide");
				window.location = window.location.href;
				 	 window.scrollTo(0,0);
					 });
				
<!----- FUNCTION PRINT ---->

//function printDiv() {
//if (confirm("Do you want to print in full version?")==true){
  

  	$("#print").click(function(){ 
	 $('[data-toggle="tooltip"]').tooltip("hide");
				$("#hideprint").attr("style","display:none;");
					$("#print").attr("style","display:none;");			
//document.body.innerHTML = $("#fullprint").html()
//            $("#printresult").html(printit);
     window.print();			
//document.body.innerHTML = originalContents;
			$("#hideprint").removeAttr("style"); 
						$("#print").removeAttr("style"); 
						$("#fullprint").removeAttr("style"); 
						            $("#printresult").html("");

	 });
	/* else{
	      var printContents = document.getElementById('summaryprint').innerHTML;
     var originalContents = document.body.innerHTML;

     document.body.innerHTML = printContents;

     window.print();

     document.body.innerHTML = originalContents;
}
}
		*/
		

		
</script>

</body>
</html>