<?php
// Establishing Connection with Server by passing server_name, user_id and password as a parameter
$connection = mysql_connect("localhost", "root", "polyester10");
// Selecting Database
$db = mysql_select_db("hrsystem", $connection);
session_start();// Starting Session
// Storing Session
$user_check=$_SESSION['login_user'];
// SQL Query To Fetch Complete Information Of User
$ses_sql=mysql_query("select emp_status from emp_personal_data where emp_id='$user_check'", $connection);
$row = mysql_fetch_assoc($ses_sql);
$login_session =$row['emp_status'];
if(!isset($login_session)){
mysql_close($connection); // Closing Connection
//header('Location: http://localhost:10/xampp/e-pre-works/');
 // Redirecting To Home Page
  header("Location: HTTP/1.1 401 Unauthorized");
  }
?>