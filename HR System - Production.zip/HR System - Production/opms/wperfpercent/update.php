<?php
require_once '../../assets/dbconfig.php';
require_once '../../assets/connection.php';


	
	if($_POST)
{		$wpa_id = $_POST['id'];	

$ques_val=mysql_query("select percent from wpa_percent where wpa_percent_id='$wpa_id'", $connection);
$row4 = mysql_fetch_assoc($ques_val);
$val_entry =$row4['percent'];
$convert_val=explode(", ",$val_entry);
$countval = count($convert_val);

$cho_val=mysql_query("select choices from wpa_percent where wpa_percent_id='$wpa_id'", $connection);
$rowcho = mysql_fetch_assoc($cho_val);
$cho_entry =$rowcho['choices'];
$convert_cho=explode(" + ",$cho_entry);
$countcho = count($convert_cho);

$a = 0;
$b = 0;
$c = 0;
$d = 0;
while ($a < $countval){
$convalue = "per".$b;
$addper[] = $_POST[$convalue];
$conques = "cho".$b;
$addques[] = $_POST[$conques];
$condes = "des".$b;
$adddes[] = $_POST[$condes];
$a++;
$b++;
}
while ($c < $countcho){
$c++;
$d++;
$pilivalue = "pili".$d;
$addpili[] = $_POST[$pilivalue];
}
$perimplode = implode(", ",$addper);
$quesimplode = implode(" + ",$addques);
$desimplode = implode(" + ",$adddes);
$choimplode = implode(" + ",$addpili);

 
		$cat = $_POST['cat'];
		
		$stmt = $db_con->prepare("UPDATE wpa_percent SET category=:cat, question=:ques, descrip=:des, choices=:cho, percent=:per WHERE wpa_percent_id=:id");
			$stmt->bindParam(":cat", $cat);
			$stmt->bindParam(":ques", $quesimplode);
			$stmt->bindParam(":des", $desimplode);
			$stmt->bindParam(":cho", $choimplode);
			$stmt->bindParam(":per", $perimplode);
			$stmt->bindParam(":id", $wpa_id);
		
		if($stmt->execute())
		{
		$trail = mysql_query("INSERT INTO trail (type, per_action, description, emp_id) VALUES ('Manage WPA', 'UPDATED', 'ID No. $wpa_id', '$user_check')", $connection);
			echo "Updating...";
		}
		else{
			echo "Query Problem";
		}
	}

?>