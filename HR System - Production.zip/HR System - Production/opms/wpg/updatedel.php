<?php
require_once '../../assets/dbconfig.php';
require_once '../../assets/connection.php';


	if($_POST)
{		$id = $_POST['id'];
		$numgoal = $_POST['numgoal']-1;
						$numpili = $_POST['numpili'];
								$numdel = $_POST['numdel'];
									$valnumdel = $_POST['valnumdel'];		
		//Name
		$stmt=$db_con->prepare("SELECT * FROM emp_personal_data WHERE emp_id=:id");
	$stmt->execute(array(':id'=>$id));	
	$row=$stmt->fetch(PDO::FETCH_ASSOC);			
	$namewpg =$row['emp_name'];

$lastdel = $numpili-3;
$a = 0;
$b = 0;
$c = 0;
$d = 0;
while ($a < $numgoal){
$a++;
if ($a == $numdel){
$b++;}
$b++;
$convalue = "per".$b;
$addper[] = $_POST[$convalue];
$conques = "cho".$b;
$addques[] = $a.". ".$_POST[$conques];
}
while ($c < $numpili){
$c++;
if ($c == $lastdel){
$d--;
$c+=4;}
else if ($c == $valnumdel){
$d+=4;
$c+=4;}
$d++;
$pilivalue = "pili".$d;
$addpili[] = $_POST[$pilivalue];
}

$perimplode = implode(", ",$addper);
$quesimplode = implode(" + ",$addques);
$choimplode = implode(" + ",$addpili);
			
			$stmt = $db_con->prepare("UPDATE wpg_percent SET goal=:goal, choices=:cho, value=:val WHERE emp_id=:id");
			$stmt->bindParam(":id", $id);
			$stmt->bindParam(":goal", $quesimplode);
			$stmt->bindParam(":cho", $choimplode);
			$stmt->bindParam(":val", $perimplode);
			
			if($stmt->execute())
			{
			$trail = mysql_query("INSERT INTO trail (type, per_action, description, emp_id) VALUES ('WPG', 'DELETED', '$namewpg | Goal # $numdel', '$user_check')", $connection);
			echo "Deleting...";
			
			}
			else{
				echo "Query Problem";
			}	
		}

?>