<?php
require_once '../../assets/dbconfig.php';
require_once '../../assets/connection.php';

if($_GET['add_id'])
{
	$idwpg = $_GET['add_id'];	
	$numgoal = $_GET['numgoal'];
	$stmt=$db_con->prepare("SELECT * FROM emp_personal_data WHERE emp_id=:id");
	$stmt->execute(array(':id'=>$idwpg));	
	$row=$stmt->fetch(PDO::FETCH_ASSOC);			
				$namewpg =$row['emp_name'];
				
}


			
?>

<script>
		$(document).ready(function(){
    $('[data-toggle="tooltip"]').tooltip();   
		$(".content-loader").fadeIn();
				$(".footer").fadeIn();
});
		</script>

<style type="text/css">
#dis{
	display: none;
	margin-left: 70px;
	position: fixed;
	top: 50px;
	width: 68%;
	padding:20px;
	z-index:99999;
}
  .loader {
	position: fixed;
	left: 0px;
	top: 0px;
	width: 100%;
	height: 100%;
	z-index: 9999;
	background: url('../../img/loading.gif') 50% 50% no-repeat rgb(249,249,249);
	opacity: .5;
}

#square {
background-color: #ECECFF;
-webkit-box-shadow: 0px 0px 2px rgba(50, 50, 50, 0.31);
    -moz-box-shadow:    0px 0px 5px rgba(50, 50, 50, 0.31);
    box-shadow:         0px 0px 10px rgba(50, 50, 50, 0.31);
padding:20px;
}

#btn-save {
border-radius: 100%;
padding-top:25px;
padding-bottom: 25px;
padding-left: 25px;
padding-right: 25px;
font-size:36px;
	-webkit-box-shadow: 0px 0px 10px rgba(50, 50, 50, 20);
    -moz-box-shadow:    0px 0px 10px rgba(50, 50, 50, 20);
    box-shadow:         0px 0px 10px rgba(50, 50, 50, 20);
}
#btn-save:focus{
outline: 0px;
}

  @media only screen and (max-width: 768px) 
{ 
#dis{
	top: 75px;
	margin-left: 0;
	width:70%
}

</style>
    <div id="dis">
    <!-- here message will be displayed -->
	</div>

<div class="title"> Add Goals for <c class="label label-primary"><?php echo $namewpg; ?></c> </div>
<div id="square">
<?php 
$x = 0;
$y = 0;
$z = 0;
$c = 0; 
$countnumgoal = (int)$numgoal;
while ($x != $countnumgoal){ 

$x++;
$z++;
 ?>
	 <form method='post' id='wpg' action="#">
	 <input type="hidden" name="id" value="<?php echo $idwpg; ?>" />
	 <input type="hidden" name="numgoal" value="<?php echo $countnumgoal; ?>" />
 <div class="row">
 <div class="col-sm-10">
 	 <b>Work Performance Goal <?php echo $x; ?></b>
 <div class="input-group">
 <span class="input-group-addon"><?php echo $x."."; ?></span>
<input type='text' name='cho<?php echo $z; ?>' id='goal' placeholder='' class='form-control' required/></div>
</div>
 <div class="col-sm-2">
  	 <b>Percent (%)</b>
 <input type='text' name='per<?php echo $z; ?>' id="value" class='form-control' maxlength="2" onkeypress='return event.charCode >= 48 && event.charCode <= 57' required/></div></div><br />
  <div class="row">
   <div class="col-sm-12">
    	 <b>Choices</b>
 <?php $valdown = 4;
while (0 != $valdown){ 
$c++;
?>
 <div class="input-group">
 <span class="input-group-addon"><?php echo "Value : $valdown"; ?></span>
<input type='text' name='pili<?php echo $c; ?>' id='goal' placeholder='' class='form-control' required/></div><br />
<?php  $valdown--; } ?>
</div>
</div>
 <input type="hidden" name="numpili" value="<?php echo $c; ?>" />
 
 <br />
 
<?php 
} ?>

		  <center><div id="errrmsg" style="color:#FF0000; font-size:12px;"></div></center>
		     
     </form>    
            <button type="btn-save" class="btn btn-success" name="btn-save" id="btn-save" data-toggle="tooltip" disabled="disabled" data-placement="right" title="Save Record">
    		<span class="glyphicon glyphicon-floppy-save"></span>
			</button>  
			</div>
		</div>
		
 <script>
 var arrsum = 100;
var count = parseInt(1, 10);      
var count2 = parseInt(1, 10);    
$('input[id="goal"]').keyup(function() {
    var empty_flds = 0;
    $('input[id="goal"]').each(function() {
        if(!$.trim($(this).val())) {
            empty_flds++;
        }    
    });

    if (empty_flds) { 
count = 1;	
$("input[id='goal']").css("border","grey solid 1px");
    } else {
	count = 0;	
$("input[id='goal']").css("border","green solid 1px"); 
   }
   
   if (count == 1 || count2 == 1){       
            $('#btn-save').attr('disabled', 'disabled');
        } else {
            $('#btn-save').removeAttr('disabled');}


});
	$('input[id=value]').keyup(function(){
		var sum = 0;
	var left = arrsum;
	$('input[id="value"]').each(function(){	 
    sum += parseFloat(this.value);
	left -= parseFloat(this.value);
            if (sum != arrsum) {
                count2 = 1;				
$("#errrmsg").text("*Maximum total percent in this category is "+arrsum+"% | percent value left: " + left+"");
$("input[id='value']").css("border","grey solid 1px");
$('#btn-save').attr('disabled', 'disabled');
            }
else {
count2=0;
$("#left").text("");
$("#errrmsg").text("");
$("input[id='value']").css("border","green solid 1px");
}
if (count == 1 || count2 == 1){       
            $('#btn-save').attr('disabled', 'disabled');
        } else {
            $('#btn-save').removeAttr('disabled');}

})
});

		$("#btn-save").click(function() {
	  	$("#btn-save").attr("disabled","disabled");
	   		$.ajax({
            type: "POST",
            url: "create.php", //process to add
            data: $("#wpg").serialize(),					
            success: function(data){
			 $(".loader").fadeIn();
			 $("#dis").html('<div class="alert alert-success"><span class="glyphicon glyphicon-ok">&nbsp;</span>'+data+'</div>');
			 $("#dis").fadeIn('slow');
				     setTimeout(function(){
        $("#dis").fadeOut();
    }, 3000); 									
					  setTimeout(
  function() 
  {
$(".loader").fadeOut();
  }, 2000);
					  
					 setTimeout(
  function() 
  {
			window.location.href="index.php";
  }, 3000);
  }
		     });	
		 });   


</script>
    