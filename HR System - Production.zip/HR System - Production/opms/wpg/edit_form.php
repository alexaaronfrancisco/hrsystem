<?php
require_once '../../assets/dbconfig.php';
require_once '../../assets/connection.php';
if($_GET['edit_id'])
{   
	$idwpg = $_GET['edit_id'];	
	$stmt=$db_con->prepare("SELECT * FROM emp_personal_data WHERE emp_id=:id");
	$stmt->execute(array(':id'=>$idwpg));	
	$row=$stmt->fetch(PDO::FETCH_ASSOC);			
	$namewpg =$row['emp_name'];
				
}


			
?>

<script>
		$(document).ready(function(){
    $('[data-toggle="tooltip"]').tooltip();  
$('body').removeClass('modal-open');
$('.modal-backdrop').remove();
	// GOAL KEY UP
			$('#passaddgoal').attr('disabled', 'disabled');	
	$("input[name='valaddgoal']").keyup(function() {       		 
            if ($(this).val() == '') {
			$('#passaddgoal').attr('disabled', 'disabled');
            }
else {
$('#passaddgoal').removeAttr('disabled', 'disabled');
}
});
	// TRIGGER MODAL
	var empid2;
	var numaddgoal;
	$('#addgoal').click(function() { 
	$("#modaladdgoal").modal("show");
	empid2 = "<?php echo $idwpg; ?>";
	});
	
	//PASS THE VALUE OF GOAL
	$('#passaddgoal').click(function() { 
	$("#modaladdgoal").modal("hide");
	numaddgoal = $("input[name='valaddgoal']").val()
	 $(".loader").fadeIn();			
	$(".content-loader").load('edit_form_add.php?edit_id='+empid2+'&addgoal='+numaddgoal);
			  setTimeout(
  function() 
  {
$(".loader").fadeOut();
			$(".modal").modal("hide");
  }, 2000);
	});
	
});

/*
$(function() {
        var scntDiv = $('form');
        var i = $('form .addinput').size() + 1;
        $('#addgoal').click(function() {
                $('<div class="addinput'+i+'"><div class="row"><div class="col-sm-10"><b>Goal '+i+'</b><div class="input-group"><span class="input-group-addon">'+i+'. </span><input type="text" value="" name="cho'+i+'" id="goal" placeholder="" class="form-control" required/></div></div><div class="col-sm-2"><b>% Weight</b><input type="text" value="" name="per'+i+'" id="value" class="form-control" maxlength="2" onkeypress="return event.charCode >= 48 && event.charCode <= 57" required/></div></div><br /><div class="row"><div class="col-sm-12"><b>Success Measures</b><div class="input-group"><span class="input-group-addon">Value : WOW</span><input type="text" value="" name="pili" id="goal" placeholder="" class="form-control" required/></div><br /></div></div><c class="btn btn-default" id="remaddgoal">Remove</c></div>').appendTo(scntDiv);
                i++;
                return false;
        });
        
		$('#remaddgoal').click(function() {
//		var getdivrem = $(this).attr("name");
		alert("nice");
                //  $('.'+getdivrem).remove();
                        i--;
                return false;
				});
				});
  */   
		</script>

<style type="text/css">
#dis{
	display: none;
	margin-left: 70px;
	position: fixed;
	top: 50px;
	width: 68%;
	padding:20px;
	z-index:99999;
}
  .loader {
	position: fixed;
	left: 0px;
	top: 0px;
	width: 100%;
	height: 100%;
	z-index: 9999;
	background: url('../../img/loading.gif') 50% 50% no-repeat rgb(249,249,249);
	opacity: .5;
}

#square {
background-color: #ECECFF;
-webkit-box-shadow: 0px 0px 2px rgba(50, 50, 50, 0.31);
    -moz-box-shadow:    0px 0px 5px rgba(50, 50, 50, 0.31);
    box-shadow:         0px 0px 10px rgba(50, 50, 50, 0.31);
padding:20px;
}

#btn-save {
border-radius: 100%;
padding-top:25px;
padding-bottom: 25px;
padding-left: 25px;
padding-right: 25px;
font-size:36px;
	-webkit-box-shadow: 0px 0px 10px rgba(50, 50, 50, 20);
    -moz-box-shadow:    0px 0px 10px rgba(50, 50, 50, 20);
    box-shadow:         0px 0px 10px rgba(50, 50, 50, 20);
}
#btn-save:focus{
outline: 0px;
}

  @media only screen and (max-width: 768px) 
{ 
#dis{
	top: 75px;
	margin-left: 0;
	width:70%
}

</style>

	<!-- Modal -->

  <div class="modal fade" id="modaldel" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h3 class="modal-title text-danger"><span class="glyphicon glyphicon-remove"> </span> Delete</h3>
        </div>
        <div class="modal-body">
		<br />
          <p>Are you sure you want to delete <i>Goal <c id="numbergoal"></c></i> ?</p>
        </div>
        <div class="modal-footer">
		  <button type="button" id="no" value="no" data-dismiss="modal" class="btn btn-default" > No </button>
		  <button type="button" id="delgoal" value="yes" class="btn btn-primary" autofocus > Yes </button>
		
        </div>
      </div>
      
    </div>
  </div>

  <div class="modal fade" id="modaladdgoal" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h3 class="modal-title text-success"><span class="glyphicon glyphicon-plus"> </span> Add Goal</h3>
        </div>
        <div class="modal-body">
		<br />
			<label>How many goal do you want to add?</label>
          <input type='text' value="" name='valaddgoal' id='valaddgoal' placeholder='' maxlength="1" style="padding:2px;" onkeypress='return event.charCode >= 48 && event.charCode <= 57' required/>
        </div>
        <div class="modal-footer">
		  <button type="button" id="no" value="no" data-dismiss="modal" class="btn btn-default" > Cancel </button>
		  <button type="button" id="passaddgoal" value="yes" class="btn btn-primary" autofocus > Submit </button>
		
        </div>
      </div>
      
    </div>
  </div>



    <div id="dis">
    <!-- here message will be displayed -->
	</div>



<div class="title"> Update Goals for <c class="label label-primary"><?php echo $namewpg; ?></c> </div>
<div id="square">
<?php 
//goal
$ques_sql=mysql_query("select goal from wpg_percent where emp_id='$idwpg'", $connection);
$row3 = mysql_fetch_assoc($ques_sql);
$ques_entry =$row3['goal'];
$convert_ques=explode(" + ",$ques_entry);
//choices
$cho_sql=mysql_query("select choices from wpg_percent where emp_id='$idwpg'", $connection);
$row4 = mysql_fetch_assoc($cho_sql);
$cho_entry =$row4['choices'];
$convert_cho=explode(" + ",$cho_entry);
//value
$per_sql=mysql_query("select value from wpg_percent where emp_id='$idwpg'", $connection);
$row5 = mysql_fetch_assoc($per_sql);
$per_entry =$row5['value'];
$convert_per=explode(", ",$per_entry);
$countques = count($convert_ques);
$x = 0;
$y = 0;
$z = 0;
$c = 0;
$d = 0;
$valnumdel=1;
while ($x != $countques){ 
$x++;
$z++;
$goal_result = substr($convert_ques[$y], 3);
 ?>
	 <form method='post' id='wpg' action="#">
	 <input type="hidden" name="id" value="<?php echo $idwpg; ?>" />
	 <input type="hidden" name="numgoal" value="<?php echo $countques; ?>" />
	 <div id="delsec<?php echo $x; ?>" class="addinput">
	 <c class="btn btn-danger del-goal" id="<?php echo $x; ?>" name="<?php echo $valnumdel; ?>"><span class="glyphicon glyphicon-trash"></span> Delete<b> Goal <?php echo $x; ?></b> </c>
 <div class="row">
 <div class="col-sm-10">
 	 <b>Goal <?php echo $x; ?></b> 
 <div class="input-group">
 <span class="input-group-addon"><?php echo $x."."; ?></span>
<input type='text' value="<?php echo $goal_result; ?>" name='cho<?php echo $z; ?>' id='goal' placeholder='' class='form-control' required/></div>
</div>
 <div class="col-sm-2">
  	 <b>% Weight</b>
 <input type='text' value="<?php echo $convert_per[$y]; ?>" name='per<?php echo $z; ?>' id="value" class='form-control' maxlength="2" onkeypress='return event.charCode >= 48 && event.charCode <= 57' required/></div></div><br />
   <div class="row">
   <div class="col-sm-12">
    	 <b>Success Measures</b>
 <?php $valdown = 4;

while (0 != $valdown){ 
if ($valdown == 4){
$valnumdel+=4;}
$c++;
?>
 <div class="input-group">
 <span class="input-group-addon"><?php echo "Value : $valdown"; ?></span>
<input type='text' value="<?php echo $convert_cho[$d]; ?>" name='pili<?php echo $c; ?>' id='goal' placeholder='' class='form-control' required/></div><br />
<?php $d++; $valdown--; } ?>
</div>
</div>

 
 
 <br />
  </div>
<?php 
$y++;
} 

?>
 <input type="hidden" name="numpili" value="<?php echo $c; ?>" />
 	 <c class="btn btn-primary" id="addgoal"><span class="glyphicon glyphicon-plus"></span> Add Goal</c><br /><br />
	 
		  <center><div id="errrmsg" style="color:#FF0000; font-size:12px;"></div></center>
		     
     </form>    

            <button type="btn-save" class="btn btn-success" name="btn-save" id="btn-save" data-toggle="tooltip" data-placement="right" title="Save Record">
    		<span class="glyphicon glyphicon-floppy-save"></span>
			</button>  
			</div>
		</div>
		
 <script>
 var countx = <?php echo $x; ?>; 
if(countx == 1){
$(".del-goal").hide();
}
 
 
 var countdel;
 var valnumdel;
 var empid;
 
  $("input[id='goal']").keyup(function(){
  var goal = $(this).attr("name");
  alert(goal);
  });
 
 $(".del-goal").click(function(){
 countdel =  $(this).attr("id");
 $("#numbergoal").text(countdel);
 valnumdel =  $(this).attr("name");

 alert(valnumdel);
 alert(goal);
empid = "<?php echo $idwpg; ?>";
 $("#modaldel").modal("show");


}); 
 
 $("#delgoal").click(function(){
  $("#modaldel").modal("hide");
  $(".loader").fadeIn();
	   		$.ajax({
            type: "POST",
            url: "updatedel.php", //process to add
            data: $("#wpg").serialize() + "&numdel="+countdel+"&valnumdel="+valnumdel,					
            success: function(data){

			 $("#dis").html('<div class="alert alert-danger"><span class="glyphicon glyphicon-ok">&nbsp;</span>'+data+'</div>');
			 $("#dis").fadeIn('slow');			 
				     setTimeout(function(){
        $("#dis").fadeOut();
		$('#delsec'+countdel).remove();
    }, 3000); 									
					  setTimeout(
  function() 
  {
$(".loader").fadeOut();
  }, 3000);
					  
					 setTimeout(
  function() 
  {
	$(".content-loader").load('edit_form.php?edit_id='+empid);
  }, 3000);
  }
		     });
		 });  
 
 var arrsum = 100;
var count = parseInt(1, 10);      
var count2 = parseInt(1, 10);    
//ready
$(document).ready(function(){
    var empty_flds = 0;
    $('input[id="goal"]').each(function() {
        if(!$.trim($(this).val())) {
            empty_flds++;
        }    
    });

    if (empty_flds) { 
count = 1;	
$("input[id='goal']").css("border","grey solid 1px");
    } else {
	count = 0;	
$("input[id='goal']").css("border","green solid 1px"); 
   }
   
   if (count == 1 || count2 == 1){       
            $('#btn-save').attr('disabled', 'disabled');
        } else {
            $('#btn-save').removeAttr('disabled');}
});
$(document).ready(function(){
		var sum = 0;
	var left = arrsum;
	$('input[id="value"]').each(function(){	 
    sum += parseFloat(this.value);
	left -= parseFloat(this.value);
            if (sum != arrsum) {
                count2 = 1;				
$("#errrmsg").text("*Maximum total percent in this category is "+arrsum+"% | percent value left: " + left+"");
$("input[id='value']").css("border","grey solid 1px");
$('#btn-save').attr('disabled', 'disabled');
            }
else {
count2=0;
$("#left").text("");
$("#errrmsg").text("");
$("input[id='value']").css("border","green solid 1px");
}
if (count == 1 || count2 == 1){       
            $('#btn-save').attr('disabled', 'disabled');
        } else {
            $('#btn-save').removeAttr('disabled');}

})
});
//keyup
    $('input[id="goal"]').keyup(function() {
    var empty_flds = 0;
    $('input[id="goal"]').each(function() {
        if(!$.trim($(this).val())) {
            empty_flds++;
        }    
    });
    if (empty_flds) { 
count = 1;	
$("input[id='goal']").css("border","grey solid 1px");
    } else {
	count = 0;	
$("input[id='goal']").css("border","green solid 1px"); 
   }
   
   if (count == 1 || count2 == 1){       
            $('#btn-save').attr('disabled', 'disabled');
        } else {
            $('#btn-save').removeAttr('disabled');}


});
	$('input[id=value]').keyup(function(){
		var sum = 0;
	var left = arrsum;
	$('input[id="value"]').each(function(){	 
    sum += parseFloat(this.value);
	left -= parseFloat(this.value);
            if (sum != arrsum) {
                count2 = 1;				
$("#errrmsg").text("*Maximum total percent in this category is "+arrsum+"% | percent value left: " + left+"");
$("input[id='value']").css("border","grey solid 1px");
$('#btn-save').attr('disabled', 'disabled');
            }
else {
count2=0;
$("#left").text("");
$("#errrmsg").text("");
$("input[id='value']").css("border","green solid 1px");
}
if (count == 1 || count2 == 1){       
            $('#btn-save').attr('disabled', 'disabled');
        } else {
            $('#btn-save').removeAttr('disabled');}

})
});

		$("#btn-save").click(function() {
	  	$("#btn-save").attr("disabled","disabled");
	   		$.ajax({
            type: "POST",
            url: "update.php", //process to add
            data: $("#wpg").serialize(),					
            success: function(data){
			 $(".loader").fadeIn();
			 $("#dis").html('<div class="alert alert-success"><span class="glyphicon glyphicon-ok">&nbsp;</span>'+data+'</div>');
			 $("#dis").fadeIn('slow');
				     setTimeout(function(){
        $("#dis").fadeOut();
    }, 3000); 									
					  setTimeout(
  function() 
  {
$(".loader").fadeOut();
  }, 2000);
					  
					 setTimeout(
  function() 
  {
			window.location.href="index.php";
  }, 3000);
  }
		     });	
		 });   


</script>
    