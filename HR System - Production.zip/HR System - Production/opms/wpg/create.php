<?php
require_once '../../assets/dbconfig.php';
require_once '../../assets/connection.php';


	if($_POST)
{		$id = $_POST['id'];
		$numgoal = $_POST['numgoal'];	
				$numpili = $_POST['numpili'];	
		//Name
		$stmt=$db_con->prepare("SELECT * FROM emp_personal_data WHERE emp_id=:id");
	$stmt->execute(array(':id'=>$id));	
	$row=$stmt->fetch(PDO::FETCH_ASSOC);			
	$namewpg =$row['emp_name'];

$a = 0;
$b = 0;
$c = 0;
$d = 0;
while ($a < $numgoal){
$a++;
$b++;
$convalue = "per".$b;
$addper[] = $_POST[$convalue];
$conques = "cho".$b;
$addques[] = $a.". ".$_POST[$conques];
}
while ($c < $numpili){
$c++;
$d++;
$pilivalue = "pili".$d;
$addpili[] = $_POST[$pilivalue];

}

$perimplode = implode(", ",$addper);
$quesimplode = implode(" + ",$addques);
$choimplode = implode(" + ",$addpili);
		
		try{
			
			$stmt = $db_con->prepare("INSERT INTO wpg_percent(emp_id, goal, choices, value) VALUES(:id, :goal, :cho, :val)");
			$stmt->bindParam(":id", $id);
			$stmt->bindParam(":goal", $quesimplode);
			$stmt->bindParam(":cho", $choimplode);
			$stmt->bindParam(":val", $perimplode);
			
			if($stmt->execute())
			{
			$trail = mysql_query("INSERT INTO trail (type, per_action, description, emp_id) VALUES ('WPG', 'ADDED', '$namewpg', '$user_check')", $connection);
			echo "Saving...";
			
			}
			else{
				echo "Query Problem";
			}	
		}
		catch(PDOException $e){
			echo $e->getMessage();
		}
	}

?>