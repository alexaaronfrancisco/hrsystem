<?php
require_once '../../assets/dbconfig.php';
//STAFF
$per_goal=mysql_query("select performance ,percent from org_percent where org_percent_id='1'", $connection);
$row = mysql_fetch_assoc($per_goal);
$goal_entry =$row['performance'];
$pergoal_entry =$row['percent'];
$per_attr=mysql_query("select performance, percent from org_percent where org_percent_id='2'", $connection);
$row2 = mysql_fetch_assoc($per_attr);
$attr_entry =$row2['performance'];
$perattr_entry =$row2['percent'];

//SUPERVISOR
$per_goal2=mysql_query("select performance ,percent from org_percent where org_percent_id='3'", $connection);
$row3 = mysql_fetch_assoc($per_goal2);
$goal_entry2 =$row3['performance'];
$pergoal_entry2=$row3['percent'];
$per_attr2=mysql_query("select performance, percent from org_percent where org_percent_id='4'", $connection);
$row4 = mysql_fetch_assoc($per_attr2);
$attr_entry2 =$row4['performance'];
$perattr_entry2 =$row4['percent'];

//MANAGER
$per_goal3=mysql_query("select performance ,percent from org_percent where org_percent_id='5'", $connection);
$row5 = mysql_fetch_assoc($per_goal3);
$goal_entry3 =$row5['performance'];
$pergoal_entry3=$row5['percent'];
$per_attr3=mysql_query("select performance, percent from org_percent where org_percent_id='6'", $connection);
$row6 = mysql_fetch_assoc($per_attr3);
$attr_entry3 =$row6['performance'];
$perattr_entry3 =$row6['percent'];


?>
<script>
		$(document).ready(function(){
    $('[data-toggle="tooltip"]').tooltip();   
});
		</script>

<style type="text/css">
#dis{
	display: none;
	margin-left: 70px;
	position: fixed;
	top: 50px;
	width: 68%;
	padding:20px;
	z-index:99999;
}
  .loader {
	position: fixed;
	left: 0px;
	top: 0px;
	width: 100%;
	height: 100%;
	z-index: 9999;
	background: url('../../img/loading.gif') 50% 50% no-repeat rgb(249,249,249);
	opacity: .5;
}

#square {
background-color: #ECECFF;
-webkit-box-shadow: 0px 0px 2px rgba(50, 50, 50, 0.31);
    -moz-box-shadow:    0px 0px 5px rgba(50, 50, 50, 0.31);
    box-shadow:         0px 0px 10px rgba(50, 50, 50, 0.31);
padding:20px;
}
.add {
border-radius: 100%;
padding-top:15px;
padding-bottom: 17px;
padding-left: 15px;
padding-right: 17px;
font-size:24px;		
}
.add:focus{
outline: 0px;
}
.btn {
border-radius: 100%;
padding-top:25px;
padding-bottom: 25px;
padding-left: 25px;
padding-right: 25px;
font-size:36px;
margin-top: -50px;
			    -webkit-box-shadow: 0px 0px 10px rgba(50, 50, 50, 20);
    -moz-box-shadow:    0px 0px 10px rgba(50, 50, 50, 20);
    box-shadow:         0px 0px 10px rgba(50, 50, 50, 20);
}
.btn:focus{
outline: 0px;
}
  @media only screen and (max-width: 768px) 
{ 
#dis{
	top: 75px;
	margin-left: 0;
	width:70%
}
.btn {
margin-top: 0px;
}
</style>
    <div id="dis">
    <!-- here message will be displayed -->
	</div>
	<form>
		<div id="row">
			   <div class="col-sm-3">
		     <select name='rankcat' id="rankcat" class='form-control'  placeholder='' required>
			 <option value="Staff">Rank & File / Staff</option>
			 <option value="Supervisor">Supervisor</option>
			 <option value="Manager">Manager</option>
			 </select>
         </div>
		 </div>
		 </form>
<!----<div class="title"> Update  </div>---->
<br /><p></p><br />
	 <form method='post' id='emp-UpdateForm' action="#">
<div id="staff">

 
<div id="square">
<div class="row">
                  <div class="col-sm-6">
              <b>Performance</b>
 <div style="margin-bottom: 10px;" class="input-group">
			  <span class="input-group-addon"><b>WPG</b></span>
			<input type='text' name='goal' id="goal" value="<?php echo $goal_entry ?>"  placeholder='' readonly="" class="form-control" required /> 
         </div>
 </div>

         <div class="col-sm-2">
             <b>Percent</b> 
			  <div style="margin-bottom: 10px;" class="input-group">
			  <span class="input-group-addon"><b>%</b></span>
			  <input type="text" name='pergoal' id="per" class='form-control' value="<?php echo $pergoal_entry; ?>" maxlength="2" onkeypress='return event.charCode >= 48 && event.charCode <= 57' placeholder='' required>

         </div>
		 </div>
		 </div>
		 <div class="row">
 <div class="col-sm-6">
			  <div style="margin-bottom: 10px;" class="input-group">
			  <span class="input-group-addon"><b>WPA</b></span>
             <input type='text' name='attr' id="attr" class='form-control' value="<?php echo $attr_entry ?>" placeholder='' maxlength="3" readonly="" onkeypress='return event.charCode >= 48 && event.charCode <= 57' required>
         </div>
		 </div>
		  <div class="col-sm-2">
			  <div style="margin-bottom: 10px;" class="input-group">
			  <span class="input-group-addon"><b>%</b></span>
             <input type='text' name='perattr' id="per" class='form-control' value="<?php echo $perattr_entry ?>" placeholder='' maxlength="2" onkeypress='return event.charCode >= 48 && event.charCode <= 57' required>
         </div>
		 </div>
		  		  <button type="btn-save" class="btn btn-success" name="btn-save" id="btn-save" data-toggle="tooltip" data-placement="right" title="Save Record">
    		<span class="glyphicon glyphicon-floppy-save"></span>
			</button>  
					</div>
					<div id="err" style="color:#FF0000; font-size:12px; font-style:italic;"></div>
	
		     </div>
			 </div>
			 <div id="supervisor" style="display:none;">
 
<div id="square">
<div class="row">
                  <div class="col-sm-6">
              <b>Performance</b>
 <div style="margin-bottom: 10px;" class="input-group">
			  <span class="input-group-addon"><b>WPG</b></span>
			<input type='text' name='goal2' id="goal2" value="<?php echo $goal_entry2; ?>"  placeholder='' readonly="" class="form-control" required /> 
         </div>
 </div>

         <div class="col-sm-2">
             <b>Percent</b> 
			  <div style="margin-bottom: 10px;" class="input-group">
			  <span class="input-group-addon"><b>%</b></span>
			  <input type="text" name='pergoal2' id="per2" class='form-control' value="<?php echo $pergoal_entry2; ?>" maxlength="2" onkeypress='return event.charCode >= 48 && event.charCode <= 57' placeholder='' required>

         </div>
		 </div>
		 </div>
		 <div class="row">
 <div class="col-sm-6">
			  <div style="margin-bottom: 10px;" class="input-group">
			  <span class="input-group-addon"><b>WPA</b></span>
             <input type='text' name='attr2' id="attr2" class='form-control' value="<?php echo $attr_entry2 ?>" placeholder='' maxlength="3" readonly="" onkeypress='return event.charCode >= 48 && event.charCode <= 57' required>
         </div>
		 </div>
		  <div class="col-sm-2">
			  <div style="margin-bottom: 10px;" class="input-group">
			  <span class="input-group-addon"><b>%</b></span>
             <input type='text' name='perattr2' id="per2" class='form-control' value="<?php echo $perattr_entry2 ?>" placeholder='' maxlength="2" onkeypress='return event.charCode >= 48 && event.charCode <= 57' required>
         </div>
		 </div>
		  		  <button type="btn-save" class="btn btn-success" name="btn-save2" id="btn-save2" data-toggle="tooltip" data-placement="right" title="Save Record">
    		<span class="glyphicon glyphicon-floppy-save"></span>
			</button>  
					</div>
					<div id="err2" style="color:#FF0000; font-size:12px; font-style:italic;"></div>
		     </div>
			 </div>
			 <div id="manager" style="display:none;">
 
<div id="square">
<div class="row">
                  <div class="col-sm-6">
              <b>Performance</b>
 <div style="margin-bottom: 10px;" class="input-group">
			  <span class="input-group-addon"><b>WPG</b></span>
			<input type='text' name='goal3' id="goal3" value="<?php echo $goal_entry3; ?>"  placeholder='' readonly="" class="form-control" required /> 
         </div>
 </div>

         <div class="col-sm-2">
             <b>Percent</b> 
			  <div style="margin-bottom: 10px;" class="input-group">
			  <span class="input-group-addon"><b>%</b></span>
			  <input type="text" name='pergoal3' id="per3" class='form-control' value="<?php echo $pergoal_entry3; ?>" maxlength="2" onkeypress='return event.charCode >= 48 && event.charCode <= 57' placeholder='' required>

         </div>
		 </div>
		 </div>
		 <div class="row">
 <div class="col-sm-6">
			  <div style="margin-bottom: 10px;" class="input-group">
			  <span class="input-group-addon"><b>WPA</b></span>
             <input type='text' name='attr3' id="attr3" class='form-control' value="<?php echo $attr_entry3; ?>" placeholder='' maxlength="3" readonly="" onkeypress='return event.charCode >= 48 && event.charCode <= 57' required>
         </div>
		 </div>
		  <div class="col-sm-2">
			  <div style="margin-bottom: 10px;" class="input-group">
			  <span class="input-group-addon"><b>%</b></span>
             <input type='text' name='perattr3' id="per3" class='form-control' value="<?php echo $perattr_entry3; ?>" placeholder='' maxlength="2" onkeypress='return event.charCode >= 48 && event.charCode <= 57' required>
         </div>
		 </div>
		  <button type="btn-save" class="btn btn-success" name="btn-save3" id="btn-save3" data-toggle="tooltip" data-placement="right" title="Save Record">
    		<span class="glyphicon glyphicon-floppy-save"></span>
			</button>  
					</div>
					<div id="err3" style="color:#FF0000; font-size:12px; font-style:italic;"></div>
		     </div>
			 </div>			 
     </form>    
            	</div>

		</div>

 <script>
 
(function() {
		var count1 = parseInt(1, 10);
		var count2 = parseInt(1, 10);
		var count3 = parseInt(1, 10);        

<!----- FOR READY FUNCTION ----> 
$(document).ready(function() { 
            if ($('input[id="per"]').val() == '') {
                count1 = 1;
$("#err").text("*Required field is empty");
$("input[id='per']").css("border","red solid 1px");
$('#btn-save').attr('disabled', 'disabled');
            }
else {
count1=0;
$("#err").text("");
$("input[id='per']").css("border","green solid 1px");
}
if (count1 == 1){       
            $('#btn-save').attr('disabled', 'disabled');
        } else {
            $('#btn-save').removeAttr('disabled');}

})
$(document).ready(function() { 
            if ($('input[id="per2"]').val() == '') {
                count2 = 1;
$("#err").text("*Required field is empty");
$("input[id='per2']").css("border","red solid 1px");
$('#btn-save2').attr('disabled', 'disabled');
            }
else {
count2=0;
$("#err").text("");
$("input[id='per2']").css("border","green solid 1px");
}
if (count2 == 1){       
            $('#btn-save2').attr('disabled', 'disabled');
        } else {
            $('#btn-save2').removeAttr('disabled');}

})
$(document).ready(function() { 
            if ($('input[id="per3"]').val() == '') {
                count3 = 1;
$("#err").text("*Required field is empty");
$("input[id='per3']").css("border","red solid 1px");
$('#btn-save3').attr('disabled', 'disabled');
            }
else {
count3=0;
$("#err").text("");
$("input[id='per3']").css("border","green solid 1px");
}
if (count3 == 1){       
            $('#btn-save3').attr('disabled', 'disabled');
        } else {
            $('#btn-save3').removeAttr('disabled');}

})
<!----- FOR KeyUP FUNCTION ----> 
	$('input[id=per]').keyup(function(){
		var sum = 0;
	var left = 100;
	$('input[id="per"]').each(function(){	 
    sum += parseFloat(this.value);
	left -= parseFloat(this.value);
            if (sum != 100) {
                count1 = 1;
$("#err").text("*Required total percentage is 100% | percent value left: " + left+"");
$("input[id='per']").css("border","red solid 1px");
$('#btn-save').attr('disabled', 'disabled');
		    $("select[id='rankcat']").prop('disabled',true);
            }
else {
count1=0;
$("#err").text("");
$("input[id='per']").css("border","green solid 1px");
}
if (count1 == 1){       
 $("select[id='rankcat']").prop('disabled',true);
            $('#btn-save').attr('disabled', 'disabled');
        } else {
		 $("select[id='rankcat']").prop('disabled',false);
            $('#btn-save').removeAttr('disabled');}

})
});
<!----- FOR KeyUP FUNCTION ----> 
	$('input[id=per2]').keyup(function(){
		var sum2 = 0;
	var left2 = 100;
	$('input[id="per2"]').each(function(){	 
    sum2 += parseFloat(this.value);
	left2 -= parseFloat(this.value);
            if (sum2 != 100) {
                count2 = 1;
$("#err2").text("*Required total percentage is 100% | percent value left: " + left2+"");
$("input[id='per2']").css("border","red solid 1px");
$('#btn-save2').attr('disabled', 'disabled');
 $("select[id='rankcat']").prop('disabled',true);
            }
else {
count2=0;
$("#err2").text("");
$("input[id='per2']").css("border","green solid 1px");
}
if (count2 == 1){       
 $("select[id='rankcat']").prop('disabled',true);
            $('#btn-save2').attr('disabled', 'disabled');
        } else {
		 $("select[id='rankcat']").prop('disabled',false);
            $('#btn-save2').removeAttr('disabled');}

})
});
<!----- FOR KeyUP FUNCTION ----> 
	$('input[id=per3]').keyup(function(){
		var sum3 = 0;
	var left3 = 100;
	$('input[id="per3"]').each(function(){	 
    sum3 += parseFloat(this.value);
	left3 -= parseFloat(this.value);
            if (sum3 != 100) {
                count3 = 1;
$("#err3").text("*Required total percentage is 100% | percent value left: " + left3+"");
$("input[id='per3']").css("border","red solid 1px");
$('#btn-save3').attr('disabled', 'disabled');
 $("select[id='rankcat']").prop('disabled',true);
            }
else {
count3=0;
$("#err3").text("");
$("input[id='per3']").css("border","green solid 1px");
}
if (count3 == 1){       
 $("select[id='rankcat']").prop('disabled',true);
            $('#btn-save3').attr('disabled', 'disabled');
        } else {
		 $("select[id='rankcat']").prop('disabled',false);
            $('#btn-save3').removeAttr('disabled');}

})
});



})()
 $("#rankcatval").text("staff"); 
 $("#rankcat").change(function() {
 var rankval = $(this).val();	
 	if (rankval == 'Staff'){
	$("#supervisor").fadeOut();
	$("#manager").fadeOut();
	$("#staff").fadeIn();	
	}
	else if (rankval == 'Supervisor'){
	$("#staff").fadeOut();
	$("#manager").fadeOut();
	$("#supervisor").fadeIn();	
		$("#supervisor").removeAttr("style")
	}
	else if (rankval == 'Manager') {
	$("#staff").fadeOut();
	$("#supervisor").fadeOut();
	$("#manager").fadeIn();	
	}
 });


	/* Update Record  */
	    $("button[name='btn-save']").click(function(e){
		e.preventDefault();
		var wpg = $("input[name='goal']").val();
		var wpa = $("input[name='attr']").val();
		var wpgper = $("input[name='pergoal']").val();
		var wpaper = $("input[name='perattr']").val();
$.ajax({
            type: "POST",
            url: "update.php", //process to add
            data: {goal : wpg , attr : wpa, pergoal : wpgper, perattr : wpaper, id1 : 1, id2 : 2} ,					
            success: function(data){
			$("#dis").fadeOut();
			$("#dis").fadeIn('slow');
				 $("#dis").html('<div class="alert alert-success"><span class="glyphicon glyphicon-ok">&nbsp;</span>'+data+'</div>');
				     setTimeout(function(){
        $("#dis").fadeOut();
    }, 3000); 					
					  $(".loader").fadeIn();
					  setTimeout(
  function() 
  {
$(".loader").fadeOut();
  }, 2000);
					  
					 setTimeout(
  function() 
  {
window.location.href="index.php";
  }, 3000);
					
			}
    });
	});
//Supervisor
	    $("button[name='btn-save2']").click(function(e){
		e.preventDefault();
		var wpg = $("input[name='goal2']").val();
		var wpa = $("input[name='attr2']").val();
		var wpgper = $("input[name='pergoal2']").val();
		var wpaper = $("input[name='perattr2']").val();
$.ajax({
            type: "POST",
            url: "update.php", //process to add
            data: {goal : wpg , attr : wpa, pergoal : wpgper, perattr : wpaper, id1 : 3, id2 : 4} ,					
            success: function(data){
			$("#dis").fadeOut();
			$("#dis").fadeIn('slow');
				 $("#dis").html('<div class="alert alert-success"><span class="glyphicon glyphicon-ok">&nbsp;</span>'+data+'</div>');
				     setTimeout(function(){
        $("#dis").fadeOut();
    }, 3000); 					
					  $(".loader").fadeIn();
					  setTimeout(
  function() 
  {
$(".loader").fadeOut();
  }, 2000);
					  
					 setTimeout(
  function() 
  {
window.location.href="index.php";
  }, 3000);
					
			}
    });
	});
//Manager
	    $("button[name='btn-save3']").click(function(e){
		e.preventDefault();
		var wpg = $("input[name='goal3']").val();
		var wpa = $("input[name='attr3']").val();
		var wpgper = $("input[name='pergoal3']").val();
		var wpaper = $("input[name='perattr3']").val();
$.ajax({
            type: "POST",
            url: "update.php", //process to add
            data: {goal : wpg , attr : wpa, pergoal : wpgper, perattr : wpaper, id1 : 5, id2 : 6} ,					
            success: function(data){
			$("#dis").fadeOut();
			$("#dis").fadeIn('slow');
				 $("#dis").html('<div class="alert alert-success"><span class="glyphicon glyphicon-ok">&nbsp;</span>'+data+'</div>');
				     setTimeout(function(){
        $("#dis").fadeOut();
    }, 3000); 					
					  $(".loader").fadeIn();
					  setTimeout(
  function() 
  {
$(".loader").fadeOut();
  }, 2000);
					  
					 setTimeout(
  function() 
  {
window.location.href="index.php";
  }, 3000);
					
			}
    });
	});

</script>
    