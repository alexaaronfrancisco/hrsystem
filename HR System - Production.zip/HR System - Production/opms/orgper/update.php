<?php
require_once '../../assets/dbconfig.php';
require_once '../../assets/connection.php';
	if($_POST)
	{	$goal = $_POST['goal'];	
		$attr = $_POST['attr'];
		$pergoal = $_POST['pergoal'];
		$perattr = $_POST['perattr'];
		$id1 = $_POST['id1'];
		$id2 = $_POST['id2'];
		
		if ($id1 == 1){
		$levelname = "Rank & File / Staff";
		}
		else if ($id1 == 3){
		$levelname = "Supervisory";
		}
		else if ($id1 == 5){
		$levelname = "Managerial";
		}
		
		
		$stmt = $db_con->prepare("UPDATE org_percent SET performance=:goal, percent=:per WHERE org_percent_id LIKE :id");
			$stmt->bindParam(":goal", $goal);
			$stmt->bindParam(":per", $pergoal);
			$stmt->bindParam(":id", $id1);

			
		if($stmt->execute())
		{
			$updateattr=mysql_query("update org_percent set percent='$perattr' where org_percent_id LIKE $id2", $connection);
			$trail = mysql_query("INSERT INTO trail (type, per_action, description, emp_id) VALUES ('Manage OPMS', 'UPDATED', '$levelname', '$user_check')", $connection);
			echo "Updating...";
		}
		else{
			echo "Query Problem";
		}
	}

?>