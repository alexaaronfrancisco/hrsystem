<?php
    $key=$_GET['key'];
    $array = array();
require_once '../../assets/connection.php';
    $query=mysql_query("select emp_name from emp_personal_data INNER JOIN emp_job_data ON emp_personal_data.emp_id=emp_job_data.emp_ID where emp_name LIKE '%{$key}%' AND emp_job_data.job_id BETWEEN 1 AND 14 AND emp_personal_data.emp_status NOT LIKE 'inactive'");
    while($row=mysql_fetch_assoc($query))
    {
      $array[] = $row['emp_name'];
    }
    echo json_encode($array);
?>
