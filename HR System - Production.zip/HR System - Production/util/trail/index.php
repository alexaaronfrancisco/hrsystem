
<?php
include('../../session.php');
if ($login_session != "admin")
{
header("Location: HTTP/1.1 401 Unauthorized Access");
}
$name_sql=mysql_query("select fname from emp_personal_data where emp_id='$user_check'", $connection);
$row2 = mysql_fetch_assoc($name_sql);
$getthename =$row2['fname'];


?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<title>Audit Trail</title>
<!--<link href="bootstrap/css/bootstrap.min.css" rel="stylesheet" media="screen">-->
<!--<link href="bootstrap/css/bootstrap-theme.min.css" rel="stylesheet" media="screen"> -->
  <link rel="shortcut icon" href="../../img/logo.ico" type="image/x-icon">
<link href="../../assets/datatables.min.css" rel="stylesheet" type="text/css">
    <link href="../../bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css"/>
	    <link href="../../bootstrap/css/sidebar.css" rel="stylesheet" type="text/css"/>
<script src="../../bootstrap/js/bootstrap.js"></script>
<script src="../../bootstrap/js/jquery-1.12.0.js"></script>
<script src="../../bootstrap/js/bootstrap.min.js"></script>
<script type="text/javascript">

$(document).ready(function(){
    $('[data-toggle="tooltip"]').tooltip();   
});

$(window).load(function() {
	$(".loader").fadeOut("slow");
})

 $(document).ready(function(){
    var hContent = $("body").height(); // get the height of your content
    var hWindow = $(window).height();  // get the height of the visitor's browser window

    // if the height of your content is bigger than the height of the 
    // browser window, we have a scroll bar
    if(hContent>hWindow) {
	$('.footer').css("position","absolute");
        return true;    
    }

    return false;
});
</script>
<style>
@import url('https://fonts.googleapis.com/css?family=Tauri');
body{font-family: 'Tauri', sans-serif;}
.title{font-size:18px;
padding-bottom: 20px;
color: #0066CC;
width:100%;}

.footer {
z-index:2;
width:100%;
position:fixed;
display: block;
  right: 0;
  bottom: 0;
  left: 0;
  font-size:12px;
  padding: 1rem;
  background-color: #efefef;
  text-align: right;}
  
  .loader {
	position: fixed;
	left: 0px;
	top: 0px;
	width: 100%;
	height: 100%;
	z-index: 9999;
	background: url('../../img/loading.gif') 50% 50% no-repeat rgb(249,249,249);
	opacity: .5;
}

  .icon {
  float:left;
  display:block;
  padding-top: 10px;
  }
  
  .back {
  display:none;
  border:none;
  }
  .add {
  border:none;
border-radius: 100%;
padding-top:15px;
padding-bottom: 17px;
padding-left: 17px;
padding-right: 15px;
font-size:24px;

}
.add:focus{
outline: 0px;
}
.sidebar-brand{
background-color:#FFFFFF;
}
.sidebar-brand img {
width: 225px;
height:57px;

}
.drop {
font-size:12px;
background-color:#111;
display:none;
 text-indent: 30px;
    line-height: 30px;
}

.drop2 {
font-size:12px;
background-color:#111;
display:none;
 text-indent: 30px;
    line-height: 30px;
}

.drop3 {
font-size:12px;
background-color:#111;
display:none;
 text-indent: 30px;
    line-height: 30px;
}

.drop4 {
font-size:12px;
background-color:#111;
display:none;
 text-indent: 30px;
    line-height: 30px;
}

.drop5 {
font-size:12px;
background-color:#111;
display:none;
 text-indent: 30px;
    line-height: 30px;
}


  @media only screen and (max-width: 768px) 
{ 
.footer {
margin-top: 50px;
width:100%;
position: relative;
font-size: 10px;
background-color: #fff;
}

.sidebar-brand img {
width: 190px;
height:45px;

}
}

</style>


</head>

<body>
<!------------------------------------------->
<div class="loader"></div>
      

        <!-- Sidebar -->
		<div class="stat" style="position:static;">
		<div class="sticktop" style="top:0; display:block; position: fixed; z-index:1000; right:0; left:0;">
		<div class="sidebar-brand">
                    <a href="#">
                       <img src="../../img/logo.jpg"> 
                    </a>
                </div>
				<div class="drops">
		<div class="dropdowntogs">
                               <a href="#"><span class="glyphicon glyphicon-user"> </span> &nbsp;&nbsp;<b>Admin</b> <?php echo $getthename ?></a></div>
				<div class="dropmenu">
			<!---	<a href="#"><span class="glyphicon glyphicon-wrench"> </span> Edit Profile</a><div></div>---->
				<a href="../../chgpass.php"><span class="glyphicon glyphicon-lock"> </span> Change Password</a>
				<hr></hr>
				<a href="../../logout.php"><span class="glyphicon glyphicon-log-out"> </span> Log-out</a>
				</div>
				</div>							

		<div class="toggles"><a href="#menu-toggle" id="menu-toggle"><span class="glyphicon glyphicon-menu-hamburger"></span></a></div>       
                </div>
				</div>
				 <div id="wrapper">
											<div id="sidebar-wrapper">
            <ul class="sidebar-nav">
			<div class="menunav"></div>
				<li>
				<a href="../../home/"><span class="glyphicon glyphicon-home icon"></span> Home</a>
                </li>
                <li>
				<div class="main">
                    <a href="#"><i class="glyphicon glyphicon-cog icon"></i> Maintenance</a></div>
					<div class="drop">
					<a href="../../maintenance/emperdata">Employee Personal Data</a>
					<a href="../../maintenance/empjobdata">Employee Job Data</a>
					<a href="../../maintenance/emprater">Employee Rater</a>
					</div>
					</li>
					<li>
				<div class="ijsm">
                    <a href="#"><i class="glyphicon glyphicon-briefcase icon"></i>IJSM</a></div>
					<div class="drop2">
					<a href="../../ijsm/jobclass">Job Classification</a>
					<a href="../../ijsm/jobrating">Job Rating Plan</a>
					<a href="../../ijsm/jobeva">Job Evaluation</a>
					<a href="../../ijsm/salstruct">Salary Structure</a>
					<a href="../../ijsm/salanal">Salary Analysis</a>
					</div>
					</li>
					<li>
				<div class="opms">
                    <a href="#"><i class="glyphicon glyphicon-list-alt icon"></i>OPMS</a></div>
					<div class="drop3">
					<a href="../../opms/wpg">Manage WPG</a>
					<a href="../../opms/wperfpercent">Manage WPA</a>
					<a href="../../opms/orgper">Manage OPMS</a>
					<a href="../../opms/getper">OPMS Form</a>
					</div>
                </li>
                <li>
								<div class="rprt">
                    <a href="#"><i class="glyphicon glyphicon-duplicate icon"></i>Report</a></div>
											
									<div class="drop4">
					<a href="../../rprt/ERN">E.R.N.</a>
					<a href="../../rprt/tabul">OPMS Tabulation</a>
                    <a href="../../rprt/percat">Indv. Performance Category</a>
					<a href="../../rprt/orgcat">Org. Performance Category</a>
				</div>
                </li>
                <li>
				<div class="util">
                    <a href="#" class="active"><i class="glyphicon glyphicon-wrench icon"></i>Utilities</a></div>
					<div class="drop5" style="display:block;">
					<a href="" class="active" style="background-color:#fff; color:#000000;">Audit Trail</a>
					<a href="../../util/showinact">Show inactive</a>
					<a href="../../util/localbup">Data Back-up</a>

					</div>
                </li>
            </ul>							
			<div class="move" style="position:relative; z-index:-1; min-height:600px;">				
														<div id="footer" style=" position:absolute; margin-left:10px; left:0; bottom:0; text-align:center; font-size:10px;  width:200px; margin-right:10px; color:#CCCCCC; ">
				<b>Copyright </b> <span class="glyphicon glyphicon-copyright-mark"></span> <b><?php echo date(' Y')?></b> All Rights Reserved. <br /> Confluent Management Inc. <br /> <b>Version</b> 2.0
				</div>			</div>
							
        </div>			
        <!-- /#sidebar-wrapper -->
        <!-- Page Content -->
<!--table--->				

        <div id="page-content-wrapper">
            <div class="container-fluid">
                     	       
        <div class="content-loader">
		<h2>Audit Trail</h2>
        <hr/>
        <table cellspacing="0" width="100%" id="example" class="table table-striped table-hover table-condensed table-responsive" style="font-size:12px;" >
        <thead>
        <tr>
        <th>ID</th>
        <th>Type</th>
		<th>Action</th>
        <th>Description</th>
		<th>User ID</th>
        <th>Date & Time</th>
        </tr>
        </thead>
        <tbody>
        <?php
        require_once '../../assets/dbconfig.php';
        
        $stmt = $db_con->prepare("SELECT * FROM trail ORDER BY trail_id DESC");
        $stmt->execute();
		while($row=$stmt->fetch(PDO::FETCH_ASSOC))
		{
			?>
			<tr>
			<td><?php echo $row['trail_id']; ?></td>
			<td class="text text-primary" ><?php echo $row['type']; ?></td>
			<td><?php echo $row['per_action']; ?></td>
			<td><?php echo $row['description']; ?></td>
			<td><?php echo $row['emp_id']; ?></td>
			<td><?php echo $row['reg_date']; ?></td></tr>
			<?php

		}
		?>
        </tbody>
        </table>
        
       </div>

    </div>


						
        <!-- /#page-content-wrapper -->
    </div>
	 </div>

</div>
    <!-- /#wrapper -->
     <!-- Menu Toggle Script -->
<?php include('../../assets/navbar.php'); ?>    
     					
<script src="../../bootstrap/js/bootstrap.min.js"></script>
<script type="text/javascript" src="../../assets/datatables.min.js"></script>
<script type="text/javascript" src="../../assets/crud.js"></script>

<script type="text/javascript" charset="utf-8">
$(document).ready(function() {
	$('#example').DataTable({
	aaSorting : [[0, 'desc']]
	});

	$('#example')
	.removeClass( 'display' )
	.addClass('table table-bordered');
	 
});

</script>
</body>
</html>