<?php
require_once '../../assets/dbconfig.php';
require_once '../../assets/connection.php';

if($_POST['active_id'])
{
	$id = $_POST['active_id'];
	$name_sql=mysql_query("select emp_name from emp_personal_data where emp_id='$id'", $connection);
$row = mysql_fetch_assoc($name_sql);
$getname =$row['emp_name'];
//
	$trail = mysql_query("INSERT INTO trail (type, per_action, description, emp_id) VALUES ('Utilities', 'RETRIEVED', '$getname', '$user_check')", $connection);
	$stmt=$db_con->prepare("UPDATE emp_personal_data SET emp_status = 'active' WHERE emp_id=:id");
	$stmt->execute(array(':id'=>$id));	
}
?>