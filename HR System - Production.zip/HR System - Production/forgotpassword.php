<?php
session_start(); // Starting Session
$characters = 'abcdefghijklmnopqrstuvwxyz0123456789';
$string = '';
 $max = strlen($characters) - 1;
 for ($i = 0; $i < 6; $i++) {
      $string .= $characters[mt_rand(0, $max)];
 }
$success='';
$error=''; // Variable To Store Error Message
if (isset($_POST['submit'])) {
if (empty($_POST['empid']) || empty($_POST['bday'])) {
$error = '<div class=""><span class="glyphicon glyphicon-remove"></span>  <strong>Error!</strong> Number or Birthday is invalid!</div>';
}
else
{
// Define $empid and $bday
$empid=$_POST['empid'];
$bday=$_POST['bday'];
// Establishing Connection with Server by passing server_name, user_id and bday as a parameter
$connection = mysql_connect("localhost", "root", "polyester10");
// To protect MySQL injection for Security purpose
$empid = stripslashes($empid);
$bday = stripslashes($bday);
$empid = mysql_real_escape_string($empid);
$bday = mysql_real_escape_string($bday);
// Selecting Database
$db = mysql_select_db("hrsystem", $connection);
// SQL query to fetch information of registerd users and finds user match.
$query = mysql_query("select * from emp_personal_data where emp_bday='$bday' AND emp_id='$empid'", $connection);
$rows = mysql_num_rows($query);
if ($rows == 1) {
$error = '<div class="text text-success"><span class="glyphicon glyphicon-ok"></span>  <b>Password has been sent to your email address!</b></div>';
$query2 = mysql_query("update emp_personal_data set emp_pass='$string' where emp_bday='$bday' AND emp_id='$empid'", $connection);
$mail_sql=mysql_query("select emp_email from emp_personal_data where emp_id='$empid' AND emp_bday='$bday'", $connection);
$rowmail = mysql_fetch_assoc($mail_sql);
$email_pass =$rowmail['emp_email'];
$to = "admin@confluentlearning.com";
$subject = "Account for Confluent HR Solutions";
$content= "This is your new password in 'CONFLUENT HR SOLUTIONS'.\n\n\n
PASSWORD: $string \n\n\n";
$content.="*To access the system (CONFLUENT HR SOLUTIONS), you may contact the system's administrator through the following details: 09071072050\n\n\n";
$content.="\n\n*** This is an automatically generated email ***";

$headers = "From: Confluent HR Solutions <admin@confluentlearning.com>";
mail($to,$subject,$content,$headers);

$trail = mysql_query("INSERT INTO trail (type, per_action, description, emp_id) VALUES ('Session', 'UPDATED', 'Set a new password', '$empid')", $connection);
			echo '<META HTTP-EQUIV="Refresh" Content="5; URL= index.php" >'; // Redirecting To Other Page
}	
	
else {
$error = '<div class=""><span class="glyphicon glypihcon-remove"></span> <strong>Error!</strong>Employee Number and Birthday does not match!</div>';
}
mysql_close($connection); // Closing Connection
}
}
?>
<!DOCTYPE html>
<html>
<head>
<title>Send New Password</title>
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
  <link rel="shortcut icon" href="img/logo.ico" type="image/x-icon">
  <link href="bootstrap/css/bootstrap-theme.min.css" rel="stylesheet" type="text/css"/>
    <link href="bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css"/>
<script src="bootstrap/js/bootstrap.min.js"></script>
<script src="bootstrap/js/jquery-1.12.0.js"></script>
	    <link href="bootstrap/css/bootstrap-datepicker.css" rel="stylesheet" type="text/css"/>
		<script src="bootstrap/js/bootstrap-datepicker.min.js"></script>
<style> 

body{
background-color:#fff;
}

.btn {
border-radius: 0%;
width:100%;
padding: 10px;
font-size:14px;
}
.btn:focus{
visibility:hidden;
outline: 0px;
}

.imglogo img{
width:225px;
height: 60px;
margin-top:25px;
}

.logo{
background-color:#0066CC;
width:100%;
height:50px;
color:#fff; 
}


.logo img{
width:200px;
height:50px;
color:#fff;
}


.form-control {
border-radius: 0px;
}

.input-group-addon {
border-radius: 0px;
}
.form-signin2{
  max-width: 420px;
  padding: 0px 0px 5px;
  margin: 0 auto;
}
.wrapper{
    margin-top: 45px;
}
.form-signin{
  max-width: 420px;
  padding: 30px 30px 15px;
  margin: 0 auto;
  border: 1px solid #cccccc;
}
.input-group{
    height: 45px;
    margin-bottom: 15px;
    border-radius: 0px;
    color: #60B99A;
}
.form-control{
    height: 45px;
    color: #000000;
}
.input-group:hover span i{
    color: #0066CC;
}
.btn-block{
    border-radius: 0px;
    margin-top: 25px;
    background-color: #0066CC;
    border: none;
}
.btn-block:hover{
    background-color: #0066CC;
}
.bol{
    position: relative;
    margin-top: -40px;
    color: #0066CC;
}

.forpass {
text-align:center;
color:#CCCCCC;
padding-top:55px;
font-size:10px;
}

.forpass a {
color:#CCCCCC;
}

@media only screen and (max-width: 768px) {
.img-rounded {
display:block;
background-position:center;
text-align:center;

}
h1 {
font-size:24px;
}

.imglogo img{
width:180px;
height:50px;
}

</style>

</head>
<body>
<center><div class="logo"><img src="img/comlogo.jpg" width="200px" height="50px" /></div></center>
<div class="container">
<br><br>
<!------------------------------------------------------------------------------------------------------------->
 <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">
 <div class = "container">
 					
            <div class="wrapper">
			<div class="form-signin2">
			<a href="index.php"> <span class="glyphicon glyphicon-arrow-left"></span> Back to login page </a>  </div>
                <form action="" method="post" name="Login_Form" class="form-signin"> 
				
                     <div class="row text-center bol"><i class="fa fa-circle"></i></div>
					                
<div class="imglogo" align="center">
                        <img src="img/logo.jpg">
</div>
					              
                    <hr class="spartan">
					<h3>Send a new password</h3>
					<span style="color:#FF0000"><?php echo $error; ?></span>
					<br>
                     <input type="text" class="form-control" name="empid" placeholder="Employee Number" maxlength="4" onkeypress='return event.charCode >= 48 && event.charCode <= 57' required="" autofocus="" />
					   <br>                      	
		               <input type='text' tabindex="2" name='bday' id="bday" class='form-control' required="" placeholder='Your Birthday' readonly="true" data-behavior="datepicker" required>  
							<br>	
					<center>
					<input name="submit" class="btn btn-primary"  type="submit" value=" Send "data-toggle="tooltip" data-placement="right" title="Send" ></center>
<!---                    <button class="btn btn-lg btn-primary btn-block"  name="Submit" value="Entrar" type="Submit">Entrar</button>  			--->
                </form>			
				<br><br>

            </div>
</div>
</body>
<script>
 $(document).ready(function(){
$('input[name="bday"]').datepicker({
		format: "mm/dd/yyyy",
		startView: 'decade'     
		})
        });
</script>
</html>