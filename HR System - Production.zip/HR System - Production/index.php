<?php
include('config.php'); // Includes Login Script
?>
<!DOCTYPE html>
<html>
<head>
<title>Confluent HR Solutions</title>
	<meta charset="utf-8">
  <link rel="shortcut icon" href="img/logo.ico" type="image/x-icon">
  	<meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="bootstrap/css/bootstrap-theme.min.css" rel="stylesheet" type="text/css"/>
    <link href="bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css"/>
<script src="bootstrap/js/bootstrap.min.js"></script>
<script src="bootstrap/js/jquery-1.12.0.js"></script>
<style> 

body{
background-color:#fff;
}

.btn {
border-radius: 100%;
padding-top:15px;
padding-bottom: 15px;
padding-left: 35px;
padding-right: 35px;
font-size:48px;
}
.btn:focus{
visibility:hidden;
outline: 0px;
}

.imglogo img{
width:225px;
height: 60px;
margin-top:25px;
}

.logo{
background-color:#0066CC;
width:100%;
height:50px;
color:#fff; 
}


.logo img{
width:200px;
height:50px;
color:#fff;
}

.form-control {
border-radius: 0px;
}

.input-group-addon {
border-radius: 0px;
}

.wrapper{
    margin-top: 45px;
}
.form-signin{
  max-width: 420px;
  padding: 30px 30px 15px;
  margin: 0 auto;
  border: 1px solid #cccccc;
}
.input-group{
    height: 45px;
    margin-bottom: 15px;
    border-radius: 0px;
    color: #60B99A;
}
.form-control{
    height: 45px;
    color: #000000;
}
.input-group:hover span i{
    color: #0066CC;
}
.btn-block{
    border-radius: 0px;
    margin-top: 25px;
    background-color: #0066CC;
    border: none;
}
.btn-block:hover{
    background-color: #0066CC;
}
.bol{
    position: relative;
    margin-top: -40px;
    color: #0066CC;
}

.forpass {
text-align:center;
color:#CCCCCC;
padding-top:55px;
font-size:10px;
}

.forpass a {
color:#CCCCCC;
}

@media only screen and (max-width: 768px) {
.img-rounded {
display:block;
background-position:center;
text-align:center;

}
h1 {
font-size:24px;
}

.imglogo img{
width:180px;
height:50px;
}

.btn:focus{
visibility:visible;
outline: 0px;
}

</style>

</head>
<body>
<center><div class="logo"><img src="img/comlogo.jpg" width="200px" height="50px" /></div></center>
<div class="container">
<br><br>
<!------------------------------------------------------------------------------------------------------------->
 <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">
 <div class = "container">
            <div class="wrapper">
                <form action="" method="post" name="Login_Form" class="form-signin"> 
                     <div class="row text-center bol"><i class="fa fa-circle"></i></div>
					                
<div class="imglogo" align="center">
                        <img src="img/logo.jpg">
</div>
                
                    <hr class="spartan">
					<span><?php echo $error; ?></span>
                    <div class="input-group">
                        <span class="input-group-addon" id="sizing-addon1">
                            <i class="glyphicon glyphicon-user"></i>
                        </span>
                       <input type="text" class="form-control" name="username" placeholder="Employee Number" maxlength="4" onkeypress='return event.charCode >= 48 && event.charCode <= 57' required="" autofocus="" />
                    </div>
                    <div class="input-group">
                        <span class="input-group-addon" id="sizing-addon1">
                            <i class="glyphicon glyphicon-lock"></i>
                        </span>
                       <input type="password" class="form-control" name="password" placeholder="Password" required=""/>         	  
                    </div>
								
					<center>
					<input name="submit" class="btn btn-primary"  type="submit" value=" > "data-toggle="tooltip" data-placement="right" title="Log In" ></center>
<!---                    <button class="btn btn-lg btn-primary btn-block"  name="Submit" value="Entrar" type="Submit">Entrar</button>  			--->
					<div class="forpass"><a href="forgotpassword.php">*Forgot Password?</a></div>
                </form>			
				<br><br>
				<?php
$connection = mysql_connect("localhost", "root", "polyester10");
$db = mysql_select_db("hrsystem", $connection);
$bday_sql=mysql_query("select * from emp_personal_data ORDER BY emp_id ASC", $connection);
$countbday = mysql_num_rows($bday_sql);

   while($bdayrow=mysql_fetch_assoc($bday_sql))
    { 
	  $arrayid[] = $bdayrow['emp_id']; 		
      $array[] = $bdayrow['emp_bday']; 	 
    }
$x = 0;
while($x < $countbday){
  $empid = $arrayid[$x];	
  $birthdate = $array[$x];
  //explode the date to get month, day and year
  $birthdate = explode("/", $birthdate);
  //get age from date or birthdate
  $age = (date("md", date("U", mktime(0, 0, 0, $birthdate[0], $birthdate[1], $birthdate[2]))) > date("md")
    ? ((date("Y") - $birthdate[2]) - 1)
    : (date("Y") - $birthdate[2]));
	mysql_query("UPDATE emp_personal_data SET emp_age='".$age."' WHERE emp_id LIKE '".$empid."'");
  $x++;
  }
?>
            </div>
</div>
</body>
</html>